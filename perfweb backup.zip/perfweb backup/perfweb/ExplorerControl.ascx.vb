Imports System.Data.SqlClient
Imports System.Configuration
Imports Indigo.Performance.Tools

Partial Class ExplorerControl
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim bobDimp As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\bobdimp")
    Dim wdong As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\wdong")
    Dim rkwiec As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\rkwiec")
    Dim mauroot As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\mauroot")
    Dim michfi As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\v-michfi")
    Dim zhedai As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\zhedai")
    Dim jedmiad As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\jedmiad")

    Dim adminUser As Boolean = bobDimp Or mauroot Or rkwiec Or jedmiad Or wdong Or zhedai
    Dim powerUser As Boolean = michfi

    'Dim adminUser As Boolean = HttpContext.Current.User.IsInRole("XMLab MB Perf Pool")

    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim run_id As Integer
    Dim rcID As Integer
    Dim lastTest As String = String.Empty

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If adminUser Then
            tblPowerTools.Visible = True
            tblAdminTools.Visible = True

        ElseIf powerUser Then

            tblPowerTools.Visible = True
            tblAdminTools.Visible = False

        Else
            tblPowerTools.Visible = False
            tblAdminTools.Visible = False

        End If

        txtSummaryOutput.Visible = False
        txtSummaryOutput.Height = Unit.Pixel(0)
        btnCloseSummaryOutput.Visible = False
        btnCloseSummaryOutput.Enabled = False
        btnCloseSummaryOutput.Height = Unit.Pixel(0)

        btnRemove.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to remove this run?')== false) return false;")
        btnAddNote.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to add this note?')== false) return false;")
        btnUpdateRC.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to update RC comparisons table?')== false) return false;")
        btnAddSummary.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to summarize this run?')== false) return false;")
        btnRemoveSummary.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to remove summary records for this run?')== false) return false;")
        btnRefreshRC.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to refresh the RC table?')== false) return false;")
        btnCleanRun.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to remove the failed jobruns from this run?')== false) return false;")
        btnRefreshFT.Attributes.Add("onclick", "javascript:if(confirm('Are you sure you want to update FT tracking table?')== false) return false;")

        GetNotes(RunID)
    End Sub

    Function GetNotes(ByVal run_id As Integer)

        Dim username As System.Web.UI.WebControls.TableCell
        Dim noteDate As System.Web.UI.WebControls.TableCell
        Dim note As System.Web.UI.WebControls.TableCell
        Dim row As System.Web.UI.WebControls.TableRow

        Dim myConnection As SqlConnection
        Dim sqlCommand As SqlCommand
        Dim dr As SqlDataReader

        Dim headerDisplayed As Boolean = False

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myConnection.Open()

        sqlCommand = New SqlCommand("select username, date, note from run_notes where run_id=@id order by date asc", myConnection)
        sqlCommand.Parameters.Add(New SqlParameter("@id", run_id))
        dr = sqlCommand.ExecuteReader()

        tblNotes.CellPadding = 3
        tblNotes.CellSpacing = 0
        tblNotes.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblNotes.BorderStyle = BorderStyle.Solid
        tblNotes.BorderWidth = Unit.Pixel(2)
        tblNotes.Width = Unit.Percentage(100.0)

        While dr.Read()

            If headerDisplayed = False Then

                username = New System.Web.UI.WebControls.TableCell
                noteDate = New System.Web.UI.WebControls.TableCell
                note = New System.Web.UI.WebControls.TableCell
                row = New System.Web.UI.WebControls.TableRow

                username.Text = "Username"
                noteDate.Text = "Date"
                note.Text = "Note"

                row.Cells.Add(username)
                row.Cells.Add(noteDate)
                row.Cells.Add(note)
                tblNotes.Rows.Add(row)

                tblNotes.Rows(0).BackColor = Color.Beige
                tblNotes.Rows(0).ForeColor = Color.FromArgb(13395456) '#cc6600
                tblNotes.Rows(0).Font.Size = FontUnit.Large
                tblNotes.Rows(0).Font.Bold = True

                headerDisplayed = True

            End If
            username = New System.Web.UI.WebControls.TableCell
            noteDate = New System.Web.UI.WebControls.TableCell
            note = New System.Web.UI.WebControls.TableCell
            row = New System.Web.UI.WebControls.TableRow

            username.Text = dr.Item("username")
            noteDate.Text = dr.Item("date")
            note.Text = Server.HtmlEncode(dr.Item("note"))
            row.Cells.Add(username)
            row.Cells.Add(noteDate)
            row.Cells.Add(note)
            tblNotes.Rows.Add(row)

        End While

        myConnection.Close()
        dr.Close()

    End Function

    Public Property RunID() As Integer
        Get
            Return run_id
        End Get
        Set(ByVal Value As Integer)
            run_id = Value
            BindData(run_id)
        End Set
    End Property

    Public Sub GetData(ByVal RunID As Integer, ByVal rc As Integer)
        run_id = RunID
        rcID = rc
        BindData(RunID)
    End Sub


    Public Function GetDataSource(ByVal run_id As Integer, ByVal sp As String) As SqlDataReader

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myCommand = New SqlCommand(sp, myConnection)

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@run_id", SqlDbType.Int)
            .Parameters(0).Value = run_id
            .CommandTimeout = 120
        End With

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

        Return myReader

    End Function


    Public Function BuildRow(ByVal i As System.Data.Common.DbDataRecord) As String

        Dim out As String

        If lastTest = i.Item(0) Then
            'do not display test name when repeated
            out = BuildJobRunRow(i)
        Else
            'table row for test name
            If (lastTest = String.Empty) Then
                out = BuildTestRow(i)
            Else
                'out = BuildReportRow(i)
                out = BuildTestRow(i)
            End If

            'display a jobrun row if this is not the summary
            If i("validity") <> 4 Then
                out += BuildJobRunRow(i)
            End If

        End If

        lastTest = i.Item(0)

        Return out

    End Function
    Private Sub GetJobRunLinks(ByVal dr As System.Data.Common.DbDataRecord, ByRef ChartLink As String, ByRef CsvLink As String, ByRef ExceptionLink As String)
        Dim Link As String = Server.UrlEncode(dr.Item(0) & "-" & dr.Item(2)) & "&jrid=" & dr.Item(2)
        ChartLink = String.Format("<a href='chartdata.aspx?jrid={0}&rid={1}&test={3}'>chart</a>", dr.Item(2), run_id, dr.Item(4), Server.UrlEncode(dr.Item(0)))
        CsvLink = String.Format("<a href='csv.aspx?file={0}&type=jobrun'>csv</a>&nbsp;&nbsp;", Link)
        If dr("Failed") > 0 Then
            ExceptionLink = String.Format("&nbsp;(<a href='exceptions.aspx?rc={3}&rid={2}&jrid={0}'>{1} of {4} Failed</a>)&nbsp;", dr.Item(2), dr.Item(3), run_id, rcID, dr.Item("Total"))
        Else
            ExceptionLink = String.Format("&nbsp;({0} variations)&nbsp;", dr.Item("Total"))
        End If
    End Sub
    Private Function BuildJobRunRow(ByVal i As System.Data.Common.DbDataRecord) As String

        Dim out As New System.Text.StringBuilder
        Dim ChartLink, ExceptionLink, CsvLink As String
        GetJobRunLinks(i, ChartLink, CsvLink, ExceptionLink)

        out.Append("<TR>")
        out.Append("<TD align='right' style='WIDTH: 21px'>&nbsp;")      'blank cell

        out.Append("</TD><TD style='WIDTH: 150px'>")                    'Start cell for variations
        out.Append(ShowStatus(i.Item(3)))
        out.Append(ChartLink) 'charlink goes here
        If i.Item(3) > 0 Then
            out.Append(ExceptionLink) 'exception link goes here
        Else
            out.Append("&nbsp;(0 Failed)&nbsp;")
        End If
        out.Append("</TD>")                                             'End cell
        out.Append("</TD><TD>")
        out.Append(CsvLink) 'CSV link goes here
        out.Append(formatLogLink("logs", "#3366cc", i, "loglocation"))
        out.Append("</TD><TD>")
        out.Append("<TD style='WIDTH: 400px'>")                         'Start labconfig cell
        out.Append(i.Item(1))
        out.Append("</TD>")                                             'End cell
        out.Append("<TD style='WIDTH: 150px'>")
        out.Append(i.Item(5))
        out.Append("</TD>")
        out.Append("<TD>")
        If adminUser Then
            out.Append("<input type=""submit"" value="" runat=""server"" onclick=""javascript:if(confirm('Are you sure you want to remove jobrun " & i.Item(2) & "?')== false) { return false; } else { window.location='RemoveJobRun.aspx?runId=" & RunID.ToString() & "&jobRunId=" & i.Item(2) & "'};"" style=""background-color:PaleGoldenrod;width:10px;height:10px;"">")
        End If
        out.Append("</TD><TD>")
        out.Append("</TD></TR>")
        Return out.ToString

    End Function

    Private Function BuildReportRow(ByVal i As System.Data.Common.DbDataRecord) As String

        Dim out As New System.Text.StringBuilder
        Dim ChartLink, ExceptionLink, CsvLink As String
        GetJobRunLinks(i, ChartLink, CsvLink, ExceptionLink)

        out.Append("<TR>")
        out.Append("<TD align='right' style='WIDTH: 21px'>&nbsp;")      'blank cell

        out.Append("</TD><TD style='WIDTH: 150px'>")                    'Start cell for variations
        out.Append(ShowStatus(i.Item(3)))
        out.Append(ChartLink) 'charlink goes here
        'If i.Item(3) > 0 Then
        '    out.Append(ExceptionLink) 'exception link goes here
        'Else
        '    out.Append("&nbsp;(0 Failed)&nbsp;")
        'End If
        'out.Append("</TD>")                                             'End cell
        'out.Append("</TD><TD>")
        'out.Append(CsvLink) 'CSV link goes here
        'out.Append(formatLogLink("logs", "#3366cc", i, "loglocation"))
        'out.Append("</TD><TD>")
        'out.Append("<TD style='WIDTH: 400px'>")                         'Start labconfig cell
        'out.Append(i.Item(1))
        'out.Append("</TD>")                                             'End cell
        'out.Append("<TD>")
        'out.Append(i.Item(5))
        'out.Append("</TD>")
        'out.Append("<TD>")
        'If adminUser Then
        '    out.Append("<input type=""submit"" value="" runat=""server"" onclick=""javascript:if(confirm('Are you sure you want to remove jobrun " & i.Item(2) & "?')== false) { return false; } else { window.location='RemoveJobRun.aspx?runId=" & RunID.ToString() & "&jobRunId=" & i.Item(2) & "'};"" style=""background-color:PaleGoldenrod;width:10px;height:10px;"">")
        'End If
        out.Append("</TD><TD>")
        out.Append("</TD></TR>")
        Return out.ToString

    End Function


    Private Function GetVerifyLink(ByVal dr As System.Data.Common.DbDataRecord) As String
        Dim VerifyLink As String
        If dr("verified_by") Is DBNull.Value AndAlso dr("verified_date") Is DBNull.Value Then
            'Allow user to verify
            VerifyLink = "<a href=""javascript:if(confirm('Are you sure you want to verify this run?')==false){;} else { window.location='verifyrun.aspx?rid=" & RunID.ToString() & "&jrid=" & dr("jobrun_id") & "&a=v'};"">verify</a>"
        Else
            VerifyLink = String.Format("<br>verified by {1} on {0}", dr("verified_date"), dr("verified_by"))
            If HttpContext.Current.User.Identity.Name.ToLower().Equals(dr("verified_by").ToString().ToLower()) Then
                VerifyLink += "&nbsp;<a href=""javascript:if(confirm('Are you sure you want to verify this run?')==false){;} else { window.location='verifyrun.aspx?rid=" & RunID.ToString() & "&jrid=" & dr("jobrun_id") & "&a=u'};"">un-verify</a>"
            End If
        End If
        Return VerifyLink
    End Function

    Private Function BuildTestRow(ByVal i As System.Data.Common.DbDataRecord) As String

        Dim out As New System.Text.StringBuilder
        Dim Link As String = Server.UrlEncode(i.Item(0) & ".csv")
        out.Append("<TR><TD style='HEIGHT: 22px' colSpan='5'><b>")

        Dim shortTestName As String = i.Item(0)
        shortTestName = shortTestName.Replace("FeatureTeams", "FT").Replace("Indigo.Performance.", "I.Perf.").Replace(".ReportCard.", ".RC.").Replace("Performance.", "Perf.")
        out.Append(shortTestName)
        If Not (i.Item("test_version") Is DBNull.Value) AndAlso i.Item("test_version") <> "undefined" Then
            out.Append(" v")
            out.Append(i.Item("test_version"))
        End If
        out.Append("</B>")
        out.Append(String.Format("&nbsp;<a href='csv.aspx?file={0}&rid={1}&testid={2}&type=test'>csv</a>&nbsp;", Link, run_id, i.Item(7)))
        If i("validity") = 4 Then
            Dim CsvLink, ChartLink, ExceptionsLink As String
            GetJobRunLinks(i, ChartLink, CsvLink, ExceptionsLink)
            Dim VerifyLink As String = GetVerifyLink(i)
            out.Append("&nbsp;<b>summary:</b>&nbsp;")
            out.Append(ExceptionsLink)
            out.Append("&nbsp;")
            out.Append(CsvLink)
            out.Append("&nbsp;")
            out.Append(ChartLink)
            If Not (VerifyLink Is Nothing) Then out.Append("&nbsp;" & VerifyLink)
        End If
        out.Append("</TD>")

        out.Append("<TD>")
        out.Append("<b>last:</b>&nbsp;")
        out.Append(String.Format("<a href='GenerateReport.aspx?&runid={0}&testid={1}&testname={2} &count=10'>10</a>&nbsp;", run_id, i.Item(7), i.Item(0)))
        out.Append(String.Format("<a href='GenerateReport.aspx?&runid={0}&testid={1}&testname={2} &count=20'>20</a>&nbsp;", run_id, i.Item(7), i.Item(0)))
        out.Append(String.Format("<a href='GenerateReport.aspx?&runid={0}&testid={1}&testname={2} &count=30'>30</a>&nbsp;", run_id, i.Item(7), i.Item(0)))
        out.Append("<b>runs</b>")
        out.Append("</TD>")

        If adminUser And i("validity") = 4 Then
            out.Append("<TD>")
            out.Append("<input type=""submit"" value="" runat=""server"" onclick=""javascript:if(confirm('Are you sure you want to remove summary jobrun " & i.Item(2) & "?')== false) { return false; } else { window.location='RemoveJobRun.aspx?runId=" & RunID.ToString() & "&jobRunId=" & i.Item(2) & "'};"" style=""background-color:DarkKhaki;width:10px;height:10px;"">")
            out.Append("</TD>")
        End If

        out.Append("</TR>")
        Return out.ToString

    End Function
    Private Function ShowStatus(ByVal Failures As Object) As String

        Dim outstring As String

        Try

            If CType(Failures, Int32) > 0 Then
                outstring = "x.gif"
            Else
                outstring = "check.gif"
            End If

        Catch ex As Exception
        End Try

        Return String.Format("&nbsp;<img src='images/{0}'>", outstring)

    End Function

    Private Function formatLogLink(ByVal LinkText As String, ByVal LinkColor As String, ByVal i As System.Data.Common.DbDataRecord, ByVal fieldName As String) As String

        If i.Item(fieldName) Is DBNull.Value OrElse i.Item(fieldName) Is Nothing Then
            Return ""
        Else
            Return String.Format("<a href='{0}' style='COLOR: {1}'>{2}</a>", i.Item(fieldName), LinkColor, LinkText)
        End If

    End Function

    Private Function formatLink(ByVal URL As String, ByVal LinkText As String, ByVal LinkColor As String, ByVal QString As String, ByVal AltText As String, Optional ByVal Link As Boolean = True)

        If Link Then
            If LinkText Is String.Empty OrElse LinkText = "0" OrElse QString = "" Then
                Return String.Format("<a href='{0}' alt='{1}' style='COLOR: {2}'>{3}</a>", URL, AltText, LinkColor, LinkText)
            Else
                Return String.Format("<a href='{0}{1}' alt='{2}' style='COLOR: {3}'>{4}</a>", URL, "file=" & QString.ToString, AltText, LinkColor, LinkText)
            End If
        Else
            Return String.Format("<a style='COLOR: {3}'>{4}</a>", URL, "file=" & QString.ToString, AltText, LinkColor, LinkText)
        End If

    End Function

    Public Function GetRunStats(ByVal run_id As Integer) As String

        Dim MyReader As SqlDataReader = GetDataSource(run_id, "w_sp_runstats")
        Dim out As String

        While MyReader.Read

            out = MyReader("test_count") & " tests, " & MyReader("jobrun_count") & " test runs, " & MyReader("variation_count") & " variations, "
            If Convert.ToInt32(MyReader("failed_variation_count")) > 0 Then
                out = out & "<font color='red'>" & MyReader("failed_variation_count") & " failed variations</font>"
            Else
                'out = out & "<font color='red'>" & MyReader("failed_variation_count") & " failed variations</font>"
            End If

        End While

        Return out

    End Function


    Private Sub BindData(ByVal run_id As Integer)

        With Repeater1
            .DataSource = GetDataSource(run_id, "w_sp_jobruns")
            .DataBind()
        End With

        lblStats.Text = GetRunStats(run_id)

    End Sub

    Public Function GetDataSource(ByVal jobrun_id As Integer) As String

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String = String.Format("w_sp_getnotes " & jobrun_id.ToString)


        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myCommand = New SqlCommand(sql, myConnection)

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

        Dim sb As New System.Text.StringBuilder
        sb.Append("<i>")
        While myReader.Read
            sb.Append(String.Format("<img src='images/info2.gif' border='0' alt='{0}'>", myReader(0)))
            sb.Append(CType(myReader(0), String).Substring(0, 100))
            sb.Append("...<br>")
        End While

        sb.Append("</i>")

        Return sb.ToString

    End Function

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myConnection.Open()
        myCommand = New SqlCommand("P_ExpungeRunId", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure
        myCommand.Parameters.Add("@run_id", RunID)
        myCommand.CommandTimeout = 600
        myCommand.ExecuteNonQuery()

        myConnection.Close()

        Response.Redirect("Explorer.aspx")

    End Sub

    Private Sub btnAddNote_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNote.Click

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim note As String
        Dim username As String
        Dim index As Integer

        note = New String(txtNote.Text)

        If Not IsDBNull(note) And note.Length > 0 Then
            username = New String(HttpContext.Current.User.Identity.Name.ToLower())
            index = username.IndexOf("\")

            If index <> -1 Then
                username = username.Substring(index + 1)
            End If

            txtNote.Text = username

            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand("P_AddRunNote", connection)
            command.CommandType = CommandType.StoredProcedure
            command.Parameters.Add(New SqlParameter("@run_id", RunID))
            command.Parameters.Add(New SqlParameter("@username", username))
            command.Parameters.Add(New SqlParameter("@note", note))
            command.ExecuteNonQuery()

            connection.Close()
            Response.Redirect("Explorer.aspx?rc=1&rid1=" & RunID)
            txtNote.Text = ""

        End If

    End Sub

    Private Sub btnAddSummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddSummary.Click
        Dim connectionString As New String("data source=xmlab-perfsql;database=PerfV3;user id=Performance;password =Performance")
        Dim verbose As Boolean = True
        Dim ciLib As CILibrary

        Dim output As System.IO.TextWriter
        Dim reader As System.IO.TextReader

        Try
            output = New System.IO.StringWriter

            ciLib = New CILibrary(RunID, connectionString, verbose, output)
            ciLib.GenerateSummaryRecords()
            'txtSummaryOutput.Visible = True
            'txtSummaryOutput.Height = Unit.Pixel(100)
            'btnCloseSummaryOutput.Visible = True
            'btnCloseSummaryOutput.Enabled = True
            'btnCloseSummaryOutput.Height = Unit.Pixel(22)

            reader = New System.IO.StringReader(output.ToString())

            'txtSummaryOutput.Text = reader.ReadToEnd()

            Response.Redirect("Explorer.aspx?rc=1&rid1=" & RunID)

        Catch ex As Exception
            txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        End Try



    End Sub

    Private Sub btnRemoveSummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveSummary.Click
        Dim connectionString As New String("data source=xmlab-perfsql;database=PerfV3;user id=Performance;password =Performance")
        Dim verbose As Boolean = True
        Dim ciLib As CILibrary

        Dim output As System.IO.TextWriter
        Dim reader As System.IO.TextReader

        Try
            output = New System.IO.StringWriter

            ciLib = New CILibrary(RunID, connectionString, verbose, output)
            ciLib.DeleteSummaryRecords()

            reader = New System.IO.StringReader(output.ToString())


            Response.Redirect("Explorer.aspx?rc=1&rid1=" & RunID)
        Catch ex As Exception
            txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        End Try

    End Sub



    Private Sub btnCloseSummaryOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        txtSummaryOutput.Text = ""
        txtSummaryOutput.Visible = False
        txtSummaryOutput.Height = Unit.Pixel(0)
        btnCloseSummaryOutput.Visible = False
        btnCloseSummaryOutput.Enabled = False
        btnCloseSummaryOutput.Height = Unit.Pixel(0)

        Server.Transfer("Explorer.aspx?rc=1&rid1=" & RunID)

    End Sub

    Private Sub btnUpdateRC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateRC.Click

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim comment As String
        Dim typeId As Integer  'for now it works only for ReportCard table updates

        comment = New String(txtComment.Text)

        Dim x As String
        Dim scenarios() As String

        Dim tempString As String
        Dim size As Integer = 0




        Dim resultOutput As String

        Try

            txtSummaryOutput.Visible = True
            txtSummaryOutput.Height = Unit.Pixel(100)
            btnCloseSummaryOutput.Visible = True
            btnCloseSummaryOutput.Enabled = True
            btnCloseSummaryOutput.Height = Unit.Pixel(22)

            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            Dim runtypeIdParameter As SqlParameter
            Dim runtypeId As Integer

            command = New SqlCommand("P_GetRuntypeId", connection)
            command.CommandType = CommandType.StoredProcedure
            command.Parameters.Add(New SqlParameter("@run_id", RunID))

            runtypeIdParameter = New SqlParameter("@runtype_id", SqlDbType.Int)
            runtypeIdParameter.Direction = ParameterDirection.Output
            command.Parameters.Add(runtypeIdParameter)

            command.ExecuteNonQuery()

            runtypeId = runtypeIdParameter.Value

            'For now hardcode the initial values
            If (IsDBNull(txtRCType.Text) Or txtRCType.Text.Length <= 0) Then

                Select Case runtypeId
                    Case 6
                        typeId = 1  ' ReportCards
                    Case 28
                        typeId = 20  ' ReportCardsSMP
                    Case 39
                        typeId = 10  ' Latency
                    Case 70
                        typeId = 1  ' ReportCards on WAP
                    Case 71
                        typeId = 10 ' Latency on WAP
                    Case 76
                        typeId = 20 ' ReportCardsSMP
                    Case 79
                        typeId = 120 ' orcas_ft
                    Case 80
                        typeId = 101 'Orcas Report Card
                    Case 90
                        typeId = 120 ' V1_FT
                    Case 97
                        typeId = 120 ' Orcas_Latency
                    Case 100
                        typeId = 120 ' V1_Latency 
                    Case Else
                        ' currently we support this only for RC, Latency and RC_SMP runs
                        Throw New Exception("Currently this feature is supported only for ReportCard/ReportCard_SMP/Latency runs.  Please try another RunId.")
                End Select

                txtRCType.Text = typeId.ToString()
            End If

            typeId = Convert.ToInt32(txtRCType.Text)

            Dim scenarioIds As String

            If txtScenarios.Text = "All" And (typeId = 120 Or typeId = 101) Then

                Dim dr As SqlDataReader

                command = New SqlCommand("P_GetScenariosForAutoUpdate", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@reportcard_id", typeId))
                command.Parameters.Add(New SqlParameter("@runtype_id", runtypeId))

                dr = command.ExecuteReader()

                While dr.Read()
                    If Not IsDBNull(dr.Item("scenario_id")) Then
                        scenarioIds += CType(dr.Item("scenario_id"), String) & ","
                    End If

                End While

                scenarioIds = scenarioIds.TrimEnd(",")
                dr.Close()

            End If

            x = txtScenarios.Text

            If txtScenarios.Text <> "All" And txtScenarios.Text.Length > 0 Then
                scenarios = x.Split(",")
            Else
                scenarios = scenarioIds.Split(",")
            End If

            size = scenarios.Length
            Dim i As Integer = 0
            Dim scenarioValues(size) As Double

            If (Not IsDBNull(comment)) And comment.Length > 0 And size > 0 Then

                For Each tempString In scenarios

                    scenarioValues(i) = Convert.ToInt16(scenarios(i))

                    If (IsDBNull(txtWhidbey.Text) Or txtWhidbey.Text.Length = 0) Or (IsDBNull(txtEverett.Text) Or txtEverett.Text.Length = 0) Then

                        Dim recentEverettRunParameter As SqlParameter
                        Dim recentWhidbeyRunParameter As SqlParameter

                        command = New SqlCommand("P_GetRecentEverettWhidbeyRunFromComparison", connection)
                        command.CommandType = CommandType.StoredProcedure
                        command.Parameters.Add(New SqlParameter("@reportcard_id", txtRCType.Text))
                        command.Parameters.Add(New SqlParameter("@scenario_id", scenarioValues(i)))
                        command.Parameters.Add(New SqlParameter("@runtype_id", runtypeId))

                        recentEverettRunParameter = New SqlParameter("@everett_run_id", SqlDbType.Int)
                        recentEverettRunParameter.Direction = ParameterDirection.Output
                        command.Parameters.Add(recentEverettRunParameter)

                        recentWhidbeyRunParameter = New SqlParameter("@whidbey_run_id", SqlDbType.Int)
                        recentWhidbeyRunParameter.Direction = ParameterDirection.Output
                        command.Parameters.Add(recentWhidbeyRunParameter)

                        command.ExecuteNonQuery()

                        txtEverett.Text = Convert.ToString(recentEverettRunParameter.Value)
                        If (txtRCType.Text = "101" And (scenarioValues(i) = "4" Or scenarioValues(i) = "13")) Then
                            txtWhidbey.Text = RunID
                        ElseIf (txtRCType.Text = "120" And ((runtypeId = 79 And scenarioValues(i) <> "12") Or runtypeId = 97)) Then
                            txtWhidbey.Text = RunID
                        Else
                            txtWhidbey.Text = Convert.ToString(recentWhidbeyRunParameter.Value)
                        End If

                        If (IsDBNull(txtWhidbey.Text) Or txtWhidbey.Text.Length = 0) And (IsDBNull(txtEverett.Text) Or txtEverett.Text.Length = 0) Then
                            ' this is a new test, user didn't fill in new whidbey/everett values and we can't get these from current comparisons data
                            Throw New Exception("No whidbey/everett data exists for this test.  Please fill in at least one value in the box.")
                        End If

                    End If

                    Dim comparisonExistsParameter As SqlParameter

                    Dim comparisonExists As Boolean

                    command = New SqlCommand("P_UpdateComparisonsData", connection)
                    command.CommandType = CommandType.StoredProcedure
                    command.Parameters.Add(New SqlParameter("@reportcard_id", txtRCType.Text))
                    command.Parameters.Add(New SqlParameter("@scenario_id", scenarioValues(i)))
                    command.Parameters.Add(New SqlParameter("@indigo_run_id", RunID))

                    If (IsDBNull(txtEverett.Text) Or txtEverett.Text.Length = 0) Then
                        command.Parameters.Add(New SqlParameter("@everett_run_id", Convert.DBNull))
                    Else
                        command.Parameters.Add(New SqlParameter("@everett_run_id", txtEverett.Text))
                    End If

                    If (IsDBNull(txtWhidbey.Text) Or txtWhidbey.Text.Length = 0) Then
                        command.Parameters.Add(New SqlParameter("@whidbey_run_id", Convert.DBNull))
                    Else
                        command.Parameters.Add(New SqlParameter("@whidbey_run_id", txtWhidbey.Text))
                    End If

                    command.Parameters.Add(New SqlParameter("@comment", comment))

                    comparisonExistsParameter = New SqlParameter("@comparison_exists", SqlDbType.Int)
                    comparisonExistsParameter.Direction = ParameterDirection.Output
                    command.Parameters.Add(comparisonExistsParameter)

                    command.ExecuteNonQuery()

                    comparisonExists = Convert.ToBoolean(comparisonExistsParameter.Value)

                    If comparisonExists Then
                        'txtSummaryOutput.Text = "Comparison exists."
                        Throw New Exception("Comparison with this RunId and Scenario exists already.")
                    End If

                    resultOutput += "Scenario: " + scenarioValues(i).ToString() + ", Everett=" + txtEverett.Text + ", Whidbey=" + txtWhidbey.Text + vbNewLine

                    txtEverett.Text = String.Empty
                    txtWhidbey.Text = String.Empty

                    i += 1
                Next

                txtSummaryOutput.Text = resultOutput

            Else

                Throw New Exception("'Scenario(s)' or 'Comment' box is empty.  Please fill both with data.")

            End If

        Catch ex As Exception

            txtSummaryOutput.Text += "CAUGHT EXCEPTION: " & ex.Message

        Finally

            connection.Close()

        End Try

        'Response.Redirect("Explorer.aspx?rc=1&rid1=" & RunID)
        'txtComment.Text = ""

        txtEverett.Text = String.Empty
        txtWhidbey.Text = String.Empty
        txtComment.Text = String.Empty
        txtRCType.Text = String.Empty
        txtScenarios.Text = String.Empty

    End Sub
    Private Sub btnRefreshRC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefreshRC.Click

        Dim connection As SqlConnection
        Dim command As SqlCommand


        Try

            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand("P_RefreshReportCardSnapshotTable", connection)
            command.CommandTimeout = 600
            command.CommandType = CommandType.StoredProcedure
            command.ExecuteNonQuery()

        Catch ex As Exception

            txtSummaryOutput.Visible = True
            txtSummaryOutput.Height = Unit.Pixel(100)
            btnCloseSummaryOutput.Visible = True
            btnCloseSummaryOutput.Enabled = True
            btnCloseSummaryOutput.Height = Unit.Pixel(22)

            txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally

            connection.Close()

        End Try

    End Sub


    Private Sub btnRefreshFT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefreshFT.Click

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Try

            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand("P_RefreshFeatureTeamsSnapshotTable", connection)
            command.CommandTimeout = 300
            command.CommandType = CommandType.StoredProcedure
            command.ExecuteNonQuery()

        Catch ex As Exception

            txtSummaryOutput.Visible = True
            txtSummaryOutput.Height = Unit.Pixel(100)
            btnCloseSummaryOutput.Visible = True
            btnCloseSummaryOutput.Enabled = True
            btnCloseSummaryOutput.Height = Unit.Pixel(22)

            txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally

            connection.Close()

        End Try

    End Sub



    Private Sub btnCleanRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCleanRun.Click

        Dim connection As SqlConnection
        Dim command As SqlCommand

        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        command = New SqlCommand("P_ExpungeFailedJobrunsSelective", connection)
        command.CommandType = CommandType.StoredProcedure
        command.CommandTimeout = 300
        command.Parameters.Add(New SqlParameter("@run_id", RunID))
        command.ExecuteNonQuery()

        connection.Close()
        Response.Redirect("Explorer.aspx?rc=1&rid1=" & RunID)

    End Sub
End Class
