Public Class compselect
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents cbCPUUtilization As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbThroughput As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbLatency As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbNetworkUtilization As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbNoOfThreads As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbCPUCycles As System.Web.UI.WebControls.CheckBox
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton3 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton4 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddMessageSize As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBox As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddFramework As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents ddOSParings As System.Web.UI.WebControls.DropDownList
    Protected WithEvents DropDownList2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents DropDownList3 As System.Web.UI.WebControls.DropDownList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Not IsPostBack Then
            LoadOS(True)
            LoadFramework(True)
            LoadBox(True)
            LoadMessageSize(True)
        End If



    End Sub


    Function ServerValidate()

        Dim MatchCount As Integer

        Try
            If ddOSParings.SelectedValue = "Vary This" Then MatchCount += 1
            If ddFramework.SelectedValue = "Vary This" Then MatchCount += 1
            If ddMessageSize.SelectedValue = "Vary This" Then MatchCount += 1
            If ddBox.SelectedValue = "Vary This" Then MatchCount += 1

            If MatchCount > 1 Then
                Me.lblError.Visible = True
                Return False
            Else
                Me.lblError.Visible = False
                Return True
            End If
        Catch exc As Exception
        End Try

    End Function

    Private Sub LoadOS(ByVal VaryThis As Boolean)

        With ddOSParings
            .Items.Clear()
            .Items.Add("XP Pro SP1")
            .Items.Add("XP Pro SP2")
            .Items.Add("Win2k SP 2")
            .Items.Add(".NET Svr (3621)")
            .Items.Add("Win03 Svr (3777)")
            .Items.Add("Win03 Svr (3663)")
            .Items(0).Selected = True
            .Items.Add("Vary This")

        End With

    End Sub

    Private Sub LoadFramework(ByVal VaryThis As Boolean)

        With ddFramework
            .Items.Clear()
            .Items.Add("1.1")
            .Items.Add("1.2")
            .Items(0).Selected = True
            .Items.Add("Vary This")
        End With

    End Sub

    Private Sub LoadBox(ByVal VaryThis As Boolean)

        With ddBox
            .Items.Clear()
            .Items.Add("Client")
            .Items.Add("Server")
            .Items(0).Selected = True
            .Items.Add("Vary This")
        End With

    End Sub

    Private Sub LoadMessageSize(ByVal VaryThis As Boolean)

        With ddMessageSize
            .Items.Clear()
            .Items.Add("512")
            .Items.Add("1024")
            .Items.Add("2048")
            .Items.Add("4096")
            .Items(0).Selected = True
            .Items.Add("Vary This")
        End With

    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ServerValidate() Then
            Response.Redirect("ComparisonGraph.aspx")
        End If
    End Sub
End Class
