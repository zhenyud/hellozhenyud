Imports System.Data.SqlClient
Imports System.Configuration

Public Class Glossary2
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents LeftNav2 As LeftNav
    Protected WithEvents DataGrid2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid3 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid4 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid5 As System.Web.UI.WebControls.DataGrid

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        '[AML] Hides Run navigator on left side
        LeftNav2.ShowRunNavigator = False

        'By default, use Report Card 1
        Dim reportcard_id As Integer = Request2Int("rc", 1)

        If Not IsPostBack Then
            BindScenarioDef(reportcard_id)
            BindOrcasScenarioDef(reportcard_id)
            BindOsloScenarioDef(reportcard_id)
            BindMeasurementDef(reportcard_id)
            BindOrcasSp1ScenarioDef(reportcard_id)
         End If
    End Sub

    Private Sub BindScenarioDef(ByVal reportcard_id As Integer)
        Dim ds As New DataSet
        Dim myString As String = "SELECT s.*, o.purpose FROM w_reportcard_scenario_details AS s " _
                               + "INNER JOIN w_reportcard_criteria_ogf AS o ON s.scenario_id = o.scenario_id AND s.reportcard_id = o.reportcard_id"
        ds = GetDataSet(myString)
        DataGrid1.DataSource = ds
        DataGrid1.DataBind()
    End Sub

    Private Sub BindOrcasScenarioDef(ByVal reportcard_id As Integer)
        Dim ds As New DataSet
        Dim myString As String = "SELECT s.*, o.purpose FROM w_orcas_reportcard_scenario_details AS s " _
                               + "INNER JOIN w_reportcard_criteria_ogf AS o ON s.scenario_id = o.scenario_id AND s.reportcard_id = o.reportcard_id WHERE s.reportcard_id=101"
        ds = GetDataSet(myString)
        Datagrid3.DataSource = ds
        Datagrid3.DataBind()
    End Sub

    Private Sub BindOrcasSp1ScenarioDef(ByVal reportcard_id As Integer)
        Dim ds As New DataSet
        Dim myString As String = "SELECT s.*, o.purpose FROM w_orcas_sp1_reportcard_scenario_details AS s " _
                               + "INNER JOIN w_reportcard_criteria_ogf AS o ON s.scenario_id = o.scenario_id AND s.reportcard_id = o.reportcard_id WHERE s.reportcard_id=130"
        ds = GetDataSet(myString)
        Datagrid5.DataSource = ds
        Datagrid5.DataBind()
    End Sub

    Private Sub BindOsloScenarioDef(ByVal reportcard_id As Integer)
        Dim ds As New DataSet
        Dim myString As String = "SELECT s.*, o.purpose FROM w_oslo_reportcard_scenario_details AS s " _
                               + "INNER JOIN w_reportcard_criteria_ogf AS o ON s.scenario_id = o.scenario_id AND s.reportcard_id = o.reportcard_id WHERE s.reportcard_id=111"
        ds = GetDataSet(myString)
        Datagrid4.DataSource = ds
        Datagrid4.DataBind()
    End Sub

    Private Sub BindMeasurementDef(ByVal reportcard_id As Integer)
        Dim ds As New DataSet
        ds = GetDataSet("w_sp_get_measurement_types")
        DataGrid2.DataSource = ds
        DataGrid2.DataBind()
    End Sub

    Private Function GetDataSet(ByVal sql As String) As DataSet
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet

        myConnection = New SqlConnection(perfConnection)
        myDA = New SqlDataAdapter(sql, myConnection)

        myConnection.Open()
        myDA.Fill(ds)

        myConnection.Close()
        Return ds

    End Function


    Private Function GetDBValue(ByVal FieldName As String, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) As Double

        Try
            If Not DataBinder.Eval(e.Item.DataItem, FieldName) Is DBNull.Value Then
                Return CType(DataBinder.Eval(e.Item.DataItem, FieldName), Double)
            Else
                Return -99
            End If

        Catch ex As Exception
            Return -1
        End Try


    End Function

    Protected Function Request2Int(ByVal key As String, Optional ByVal DefaultValue As Integer = 0) As Integer

        Try
            Dim Num As Integer = Convert.ToInt32(Request(key))
            If Num = 0 Then
                Return DefaultValue
            Else
                Return Num
            End If
        Catch ex As Exception
            Return DefaultValue
        End Try

    End Function
    Private Sub DataGrid1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemDataBound

        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then

            e.Item.Cells(0).Text = String.Format("<A NAME='s{0}'>{0}", GetDBValue("scenario_id", e))

        End If

    End Sub

End Class
