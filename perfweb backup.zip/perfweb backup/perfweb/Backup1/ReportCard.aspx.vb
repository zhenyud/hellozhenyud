Imports System.Data.SqlClient
Imports System.Collections.Specialized

Public Class reportcard
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RunNav As LeftNav
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblReportCardTitle As System.Web.UI.WebControls.Label
    Protected WithEvents RCMemory As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents FTScorecards As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lblScorecardsTitle As System.Web.UI.WebControls.Label
    Protected WithEvents lblReportCardMemoryTitle As System.Web.UI.WebControls.Label
    Protected WithEvents CreatedStamp As System.Web.UI.WebControls.Literal
    Protected WithEvents RCThroughput As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lblReportCardLatencyTitle As System.Web.UI.WebControls.Label
    Protected WithEvents RCLatency As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lblReportCardSMPThroughputTitle As System.Web.UI.WebControls.Label
    Protected WithEvents RCSMPThroughput As System.Web.UI.WebControls.DataGrid
    Protected WithEvents RCThroughput2 As System.Web.UI.WebControls.DataGrid


    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Const sm_NotFound As String = "N/A"
    Const sm_Disabled As String = ""
    Const ShowRCLinks As Boolean = True

    Dim RegressionCalculated As Boolean = False
    Dim ds As DataSet = New DataSet("myDataSet")
    Dim htBugs As New Hashtable
    Dim slBugs As New StringCollection
    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim dsIndigoThData As DataSet
    Dim dsComparativeThData As DataSet
    Dim dsScenarios As DataSet
    'Dim reportcard_id As Integer = 1
    Enum ReportCards
        ThroughputId = 1
        ThroughputId2 = 5
        LatencyId = 10
        RefsetId = 15
        SMPThroughputId = 20
    End Enum
    Dim rcRun As Integer
    Dim regression_run As Integer

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '[AML] hides Run navigator on left side
        RunNav.ShowRunNavigator = False

        '[AML] Used to set default.aspx to either reportcard or explorer depending on last visited
        Dim cookie As New HttpCookie("PerfPage", "reportcard")
        cookie.Expires = DateTime.MaxValue
        Response.Cookies.Add(cookie)

        'All report cards are on one page, but each metric is a different report card in DB
        '[AML] Currently only one (rc=1) report card.
        ' If Convert.ToInt32(Request("rc")) > 0 Then
        ' reportcard_id = Convert.ToInt32(Request("rc"))
        ' Else
        '     reportcard_id = 1
        ' End If

        '[AML] Not clear when this page is a post-back; main table has no forms, 
        ' and leftNav forms cause this to be reloaded with IsPostBack = false.
        If Not IsPostBack Then

            '[AML] Populates throughput reportcard grid (table)
            ShowRCThroughputStatus()
            ShowRCThroughput2Status()

            '[AML] Show feature team status
            ShowFeatureTeamScorecardsStatus()

            '[AML] Show report card grid for memory metrics
            ShowRCMemoryStatus()

            '[AML] Show report card grid for latency metrics
            ShowRCLatencyStatus()

            '[AML] Show report card grid for latency metrics
            ShowRCSMPThroughputStatus()

            '[AML] Show when page was created
            CreatedStamp.Text = "Created: " + Now().ToShortDateString + " " + Now().ToLongTimeString
        End If

    End Sub
    '[AML] Version 2.0: now using a table view to do all ratio calculations.
    Private Sub ShowRCThroughputStatus()

        ' [AML] Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        ' [AML] Gets this reportcard's data (id, purpose, criteria, enabled, OGF) and place in table.
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0} " + _
        "ORDER BY scenario_id", ReportCards.ThroughputId.ToString("d"))
        DBUtil.ExecDataSet(ds, selectString, "RCThroughputStatus")

        '[AML] Bind table to datagrid.
        RCThroughput.DataSource = ds.Tables("RCThroughputStatus")
        RCThroughput.DataBind()

    End Sub

    'Scalability/capacity throughput table: uses stored procedure to get data
    Private Sub ShowRCThroughput2Status()

        ' [AML] Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenarios_scalability_status")

        With myCommand
            .CommandType = CommandType.StoredProcedure
        End With

        DBUtil.ExecDataSet(ds, myCommand, "RCThroughput2Status")

        '[AML] Bind table to datagrid.
        RCThroughput2.DataSource = ds.Tables("RCThroughput2Status")
        RCThroughput2.DataBind()

    End Sub
    '[AML] Also see FTScorecards_ItemDataBound for coloring logic
    Private Sub ShowFeatureTeamScorecardsStatus()
        ' [AML] Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        ' [AML] Gets this scorecards data and place in table.
        Dim selectString As String = String.Format("SELECT * FROM w_scorecards_progress_ogf ORDER BY team")
        DBUtil.ExecDataSet(ds, selectString, "FTScorecardsStatus")

        '[AML] Bind table to datagrid.
        FTScorecards.DataSource = ds.Tables("FTScorecardsStatus")
        FTScorecards.DataBind()
    End Sub
    Private Sub ShowRCMemoryStatus()
        ' Since the goal is smaller than the competition, all the data is % relative to the competition.
        ' All real work in done in the view.

        ' Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        ' Gets this reportcard's data
        'Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status_memory WHERE reportcard_id = {0} " + _
        '"ORDER BY scenario_id", ReportCards.RefsetId.ToString("d"))
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status_memory_table ORDER BY scenario_order")
        DBUtil.ExecDataSet(ds, selectString, "RCMemoryStatus")

        ' Bind table to datagrid.
        RCMemory.DataSource = ds.Tables("RCMemoryStatus")
        RCMemory.DataBind()

    End Sub
    Private Sub ShowRCLatencyStatus()
        ' Since the goal is smaller than the competition, all the data is % relative to the competition.
        ' Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        ' Gets the latency reportcard's data
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0} " + _
        "ORDER BY scenario_id", ReportCards.LatencyId.ToString("d"))
        DBUtil.ExecDataSet(ds, selectString, "RCLatencyStatus")

        ' Bind table to datagrid.
        RCLatency.DataSource = ds.Tables("RCLatencyStatus")
        RCLatency.DataBind()
    End Sub
    Private Sub ShowRCSMPThroughputStatus()
        ' Since the goal is smaller than the competition, all the data is % relative to the competition.
        ' Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        ' Gets the latency reportcard's data
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0} " + _
        "ORDER BY scenario_id", ReportCards.SMPThroughputId.ToString("d"))
        DBUtil.ExecDataSet(ds, selectString, "RCSMPThroughputStatus")

        ' Bind table to datagrid.
        RCSMPThroughput.DataSource = ds.Tables("RCSMPThroughputStatus")
        RCSMPThroughput.DataBind()
    End Sub

    '[AML] version 1.0: fill in feature team scorecard from simple table
    Private Sub FTScorecards_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles FTScorecards.ItemDataBound
        Dim TeamColumn As Integer = 0
        Dim OwnerColumn As Integer = 1
        Dim ComparisonColumn As Integer = 2
        Dim ChartColumn As Integer = 3
        Dim OGFColumn As Integer = 4
        Dim OGFShipColumn As Integer = 5

        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim OGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "ogf_color"), String)

            If OGFColor = "blue" Then
                e.Item.Cells(OGFColumn).BackColor = System.Drawing.Color.LightBlue
            Else
                e.Item.Cells(OGFColumn).BackColor = System.Drawing.Color.FromName(OGFColor)
            End If

            If OGFColor = "green" Or OGFColor = "red" Then
                e.Item.Cells(OGFColumn).ForeColor = Color.White
            End If

            If OGFColor.ToLower = "red" Then
                e.Item.Cells(OGFColumn).ToolTip = CType(DataBinder.Eval(e.Item.DataItem, "issue"), String)
            End If

            Dim OGFShipColor As String = CType(DataBinder.Eval(e.Item.DataItem, "shiproom_ogf"), String)

            If OGFShipColor = "blue" Then
                e.Item.Cells(OGFShipColumn).BackColor = System.Drawing.Color.LightBlue
            Else
                e.Item.Cells(OGFShipColumn).BackColor = System.Drawing.Color.FromName(OGFShipColor)
            End If

            If OGFShipColor = "green" Or OGFShipColor = "red" Then
                e.Item.Cells(OGFShipColumn).ForeColor = Color.White
            End If

            If OGFShipColor.ToLower = "red" Then
                e.Item.Cells(OGFShipColumn).ToolTip = CType(DataBinder.Eval(e.Item.DataItem, "issue"), String)
            End If

        End If
    End Sub

    '[AML] version 2.0: simplified; new coloring logic for report card scenarios
    Private Sub RCThroughput_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles RCThroughput.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns by number
        ' not used: Dim IDColumn As Integer = 0
        Dim DescriptionColumn As Integer = 1
        Dim ComparisonColumn As Integer = 2
        Dim EverettColumn As Integer = 3
        Dim WhidbeyColumn As Integer = 4
        Dim CriteriaColumn As Integer = 5
        Dim x64Column As Integer = 6

        'Add link to glossary with detailed descriptions
        e.Item.Cells(DescriptionColumn).Text = String.Format("<a href='glossary.aspx#rc' style='COLOR: {0}'>{1}</a>", _
                                            "#3366cc", e.Item.Cells(1).Text)

        'Get data; is scenario enabled? If not no data or goals yet.
        Dim IsEnabled As Boolean = CType(DataBinder.Eval(e.Item.DataItem, "enabled"), Boolean)

        'scenario id goes into construction of details link
        Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)

        'Only build links, add data, etc., for enabled tests
        If IsEnabled Then
            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria")) Then
                'Whidbey is compared with the criteria to determine the OGF
                'color the Criteria, because I can't get font coloring to work with hyperlinks
                Dim RTMOGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "rtm_ogf_color"), String)
                e.Item.Cells(CriteriaColumn).BackColor = System.Drawing.Color.FromName(RTMOGFColor)
                If RTMOGFColor = "green" Or RTMOGFColor = "red" Then
                    e.Item.Cells(CriteriaColumn).ForeColor = Color.White
                End If
            Else
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If

            'Null means no data planned for everett (--); null means no data yet for whidbey (TBD)
            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "everett_ratio")) Then
                Dim EverettRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "everett_ratio"), Double))
                Dim EverettText As String = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}'>{3}%</a>", 1, ScenarioId, False, EverettRatio)
                e.Item.Cells(EverettColumn).Text = EverettText
            Else
                e.Item.Cells(EverettColumn).Text = "--"
            End If

            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio")) Then
                Dim WhidbeyRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double))
                Dim WhidbeyText As String = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}'>{3}%</a>", 1, ScenarioId, True, WhidbeyRatio)
                e.Item.Cells(WhidbeyColumn).Text = WhidbeyText
            Else
                e.Item.Cells(WhidbeyColumn).Text = "TBD"
            End If
        Else
            'no data if not enabled
            e.Item.Cells(EverettColumn).Text = "--"
            e.Item.Cells(WhidbeyColumn).Text = "TBD"
            e.Item.Cells(WhidbeyColumn).BackColor = Color.White
            e.Item.Cells(CriteriaColumn).Text = "TBD"
        End If

        'Set the x64 column. NULL means no data, -1 means not an x64 scenario.
        If IsDBNull(DataBinder.Eval(e.Item.DataItem, "x64_ratio")) Then
            e.Item.Cells(x64Column).Text = "TBD"
            e.Item.Cells(x64Column).BackColor = Color.White
        Else
            Dim X64Ratio As Double = CType(DataBinder.Eval(e.Item.DataItem, "x64_ratio"), Double)
            If X64Ratio < 0.0 Then
                e.Item.Cells(x64Column).Text = "TBD"
                'e.Item.Cells(WhidbeyColumn).Text = "--"
                e.Item.Cells(x64Column).BackColor = Color.White
            ElseIf X64Ratio < 60.0 Then
                e.Item.Cells(x64Column).Text = ""
                e.Item.Cells(x64Column).BackColor = Color.Red
                e.Item.Cells(x64Column).ForeColor = Color.White
            ElseIf X64Ratio < 80.0 Then
                e.Item.Cells(x64Column).Text = ""
                e.Item.Cells(x64Column).BackColor = Color.Yellow
            Else
                e.Item.Cells(x64Column).Text = ""
                e.Item.Cells(x64Column).BackColor = Color.Green
                e.Item.Cells(x64Column).ForeColor = Color.White
            End If
        End If

    End Sub

    '[AML] version 2.0: simplified; new coloring logic for report card scenarios
    Private Sub RCThroughput2_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles RCThroughput2.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns by number
        ' not used: Dim IDColumn As Integer = 0
        Dim DescriptionColumn As Integer = 1
        Dim ComparisonColumn As Integer = 2
        Dim WhidbeyColumn As Integer = 3
        Dim CriteriaColumn As Integer = 4
        'Dim x64Column As Integer = 5

        'Add link to glossary with detailed descriptions
        e.Item.Cells(DescriptionColumn).Text = String.Format("<a href='glossary.aspx#rc' style='COLOR: {0}'>{1}</a>", _
                                            "#3366cc", e.Item.Cells(1).Text)

        'Get data; is scenario enabled? If not no data or goals yet.
        Dim IsEnabled As Boolean = CType(DataBinder.Eval(e.Item.DataItem, "enabled"), Boolean)

        'scenario id goes into construction of details link
        Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)

        'Only build links, add data, etc., for enabled tests
        If IsEnabled Then
            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria")) Then
                'Whidbey is compared with the criteria to determine the OGF
                'color the Criteria, because I can't get font coloring to work with hyperlinks
                Dim RTMOGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "rtm_ogf_color"), String)
                e.Item.Cells(CriteriaColumn).BackColor = System.Drawing.Color.FromName(RTMOGFColor)
                If RTMOGFColor = "green" Or RTMOGFColor = "red" Then
                    e.Item.Cells(CriteriaColumn).ForeColor = Color.White
                End If
            Else
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If

            'Null means no data yet for whidbey (TBD)

            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "current_ratio")) Then
                Dim WhidbeyRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "current_ratio"), Double))
                'Dim WhidbeyText As String = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}'>{3}%</a>", 1, ScenarioId, True, WhidbeyRatio)

                Dim WhidbeyText As String = String.Format("{0}%", WhidbeyRatio)
                e.Item.Cells(WhidbeyColumn).Text = WhidbeyText
            Else
                e.Item.Cells(WhidbeyColumn).Text = "TBD"
            End If
        Else
            'no data if not enabled
            e.Item.Cells(WhidbeyColumn).Text = "TBD"
            e.Item.Cells(WhidbeyColumn).BackColor = Color.White
            e.Item.Cells(CriteriaColumn).Text = "TBD"
        End If

        'Set the x64 column. NULL means no data, -1 means not an x64 scenario.
        'e.Item.Cells(x64Column).Text = "TBD"
        'e.Item.Cells(x64Column).BackColor = Color.White


    End Sub


    Private Sub RCMemory_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles RCMemory.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns in table on page by number
        ' not used: Dim IDColumn As Integer = 0
        Dim RefSetColumn As Integer = 1
        Dim WorkingSetColumn As Integer = 3
        Dim ThreadsColumn As Integer = 5
        'Must line up with columns above
        Dim ColumnNameArray() As String = {"scenario_id", "whidbey_ratio", "refset_criteria", "workingset_normalized", "workingset_client_normalized", "threads_normalized", "threads_comparison"}
        'Dim ColumnNameArray() As String = {"scenario_id", "whidbey_ratio", "refset_criteria", "workingset_normalized", "workingset_client_normalized", "threads_normalized", "threads_comparison"}

        'if test isn't enabled, result will be null
        'loop from RefSet to Threads columns (see above)
        For i As Integer = 1 To ColumnNameArray.Length - 1 Step 2
            'No goal for this metric for this scenario
            If (String.Equals(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1)), "None") Or (i = 3)) Then
                'if there is data, just let it be shown.
                If (IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))) And i <> 3) Then
                    e.Item.Cells(i).Text = "--"
                    e.Item.Cells(i + 1).Text = "--"
                    e.Item.Cells(i + 1).BackColor = Color.White
                Else
                    'addition to put TBD in workinset column
                    If IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))) Then
                        e.Item.Cells(i).Text = "TBD"
                    End If
                    If IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1))) Then
                        e.Item.Cells(i + 1).Text = "TBD"
                        e.Item.Cells(i + 1).BackColor = Color.White
                    End If
                End If
                'Have data and goals
            ElseIf Not (IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))) Or IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1)))) Then
                Dim current As Double = DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))
                Dim criteria As Double

                Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)
                Dim WhidbeyRatio As Double

                If Not (IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"))) Then
                    WhidbeyRatio = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double))
                    Dim WhidbeyText As String = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}'>{3}%</a>", 15, ScenarioId, True, WhidbeyRatio)
                    e.Item.Cells(RefSetColumn).Text = WhidbeyText
                End If

                If (i = RefSetColumn) Then
                    criteria = 125
                Else
                    criteria = DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1))
                End If

                Dim Ratio As Double = (current / criteria) * 100
                If Ratio > 125 Then
                    e.Item.Cells(i + 1).BackColor = Color.Red
                    e.Item.Cells(i + 1).ForeColor = Color.White
                ElseIf Ratio > 100 Then
                    e.Item.Cells(i + 1).BackColor = Color.Yellow
                Else
                    e.Item.Cells(i + 1).BackColor = Color.Green
                    e.Item.Cells(i + 1).ForeColor = Color.White
                End If

                If (i = ThreadsColumn And (ScenarioId = 7 Or ScenarioId = 12)) Then
                    e.Item.Cells(i + 1).BackColor = Color.LightBlue
                    e.Item.Cells(i + 1).ForeColor = Color.White
                End If

                'If null, then no results are available and OGFs are white
                Else
                    If IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))) Then
                        e.Item.Cells(i).Text = "TBD"
                    End If
                    If IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1))) Then
                    If (i = ThreadsColumn) Then
                        e.Item.Cells(i + 1).Text = "--"
                    Else
                        e.Item.Cells(i + 1).Text = "TBD"
                    End If
                    e.Item.Cells(i + 1).BackColor = Color.White
                End If
                End If

        Next i

    End Sub
    Private Sub RCLatency_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles RCLatency.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns in table on page by number
        ' not used: Dim IDColumn As Integer = 0
        Dim LatencyColumn As Integer = 1
        Dim CriteriaColumn As Integer = 2
        'Must line up with columns above
        Dim ColumnNameArray() As String = {"scenario_name", "whidbey_ratio", "criteria"}

        'scenario id goes into construction of details link
        Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)
        Dim ScenarioName As String = CType(DataBinder.Eval(e.Item.DataItem, "scenario_name"), String)

        'If this scenario is not used for this metric, criteria will be -1 (ratio undefined)
        'If data is not yet available for criteria or ratio, value will be NULL
        'No data yet for this metric (ratio null), and the goal is not yet defined (criteria is null)
        Dim i As Integer = 1 'used to loop; now just one column pair.
        If (IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))) And IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1)))) Then
            e.Item.Cells(i).Text = "TBD"
            e.Item.Cells(i + 1).Text = "TBD"
            e.Item.Cells(i + 1).BackColor = Color.White
        ElseIf IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1))) Then
            'No goal yet, but some data
            Dim ratio As Double = CType(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i)), Double)
            If ratio < 0 Then
                e.Item.Cells(i).Text = "TBD"
            End If
            e.Item.Cells(i + 1).Text = "TBD"
            e.Item.Cells(i + 1).BackColor = Color.White
            'Goal and may or may not be data
        Else
            Dim criteria As Double = CType(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i + 1)), Double)
            'If <0, then this test/variation/scenario combination not tracked
            If criteria < 0 Then
                e.Item.Cells(i).Text = "--"
                e.Item.Cells(i + 1).Text = "--"
                e.Item.Cells(i + 1).BackColor = Color.White
                'no measurement yet
            ElseIf IsDBNull(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i))) Then
                e.Item.Cells(i).Text = "TBD"
                e.Item.Cells(i + 1).BackColor = Color.White
                'have criteria and measurement!
            Else

                Dim WhidbeyRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double))
                Dim WhidbeyText As String = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}'>{3}%</a>", 10, ScenarioId, True, WhidbeyRatio)
                e.Item.Cells(LatencyColumn).Text = WhidbeyText

                Dim ratio As Double = CType(DataBinder.Eval(e.Item.DataItem, ColumnNameArray(i)), Double)
                If ratio > 1.25 * criteria Then
                    e.Item.Cells(i + 1).BackColor = Color.Red
                    e.Item.Cells(i + 1).ForeColor = Color.White
                ElseIf ratio > 1.0 * criteria Then
                    e.Item.Cells(i + 1).BackColor = Color.Yellow
                Else
                    e.Item.Cells(i + 1).BackColor = Color.Green
                    e.Item.Cells(i + 1).ForeColor = Color.White
                End If
            End If
        End If
    End Sub
    Private Sub RCSMPThroughput_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) _
    Handles RCSMPThroughput.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns in table on page by number
        ' not used: Dim IDColumn As Integer = 0
        Dim RatioColumn As Integer = 1
        Dim CriteriaColumn As Integer = 2

        Dim IsEnabled As Boolean = CType(DataBinder.Eval(e.Item.DataItem, "enabled"), Boolean)

        'scenario id goes into construction of details link
        Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)

        'Only build links, add data, etc., for enabled tests
        If IsEnabled Then
            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria")) Then
                'Whidbey is compared with the criteria to determine the OGF
                'color the Criteria, because I can't get font coloring to work with hyperlinks
                Dim RTMOGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "rtm_ogf_color"), String)
                e.Item.Cells(CriteriaColumn).BackColor = System.Drawing.Color.FromName(RTMOGFColor)
                If RTMOGFColor = "green" Or RTMOGFColor = "red" Then
                    e.Item.Cells(CriteriaColumn).ForeColor = Color.White
                End If
            Else
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If

            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio")) Then
                Dim WhidbeyRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double))
                Dim WhidbeyText As String = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}'>{3}%</a>", 20, ScenarioId, True, WhidbeyRatio)
                e.Item.Cells(RatioColumn).Text = WhidbeyText
            Else
                e.Item.Cells(RatioColumn).Text = "TBD"
            End If
        Else
            'no data if not enabled
            'e.Item.Cells(RatioColumn).Text = "TBD"
            'e.Item.Cells(RatioColumn).BackColor = Color.White
            'e.Item.Cells(CriteriaColumn).Text = "TBD"
        End If


        'If this scenario is not used for this metric, criteria will be -1 (ratio undefined)
        'If data is not yet available for criteria or ratio, value will be NULL
        'No data yet for this metric (ratio null), and the goal is not yet defined (criteria is null)
        If (IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria")) And IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"))) Then
            e.Item.Cells(RatioColumn).Text = "TBD"
            e.Item.Cells(CriteriaColumn).ForeColor = Color.Black
            e.Item.Cells(CriteriaColumn).Text = "TBD"
            e.Item.Cells(CriteriaColumn).BackColor = Color.White
            'no goal, but data
        ElseIf (IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria"))) Then
            e.Item.Cells(CriteriaColumn).Text = "TBD"
            e.Item.Cells(CriteriaColumn).BackColor = Color.White
            e.Item.Cells(CriteriaColumn).ForeColor = Color.Black
            'goal, but no data
        ElseIf (IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"))) Then
            e.Item.Cells(RatioColumn).Text = "TBD"
            e.Item.Cells(CriteriaColumn).ForeColor = Color.Black
            e.Item.Cells(CriteriaColumn).BackColor = Color.White
            'either goal and data, or not a scenario
        Else
            Dim Criteria As Double = CType(DataBinder.Eval(e.Item.DataItem, "criteria"), Double)
            'not a scenario
            If Criteria < 0.0 Then
                e.Item.Cells(RatioColumn).Text = "--"
                e.Item.Cells(CriteriaColumn).Text = "--"
                e.Item.Cells(CriteriaColumn).BackColor = Color.White
                e.Item.Cells(CriteriaColumn).ForeColor = Color.Black
            Else
                Dim Ratio As Double = CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double)
                If (Ratio < 0.75 * Criteria) Then
                    e.Item.Cells(CriteriaColumn).BackColor = Color.Red
                    e.Item.Cells(CriteriaColumn).ForeColor = Color.White
                ElseIf (Ratio < Criteria) Then
                    e.Item.Cells(CriteriaColumn).BackColor = Color.Yellow
                Else
                    e.Item.Cells(CriteriaColumn).BackColor = Color.Green
                    e.Item.Cells(CriteriaColumn).ForeColor = Color.White
                End If
            End If
        End If
    End Sub

    Private Sub RCThroughput_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RCThroughput.SelectedIndexChanged

    End Sub

    Private Sub RCMemory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RCMemory.SelectedIndexChanged

    End Sub

    Private Sub RCLatency_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RCLatency.SelectedIndexChanged

    End Sub

    Private Sub Datagrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RCThroughput2.SelectedIndexChanged

    End Sub

    Private Sub FTScorecards_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FTScorecards.SelectedIndexChanged

    End Sub
End Class

