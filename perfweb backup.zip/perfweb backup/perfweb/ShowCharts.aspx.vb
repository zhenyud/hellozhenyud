Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.McsMx.Web.Chart

Partial Class ShowCharts
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim chartStyle As String = Request.QueryString("Style").ToLower()

        If (chartStyle Is Nothing OrElse chartStyle.Length = 0) Then
            chartStyle = "Line"
        End If

        Dim engine As New ChartEngine
        engine.Size = New Size(600, 200)

        Dim wcCharts As New ChartCollection(engine)
        engine.Charts = wcCharts

        engine.ShowXValues = True
        engine.ShowYValues = True

        Dim lChart As LineChart
        Dim cChart As ColumnChart
        Dim goalChart As LineChart
        Dim ch As ChartLine

        Dim goalY As String
        Dim gY As Double

        goalY = Request.QueryString("goalY")

        Dim addGoalChart As Boolean = Not (goalY Is Nothing OrElse goalY.Length = 0)

        If addGoalChart Then
            gY = Convert.ToDouble(goalY)
            goalChart = New LineChart
            goalChart.Line.Color = Color.Red
            goalChart.ShowLegend = False
        End If

        If chartStyle = "line" Then
            lChart = New LineChart
            lChart.Line.Color = Color.Red
            lChart.ShowLegend = True
        ElseIf chartStyle = "column" Then
            cChart = New ColumnChart
            cChart.Line.Color = Color.LightGray
            cChart.Fill.Color = Color.Blue
            cChart.MaxColumnWidth = 30
            cChart.Line.Width = 1
            cChart.ShowLegend = True
        End If

        Dim x As String
        Dim y As String
        Dim xValues() As String
        Dim tempY() As String

        'x = Session("xValues") 'Request.QueryString("x")
        x = Request.QueryString("x")
        xValues = x.Split(",")

        'y = Session("yValues") 'Request.QueryString("y")
        y = Request.QueryString("y")
        tempY = y.Split(",")

        Dim tempString As String
        Dim i As Integer = 0
        Dim size As Integer = tempY.Length

        Dim yValues(size) As Double
        Dim maxValue As Double
        Dim minValue As Double

        If addGoalChart Then
            maxValue = gY
            minValue = gY
        Else
            maxValue = Convert.ToDouble(tempY(0))
            minValue = Convert.ToDouble(tempY(0))
        End If

        For Each tempString In tempY

            yValues(i) = Convert.ToDouble(tempY(i))

            If Not (maxValue > yValues(i)) Then
                maxValue = yValues(i)
            End If

            If (minValue > yValues(i)) Then
                minValue = yValues(i)
            End If

            'If size > 12 Then
            '    xValues(i) = xValues(i).Substring(2)
            'End If

            If chartStyle = "line" Then
                lChart.Data.Add(New ChartPoint(xValues(i), yValues(i)))
            ElseIf chartStyle = "column" Then
                cChart.Data.Add(New ChartPoint(xValues(i), yValues(i)))
            End If

            If addGoalChart Then
                goalChart.Data.Add(New ChartPoint(xValues(i), gY))
            End If

            i += 1
        Next

        engine.BottomChartPadding = 30

        ' Set X title
        'Dim xAxisTitle As String = Request.QueryString("XAxisTitle")

        'If (xAxisTitle <> "") Then

        '    engine.XTitle = New ChartText
        '    engine.XTitle.Font = New Font("Arial Narrow", 10, FontStyle.Regular)
        '    engine.XTitle.StringFormat.LineAlignment = StringAlignment.Far
        '    engine.XTitle.Text = xAxisTitle
        '    engine.XTitle.StringFormat.Alignment = StringAlignment.Center

        'End If

        Dim metric As String = Request.QueryString("metric")

        ' Set Y title
        engine.YTitle = New ChartText
        engine.YTitle.Font = New Font("Arial Narrow", 8, FontStyle.Regular)
        engine.YTitle.Text = metric
        engine.YTitle.StringFormat.Alignment = StringAlignment.Center
        engine.YTitle.StringFormat.FormatFlags = StringFormatFlags.DirectionVertical
        engine.LeftChartPadding = 60
        engine.YValuesFormat = "{0}"

        engine.YAxisFont = New ChartText
        engine.YAxisFont.Font = New Font("Arial Narrow", 8, FontStyle.Regular)
        engine.YAxisFont.StringFormat.LineAlignment = StringAlignment.Center
        engine.YAxisFont.StringFormat.Alignment = StringAlignment.Far

        engine.XAxisFont.Font = New Font("Arial Narrow", 8, FontStyle.Regular)

        Dim fudge As Integer = 1

        If size > 12 Then

            fudge = Math.Ceiling(size / 36)

            engine.Size = New Size(fudge * 600, 240)

            'If size > 36 Then
            '    engine.Size = New Size(1200, 240)
            'Else
            '    engine.Size = New Size(600, 240)
            'End If
            engine.BottomChartPadding = 70
            engine.XAxisFont.StringFormat.FormatFlags = StringFormatFlags.DirectionVertical
        End If

        Dim title As String = Request.QueryString("title")

        If (title <> "") Then
            engine.Title = New ChartText
            engine.Title.Font = New Font("Arial Narrow", 9, FontStyle.Regular)
            engine.Title.ForeColor = Color.Blue
            engine.Title.Text = title
            engine.Title.StringFormat.Alignment = StringAlignment.Near
            engine.TopChartPadding = 10
        End If

        'Find out scaling
        Dim scale As Double = 1

        Dim customEnd As Double
        Dim intervals As Integer
        Dim scaledMax = maxValue

        While (scaledMax > 1.0)
            scaledMax /= 10
            scale *= 10
        End While

        If (scaledMax > 0.8) Then
            customEnd = 1.0 * scale
            intervals = 5
        ElseIf (scaledMax > 0.6) Then
            customEnd = 0.8 * scale
            intervals = 4
        ElseIf (scaledMax > 0.5) Then
            customEnd = 0.6 * scale
            intervals = 6
        ElseIf (scaledMax > 0.4) Then
            customEnd = 0.5 * scale
            intervals = 5
        ElseIf (scaledMax > 0.3) Then
            customEnd = 0.4 * scale
            intervals = 4
        ElseIf (scaledMax > 0.2) Then
            customEnd = 0.3 * scale
            intervals = 6
        ElseIf (scaledMax < 0.0005) Then
            customEnd = 0.0005 * scale
            intervals = 5
        ElseIf (scaledMax < 0.001) Then
            customEnd = 0.001 * scale
            intervals = 5
        ElseIf (scaledMax < 0.003) Then
            customEnd = 0.003 * scale
            intervals = 6
        ElseIf (scaledMax < 0.006) Then
            customEnd = 0.006 * scale
            intervals = 6
        ElseIf (scaledMax < 0.12) Then
            customEnd = 0.15 * scale
            intervals = 6
        ElseIf (scaledMax < 0.15) Then
            customEnd = 0.2 * scale
            intervals = 6
        Else
            customEnd = 0.2 * scale
            intervals = 4
        End If

        engine.YCustomEnd = CType(customEnd, Single)
        engine.YCustomStart = 0.0
        engine.YValuesInterval = engine.YCustomEnd / intervals

        engine.Border.Color = Color.DarkKhaki
        engine.Background.Color = Color.Beige

        If chartStyle = "line" Then
            wcCharts.Add(lChart)
        ElseIf chartStyle = "column" Then
            wcCharts.Add(cChart)
        End If

        If addGoalChart Then
            wcCharts.Add(goalChart)
        End If

        Dim bmp As Bitmap
        Dim memStream As New System.IO.MemoryStream
        bmp = engine.GetBitmap()
        bmp.Save(memStream, System.Drawing.Imaging.ImageFormat.Png)

        Dim bits() As Byte = memStream.ToArray()
        Response.ContentType = "image/pjpeg"
        Response.BinaryWrite(bits)

    End Sub

End Class
