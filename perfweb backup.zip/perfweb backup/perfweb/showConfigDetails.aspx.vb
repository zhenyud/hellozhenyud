Imports System.Data
Imports System.Data.SqlClient

Partial Class showConfigDetails
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim configId As String
        configId = Request.QueryString("configId")
        Display(configId)

    End Sub

    Private Function Display(ByVal configId As Integer)

        Dim myConnection As SqlConnection
        Dim sqlCommand As SqlCommand
        Dim dr As SqlDataReader
        Dim dbXml() As Byte

        Response.ContentType = "text/xml"

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myConnection.Open()

        sqlCommand = New SqlCommand("P_GetMachineConfig", myConnection)
        sqlCommand.CommandType = CommandType.StoredProcedure
        sqlCommand.Parameters.Add(New SqlParameter("@machine_config_id", configId))
        dr = sqlCommand.ExecuteReader()

        While dr.Read()
            dbXml = CType(dr.Item("xml"), Byte())
            Response.BinaryWrite(dbXml)
        End While

    End Function

End Class
