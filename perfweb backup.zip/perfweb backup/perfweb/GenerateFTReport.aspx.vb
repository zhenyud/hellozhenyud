Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.McsMx.Web.Chart
Imports System.Collections

Partial Class GenerateFTReport
    Inherits System.Web.UI.Page

    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim teamId As Integer
    Dim selruns As String
    Dim throughputRuns As String
    Dim latencyRuns As String
    Dim selectedTests As String
    Dim throughputTests As String
    Dim latencyTests As String
    Dim goalRuns As String
    Dim featureTeam As String
    Protected WithEvents Table1 As System.Web.UI.WebControls.Table
    Protected WithEvents lblRun As System.Web.UI.WebControls.Label
    Dim clientOnlyTests As String


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        featureTeam = Request.QueryString("FT")
        teamId = GetTeamId()

        Dim latencyRuntypes As String = "97,109,100,71,120"
        latencyTests = GetSelectedTests(teamId, latencyRuntypes)

        Dim throughputRuntypes As String = "79,90,75,104"
        throughputTests = GetSelectedTests(teamId, throughputRuntypes)

        selruns = GetRuns()
        goalRuns = GetGoalRunIds()
        selruns = goalRuns + "," + selruns

        lblHeader.Text = "Current Status for " & featureTeam & " Feature Team"

        ShowRunsTable()
        ShowStatusSummaryTable()
        ShowCharts()

    End Sub

    Private Function GetTeamId() As String

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr As SqlDataReader

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            Dim sql As String
            sql = "select scenario_id from w_orcas_scorecards_progress_ogf where team in ('" & featureTeam & "')"

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextRunId As Integer

            While dr.Read()
                nextRunId = Convert.ToInt32(dr("scenario_id"))
                s += nextRunId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function GetSelectedTests(ByVal teamId As String, ByVal selectedRuntypes As String) As String

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr As SqlDataReader

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            Dim sql As String
            sql = "select distinct test_id from w_reportcard_variations where reportcard_id=120 "
            sql += "and runtype_id in (" & selectedRuntypes & ")"
            sql += "and scenario_id in ('" & teamId & "')"

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextTestId As Integer

            While dr.Read()
                nextTestId = Convert.ToInt32(dr("test_id"))
                s += nextTestId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function GetRuns() As String

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr1 As SqlDataReader
        Dim dr As SqlDataReader

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            Dim sql As String
            sql = "select indigo_run_id from w_reportcard_comparisons where reportcard_id=120 and scenario_id in ('" & teamId & "')"

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextRunId As Integer

            While dr.Read()
                nextRunId = Convert.ToInt32(dr("indigo_run_id"))
                s += nextRunId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function GetTests() As String

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr1 As SqlDataReader
        Dim dr As SqlDataReader

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            Dim sql As String
            sql = "select test_id from  w_reportcard_variations where reportcard_id=120 and scenario_id in ('" & teamId & "')"

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextTestId As Integer

            While dr.Read()
                nextTestId = Convert.ToInt32(dr("test_id"))
                s += nextTestId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function GetClientOnlyTests() As String
        'GET CLIENT ONLY TESTS
        'get tests using only role_id=1

        Dim sqlRole1 As String = "SELECT newruns.test_id FROM ( SELECT DISTINCT processes.role_id, jobruns.test_id"
        sqlRole1 += " FROM processes INNER JOIN jobruns ON jobruns.jobrun_id = processes.jobrun_id"
        sqlRole1 += String.Format(" WHERE processes.role_id IN ({0},{1},{2}) AND jobruns.run_id IN ({3}) AND jobruns.test_id IN ({4})", 1, 2, 9, selruns, selectedTests)
        sqlRole1 += " ) AS newruns GROUP BY newruns.test_id HAVING count(*) = 1"

        'txtException.Text = sqlRole1

        Dim clientOnlyTests As String = String.Empty

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sqlRole1, connection)

            dr = command.ExecuteReader()

            While dr.Read()
                clientOnlyTests += dr.Item("test_id") & ","
            End While

            If (Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0)) And clientOnlyTests.EndsWith(",") Then
                clientOnlyTests = clientOnlyTests.TrimEnd(",")
            End If

            'Session("clientOnlyTests") = clientOnlyTests
        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return clientOnlyTests

    End Function

    Private Function GetGoalRunIds() As String

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr1 As SqlDataReader
        Dim dr As SqlDataReader

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            Dim sql As String
            sql = "select distinct isnull(whidbey_run_id,0) as whidbey_run_id from w_reportcard_comparisons where reportcard_id=120 and scenario_id in ('" & teamId & "')"

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextRunId As Integer

            While dr.Read()
                nextRunId = Convert.ToInt32(dr("whidbey_run_id"))
                s += nextRunId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function ShowCharts()

        Dim selrunsArr() As String
        Dim selrunsCount As Integer = 0
        selrunsArr = selruns.Split(",")
        selrunsCount = selrunsArr.Length

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        Dim latencyTest As Boolean = False
        If Not (latencyTests Is Nothing OrElse latencyTests.Length = 0) Then
            latencyTest = True
        End If

        sql = "SELECT d.testcase, d.run, "
        sql += " d.run_id, d.test, d.test_id, d.labconfig_id, d.measured_value, d.base_measured_value, d.goal, d.deltaNormalized,"
        sql += " d.role_id, d.role, d.variation, d.metric"
        sql += " FROM w_orcas_featureteams_scorecard_data_snapshot_test4 d "
        sql += " WHERE d.team_id=" & teamId
        sql += " ORDER BY d.testcase, d.test, d.role_id, d.variation, d.metric, d.run_id"

        'sql = "SELECT DISTINCT (runs.run + ' (' + cast(runs.run_id as char(5)) + ')') as run, runs.run_id, tests.test, jobruns.test_id, measurements.measured_value, processes.process_id, processes.role_id, variations.variation"
        'sql += ", roles.role, metrics.metric"
        'sql += " FROM runs INNER JOIN jobruns ON jobruns.run_id = runs.run_id"
        'sql += " INNER JOIN tests ON tests.test_id = jobruns.test_id"
        'sql += " INNER JOIN processes ON processes.jobrun_id = jobruns.jobrun_id"
        'sql += " INNER JOIN measurements ON measurements.process_id = processes.process_id"
        'sql += " INNER JOIN variations ON variations.variation_id = processes.variation_id"
        'sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
        'sql += " INNER JOIN roles on roles.role_id = processes.role_id WHERE "

        'Dim sql3 As String = String.Empty
        'sql3 = "(jobruns.validity = 4) AND "

        'Dim sql1 As String 'runs with role_id only=1
        'Dim sql2 As String 'runs with role_id=2 or role_id=9
        'Dim clause1 As String
        'Dim clause2 As String

        'If latencyTest Then
        '    clause1 = "(metrics.metric in ('AverageLatency'))"
        '    sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3}, {4})) ", latencyTests, selruns, clause1, 1, 9)
        'End If

        'clause2 = "((measurements.metric_id = 56))"
        'sql1 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3}, {4})) ", throughputTests, selruns, clause2, 2, 9)

        ''sql1 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3})) ", "857", selruns, 56, 2)

        'If latencyTest Then
        '    sql = sql & "(" & sql1 & ") OR (" & sql2 & ")"
        'Else
        '    sql = sql & sql1
        'End If

        'sql += " ORDER BY tests.test, processes.role_id, variations.variation, metrics.metric, runs.run_id, processes.process_id"

        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        command = New SqlCommand(sql, connection)
        command.CommandTimeout = 120

        dr = command.ExecuteReader()

        Dim lastVariation As String
        lastVariation = String.Empty

        Dim lastTest As String
        lastTest = String.Empty

        Dim lastLabconfigId As String
        lastLabconfigId = String.Empty

        Dim lastRole As String
        lastRole = String.Empty

        Dim lastMetric As String
        lastMetric = String.Empty

        Dim lastGoal As String
        lastGoal = String.Empty

        Dim lastDelta As String
        lastDelta = String.Empty

        Dim i As Integer = 0

        Dim test As String
        Dim run As String
        Dim labconfig_id As String
        Dim variation As String
        Dim result As Double
        Dim run_id As String
        Dim role As String
        Dim metric As String
        Dim baseResult As Double
        Dim previousBaseResult As Double
        Dim delta As Double
        Dim goal As Integer

        Dim xValues As String = String.Empty
        Dim yValues As String = String.Empty

        While dr.Read()

            test = CType(dr.Item("test"), String)
            variation = CType(dr.Item("variation"), String)
            run = CType(dr.Item("run"), String)
            labconfig_id = CType(dr.Item("labconfig_id"), String)
            result = CType(dr.Item("measured_value"), Double)
            If Not IsDBNull(dr.Item("base_measured_value")) Then
                baseResult = CType(dr.Item("base_measured_value"), Double)
            Else
                baseResult = 0.0
            End If

            If Not IsDBNull(dr.Item("deltaNormalized")) Then
                delta = CType(dr.Item("deltaNormalized"), Double)
            Else
                delta = 0.0
            End If

            goal = CType(dr.Item("goal"), Integer)
            run_id = CType(dr.Item("run_id"), String)
            role = CType(dr.Item("role"), String)
            metric = CType(dr.Item("metric"), String)

            If i = 0 Then
                lastVariation = variation
                lastLabconfigId = labconfig_id
                lastTest = test
                lastRole = role
                lastMetric = metric
                lastGoal = goal
                lastDelta = delta

                i += 1
            End If

            If (variation <> lastVariation Or test <> lastTest Or role <> lastRole Or metric <> lastMetric Or labconfig_id <> lastLabconfigId) Then

                xValues = "Goal," & xValues
                yValues = previousBaseResult & "," & yValues
                xValues = xValues.TrimEnd(",") 'Substring(0, xValues.Length - 1)
                yValues = yValues.TrimEnd(",") 'Substring(0, yValues.Length - 1)

                lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")
                'labconfig = labconfig.Replace("processor", "proc").Replace("server", "svr")

                If lastLabconfigId = "131" Then
                    lastTest = lastTest + ".VISTA"
                End If

                AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, lastDelta, lastGoal)

                lastVariation = variation
                lastLabconfigId = labconfig_id
                lastTest = test
                lastRole = role
                lastMetric = metric
                lastGoal = goal.ToString()
                lastDelta = delta.ToString()

                xValues = ""
                yValues = ""

            End If

            'If goalRuns.IndexOf(run_id) >= 0 Then
            '    xValues = run & "," & xValues
            '    yValues = result & "," & yValues
            'Else
            '    xValues += run & ","
            '    yValues += result & ","
            'End If

            xValues += run & ","
            yValues += result & ","

            previousBaseResult = baseResult
            lastGoal = goal.ToString()
            lastDelta = delta.ToString()

        End While

        If (xValues <> Nothing And xValues.Length > 0) And xValues.EndsWith(",") Then
            xValues = "Goal," & xValues
            xValues = xValues.TrimEnd(",")
        End If

        If (yValues <> Nothing And yValues.Length > 0) And yValues.EndsWith(",") Then
            yValues = previousBaseResult & "," & yValues
            yValues = yValues.TrimEnd(",")
        End If

        If (lastTest <> Nothing And lastTest.Length > 0) Then
            lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")
        End If
        'labconfig = labconfig.Replace("processor", "proc").Replace("Server", "svr")

        If Not (lastRole Is Nothing OrElse lastRole.Length = 0) Then
            If lastLabconfigId = "131" Then
                lastTest = lastTest + ".VISTA"
            End If

            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, lastDelta, lastGoal)
        End If
    End Function

    Private Function ShowStatusSummaryTable()
        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        tblStatusSummary.CellPadding = 3
        tblStatusSummary.CellSpacing = 0
        tblStatusSummary.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblStatusSummary.BorderStyle = BorderStyle.Solid
        tblStatusSummary.GridLines = System.Web.UI.WebControls.GridLines.Both
        tblStatusSummary.BorderWidth = Unit.Pixel(3)

        Dim totalTestCases As String = "<b># of Test Cases</b>"
        Dim totalMissingGoals As String = "<b># of Missing Goals</b>"
        Dim totalRegressionsOver10 As String = "<b># Below Goals >= 5%</b>"

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(totalTestCases, row)
        AddSimpleCell(totalMissingGoals, row)
        AddSimpleCell(totalRegressionsOver10, row)
        tblStatusSummary.Rows.Add(row)

        Dim totCases As Integer = 0
        Dim totMissing As Integer = 0
        Dim totRegressions As Integer = 0

        'sql = "select distinct testcase,deltaNormalized from w_orcas_featureteams_scorecard_data_snapshot_test4 "
        'sql += "where run_id in ("
        'sql += "select max(run_id) as run_id from w_orcas_featureteams_scorecard_data_snapshot_test4 "
        'sql += "where team_id=" & teamId & " and run_id <> 0"
        'sql += " group by testcase) and team_id=" & teamId
        'sql += " order by testcase"

        sql = "select distinct t4.testcase,t4.run_id,t4.deltaNormalized "
        sql += "from w_orcas_featureteams_scorecard_data_snapshot_test4 as t4 "
        sql += "inner join (select max(run_id)as run_id,max(testcase) as testcase "
        sql += "from w_orcas_featureteams_scorecard_data_snapshot_test4 "
        sql += "where team_id=" & teamId '& "-- and run_id <> 0 "
        sql += " group by testcase) as r "
        sql += "on r.run_id=t4.run_id and r.testcase=t4.testcase "
        sql += "where team_id=" & teamId & " order by t4.testcase"

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim delta As String
            Dim deltaValue As Double

            While dr.Read()

                totCases += 1

                If Not (IsDBNull(dr.Item("deltaNormalized"))) Then

                    deltaValue = CType(dr.Item("deltaNormalized"), Double)
                    delta = CType(dr.Item("deltaNormalized"), String)

                    If Not (delta Is Nothing OrElse delta.Length = 0) Then
                        'deltaValue = Convert.ToDouble(delta)
                        If deltaValue < -5 Then
                            totRegressions += 1
                        End If
                    End If

                Else
                    totMissing += 1
                End If

            End While

            row = New System.Web.UI.WebControls.TableRow

            AddSimpleCell(totCases.ToString(), row)
            AddSimpleCell(totMissing.ToString(), row)
            AddSimpleCell(totRegressions.ToString(), row)
            tblStatusSummary.Rows.Add(row)

        Catch ex As Exception
            Throw

        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function

    Private Function ShowRunsTable()

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        tblRunsData.CellPadding = 3
        tblRunsData.CellSpacing = 0
        tblRunsData.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblRunsData.BorderStyle = BorderStyle.Solid
        tblRunsData.GridLines = System.Web.UI.WebControls.GridLines.Both
        tblRunsData.BorderWidth = Unit.Pixel(3)

        Dim runId As String = "<b>Run ID</b>"
        Dim run As String = "<b>Run</b>"
        Dim runtype As String = "<b>Run Category</b>"
        Dim wcfBuild As String = "<b>WCF Build</b>"
        Dim netfxBuild As String = "<b>Netfx3.5 Build</b>"
        Dim wfBuild As String = "<b>WF Build</b>"
        Dim runDate As String = "<b>Date</b>"

        sql = "select r.run_id,r.run,rt.runtype,b.build as WCF_build,nb.netfxbuild as Netfx35_build,wb.wfbuild as WF_build,r.start_date"
        sql += " from runs r inner join builds b on r.build_id=b.build_id "
        sql += " inner join netfxbuilds nb on r.netfxbuild_id=nb.netfxbuild_id"
        sql += " inner join wfbuilds wb on r.wfbuild_id=wb.wfbuild_id"
        sql += " inner join runtypes rt on r.runtype_id=rt.runtype_id"
        sql += " where run_id in (" + selruns + ")"
        sql += " order by rt.runtype,r.run_id desc "

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            AddRowToRunsTable(runId, run, runtype, wcfBuild, netfxBuild, wfBuild, runDate)

            While dr.Read()

                runId = CType(dr.Item("run_id"), String)
                runId = String.Format("<a href=explorer.aspx?rc=1&rid1={0}>{0}</a>", runId)
                run = CType(dr.Item("run"), String)
                runtype = CType(dr.Item("runtype"), String)
                wcfBuild = CType(dr.Item("wcf_build"), String)
                netfxBuild = CType(dr.Item("netfx35_build"), String)
                wfBuild = CType(dr.Item("WF_build"), String)
                runDate = CType(dr.Item("start_date"), String)

                AddRowToRunsTable(runId, run, runtype, wcfBuild, netfxBuild, wfBuild, runDate)

            End While
        Catch ex As Exception

        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function


    Private Function AddRowToRunsTable(ByVal runId As String, ByVal run As String, ByVal runtype As String, ByVal wcfBuild As String, ByVal netfxBuild As String, ByVal wfBuild As String, ByVal runDate As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(runId, row)
        'AddSimpleCell(run, row)
        AddSimpleCell(runtype, row)
        AddSimpleCell(wcfBuild, row)
        AddSimpleCell(wfBuild, row)
        AddSimpleCell(netfxBuild, row)
        AddSimpleCell(runDate, row)

        tblRunsData.Rows.Add(row)

    End Function


    Private Function Add2Cells(ByVal cell1 As String, ByVal cell2 As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(cell1, row)
        AddSimpleCell(cell2, row)

        tblCharts.Rows.Add(row)

    End Function

    Private Function AddSimpleCell(ByVal item As String, ByRef row As TableRow)
        Dim cell As TableCell = New System.Web.UI.WebControls.TableCell
        cell.Text = item
        row.Cells.Add(cell)
    End Function

    Private Function AddValuesRow(ByVal x As String, ByVal y As String, ByVal goalX As String, ByVal goalY As String, ByVal metric As String, ByVal goalYRaw As String, ByVal goal As String, ByVal delta As String)

        Dim tbl As Table = New Table

        tbl.CellPadding = 3
        tbl.CellSpacing = 0
        tbl.BorderColor = Color.FromArgb(13421721) '#cccc99
        tbl.BorderStyle = BorderStyle.Solid
        tbl.GridLines = System.Web.UI.WebControls.GridLines.Both
        tbl.BorderWidth = Unit.Pixel(1)

        Dim cell As TableCell
        Dim row As TableRow

        Dim xArray As ArrayList

        Dim xArr() As String
        xArr = x.Split(",")

        Dim yArr() As String
        yArr = y.Split(",")

        row = New System.Web.UI.WebControls.TableRow

        cell = New System.Web.UI.WebControls.TableCell
        cell.Font.Size = FontUnit.XXSmall
        cell.Text = "<b>Goal</b>"
        cell.BackColor = Color.FromArgb(13421721)
        row.Cells.Add(cell)

        Dim k As Integer = 0

        While k < xArr.Length
            cell = New System.Web.UI.WebControls.TableCell
            cell.Font.Size = FontUnit.XXSmall

            cell.Text = xArr(k)

            row.Cells.Add(cell)

            k += 1
        End While

        cell = New System.Web.UI.WebControls.TableCell
        cell.Font.Size = FontUnit.XXSmall
        cell.Text = "Delta"
        row.Cells.Add(cell)

        tbl.Rows.Add(row)

        row = New System.Web.UI.WebControls.TableRow

        cell = New System.Web.UI.WebControls.TableCell
        cell.Font.Size = FontUnit.XXSmall
        'cell.Text = "<b>" & yArr(k) & "</b>"
        cell.Text = "<b>" & goalY & "</b>"
        cell.ToolTip = "Goal: " & goal & "% of " & goalYRaw
        row.Cells.Add(cell)

        k = 0

        While k < xArr.Length
            cell = New System.Web.UI.WebControls.TableCell
            cell.Font.Size = FontUnit.XXSmall

            cell.Text = yArr(k)

            row.Cells.Add(cell)

            k += 1
        End While

        'Dim delta As Double = 100.0 - (Convert.ToDouble(yArr(0)) / Convert.ToDouble(yArr(k - 1))) * 100
        Dim higherIsBetter As Boolean = (metric = "Throughput")
        'If Not higherIsBetter Then
        '    delta = -1.0 * delta
        'End If

        Dim deltaValue As String = System.Math.Round(Convert.ToDouble(delta), 2).ToString()

        cell = New System.Web.UI.WebControls.TableCell
        cell.Text = deltaValue & "%"
        If System.Math.Abs(Convert.ToDouble(delta)) >= 5.0 Then
            If delta > 0 Then
                cell.BackColor = Color.Green
            Else
                cell.BackColor = Color.Red
            End If
            cell.ForeColor = Color.White
        End If

        If Convert.ToDouble(goalY) = 0.0 Then 'yArr(0) = 0.0 Then
            cell.BackColor = Color.Red
        End If

        row.Cells.Add(cell)

        tbl.Rows.Add(row)

        row = New System.Web.UI.WebControls.TableRow
        cell = New System.Web.UI.WebControls.TableCell
        cell.Controls.Add(tbl)
        cell.ColumnSpan = 2
        row.Cells.Add(cell)

        tblCharts.Rows.Add(row)

    End Function

    Private Function AddChartCell(ByVal lastRole As String, ByVal lastTest As String, ByVal lastVariation As String, ByVal lastMetric As String, ByVal x As String, ByVal y As String, ByVal delta As String, ByVal goal As String)

        Dim title As String
        Dim roleInfo1 As String
        Dim roleInfo2 As String
        Dim testInfo1 As String
        Dim testInfo2 As String
        Dim variationInfo1 As String
        Dim variationInfo2 As String

        Dim cell As TableCell
        Dim row As TableRow

        'title = lastRole & " -- " & lastTest & " - " & lastVariation

        'roleInfo1 = "<b>Role:  </b>"
        'roleInfo2 = lastRole
        'Add2Cells(roleInfo1, roleInfo2)

        testInfo1 = "<b>Test:  </b>"
        testInfo2 = lastTest
        Add2Cells(testInfo1, testInfo2)

        variationInfo1 = "<b>Variation:  </b>"
        variationInfo2 = lastVariation
        Add2Cells(variationInfo1, variationInfo2)

        'Dim xArr() As String = x.Split(",")

        Dim goalX As String

        If x.IndexOf(",") > 0 Then
            goalX = x.Substring(0, x.IndexOf(",")) 'remove the first element==goal => not needed
            x = x.Substring(x.IndexOf(",") + 1)
        End If

        Dim goalY As String = String.Empty
        Dim goalYRaw As String = String.Empty
        Dim goalYValue As Double

        If y.IndexOf(",") > 0 Then
            goalYRaw = y.Substring(0, y.IndexOf(",")) 'remove the first element==goal => will set as a goal in chart
            goalYValue = Convert.ToDouble(goalYRaw) * Convert.ToDouble(goal) / 100.0
            goalY = goalYValue.ToString()
            y = y.Substring(y.IndexOf(",") + 1)
        End If

        AddValuesRow(x, y, goalX, goalY, lastMetric, goalYRaw, goal, delta)

        cell = New System.Web.UI.WebControls.TableCell
        row = New System.Web.UI.WebControls.TableRow

        cell.ColumnSpan = 2
        If goalY <> String.Empty Then
            cell.Text = "<img src='ShowCharts.aspx?x=" & x & "&y=" & y & "&Title=" & title & "&Metric=" & lastMetric & "&Style=Column&goalY=" & goalY & "'>"
        Else
            cell.Text = "<img src='ShowCharts.aspx?x=" & x & "&y=" & y & "&Title=" & title & "&Metric=" & lastMetric & "&Style=Column'>"
        End If

        row.Cells.Add(cell)
        tblCharts.Rows.Add(row)
    End Function
End Class
