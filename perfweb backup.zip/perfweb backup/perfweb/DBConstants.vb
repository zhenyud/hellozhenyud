Public Enum Metrics
    Throughput = 56
End Enum
Public Enum Roles
    Server = 2
    InProc = 9
End Enum