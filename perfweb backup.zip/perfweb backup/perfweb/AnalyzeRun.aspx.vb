Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.McsMx.Web.Chart
Imports System.Collections
Imports System.Math
Imports System.Net.Mail

Partial Class RunAnalysis
    Inherits System.Web.UI.Page

    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim runId As Integer
    Dim runtype As String
    Dim runtype_id As String 'add for RPS
    Dim count As String
    Dim analyzeRPSrun As Boolean = False 'add for RPS, analyze run after run finished
    Dim showRPSchart As Boolean = False 'add for view RPS regressiosn
    Dim comparePrevious As Integer = 5 'add for view RPS regresion only compare with previous run, value 1 means compare with previous one
    Dim testId As String
    Dim testName As String
    Dim selruns As String
    Dim selectedTests As String = testId
    Dim showForward As Integer = 0
    Dim threshold As Double = 5.0
    Dim unstabilityCoefficient As Double = 0.3 ' ratio of (# of high deltas)/(# of data points)
    Dim noiseCoefficient As Double = 0.3 ' what we consider a noise
    Dim leftWindowInterval As Integer = 3
    Dim rightWindowInterval As Integer = 2

    Protected WithEvents Table1 As System.Web.UI.WebControls.Table
    Protected WithEvents lblRun As System.Web.UI.WebControls.Label
    Dim clientOnlyTests As String


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        runId = Request.QueryString("runid")
        count = Request.QueryString("count")
        testId = Request.QueryString("testId")
        testName = Request.QueryString("testName")

        'add for RPS analyze run when run finish
        If Not (Request.QueryString("analyzeRPSrun") Is Nothing Or Request.QueryString("analyzeRPSrun") = String.Empty) Then
            If Request.QueryString("analyzeRPSrun").Equals("true") Then
                analyzeRPSrun = True
            End If
        End If
        If Not (Request.QueryString("showRPSchart") Is Nothing Or Request.QueryString("analyzeRPSrun") = String.Empty) Then
            If Request.QueryString("showRPSchart").Equals("true") Then
                showRPSchart = True
            End If
        End If
        If Not (Request.QueryString("compare") Is Nothing Or Request.QueryString("compare") = String.Empty) Then
            comparePrevious = Integer.Parse(Request.QueryString("compare"))
        End If
        'add for analyze RPS run after run is finished
        If analyzeRPSrun Then
            count = 11
            threshold = 6.0
        End If

        If Not (Request.QueryString("t") Is Nothing Or Request.QueryString("t") = String.Empty) Then
            threshold = Request.QueryString("t")
        End If

        If Not (Request.QueryString("uc") Is Nothing Or Request.QueryString("uc") = String.Empty) Then
            unstabilityCoefficient = Request.QueryString("uc")
        End If

        If Not (Request.QueryString("noise") Is Nothing Or Request.QueryString("noise") = String.Empty) Then
            noiseCoefficient = Request.QueryString("n")
        End If

        If Not (Request.QueryString("lw") Is Nothing Or Request.QueryString("lw") = String.Empty) Then
            leftWindowInterval = Request.QueryString("lw")
        End If

        If Not (Request.QueryString("rw") Is Nothing Or Request.QueryString("rw") = String.Empty) Then
            rightWindowInterval = Request.QueryString("rw")
        End If

        selectedTests = testId

        Dim showForwardField As String = Request.QueryString("showForward")

        If Not showForwardField Is Nothing And showForwardField <> String.Empty Then
            showForward = Convert.ToInt32(showForwardField)
        End If

        selruns = GetRuns()

        'disable this for RPS
        If Not runtype_id = "182" Then
            clientOnlyTests = GetClientOnlyTests()
        End If

        If testName <> "-1" Then
            lblHeader.Text = "Trend for the last " + count.ToString() + " runs of " + testName
        End If

        'ShowRunsTable()
        'ShowRunsStats()

        'change for RPS
        If analyzeRPSrun Then
            AnalyzeRPS()
        Else
            ShowCharts()
        End If


    End Sub

    Private Function GetRuns() As String
        Dim selruns As String = String.Empty

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr1 As SqlDataReader
        Dim dr As SqlDataReader
        Dim sql As String

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            sql = "select r.runtype_id,r.labconfig_id,rt.runtype from runs r"
            sql += " inner join runtypes rt on rt.runtype_id=r.runtype_id"
            sql += " where r.run_id=" & runId

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            Dim labconfig_id As String
            'change it to global variable for RPS
            'Dim runtype_id As String

            dr1 = command.ExecuteReader()

            While dr1.Read()
                runtype_id = Convert.ToString(dr1("runtype_id"))
                labconfig_id = Convert.ToString(dr1("labconfig_id"))
                runtype = Convert.ToString(dr1("runtype"))
            End While

            dr1.Close()

            Dim relatedRuntypes As String

            ' related runtypes where confusing to some people, so I'm temporarily disabling them -- RK 070619
            If runtype_id = "90" Then 'V1_FT
                relatedRuntypes = "90" ',75,116" ' 75=Indigo_FeatureTeams_WAP, 116 V1_FT_Whidbey
            ElseIf runtype_id = "100" Then 'V1_Latency
                relatedRuntypes = "100" ',71" ' 75=Indigo_Latency_WAP
            ElseIf runtype_id = "91" Then 'V1_Startup
                relatedRuntypes = "91" ' ,66" ' 66=Indigo_Startup_WAP
            Else
                relatedRuntypes = runtype_id
            End If

            sql = "select distinct top " & count & " r.run_id from runs r "
            sql += "inner join jobruns j on r.run_id=j.run_id "
            sql += "where r.runtype_id in (" & relatedRuntypes & ") "
            sql += "and r.labconfig_id=" & labconfig_id

            If showForward = 1 Then
                sql += " and r.start_date >= (select start_date from runs where run_id=" & runId & ") "
            Else
                sql += " and r.start_date <= (select start_date from runs where run_id=" & runId & ") "
            End If


            'add for RPS
            If runtype_id = "182" Then
                sql = "select distinct top " & count & " r.run_id, t.createtime from (runs r "
                sql += "inner join jobruns j on r.run_id=j.run_id) "
                sql += "inner join RPS_testRun t on r.run_id=t.labRunId "
                sql += "where r.runtype_id in (" & relatedRuntypes & ") "
                sql += "and r.labconfig_id=" & labconfig_id

                If showForward = 1 Then
                    sql += " and t.createtime >= (select createtime from RPS_testRun where labRunId=" & runId & ") "
                Else
                    sql += " and t.createtime <= (select createtime from RPS_testRun where labRunId=" & runId & ") "
                End If
            End If

            If selectedTests <> "-1" Then
                sql += " and j.test_id in (" & selectedTests & ") "
            End If

            'add for RPS
            If runtype_id = "182" Then
                sql += " order by t.createtime desc"
            Else
                sql += " order by r.run_id desc"
            End If


            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextRunId As Integer

            While dr.Read()
                nextRunId = Convert.ToInt32(dr("run_id"))
                s += nextRunId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

            selruns = s

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function GetClientOnlyTests() As String
        'GET CLIENT ONLY TESTS
        'get tests using only role_id=1

        Dim sqlRole1 As String = "SELECT newruns.test_id FROM ( SELECT DISTINCT processes.role_id, jobruns.test_id"
        sqlRole1 += " FROM processes INNER JOIN jobruns ON jobruns.jobrun_id = processes.jobrun_id"
        sqlRole1 += String.Format(" WHERE processes.role_id IN ({0},{1},{2}) AND jobruns.run_id IN ({3}) ", 1, 2, 9, selruns)

        If selectedTests <> -1 Then
            sqlRole1 += String.Format(" AND jobruns.test_id IN ({0})", selectedTests)
        End If

        sqlRole1 += " ) AS newruns GROUP BY newruns.test_id HAVING count(*) = 1"

        'txtException.Text = sqlRole1

        Dim clientOnlyTests As String = String.Empty

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sqlRole1, connection)

            dr = command.ExecuteReader()

            While dr.Read()
                clientOnlyTests += dr.Item("test_id") & ","
            End While

            If (Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0)) And clientOnlyTests.EndsWith(",") Then
                clientOnlyTests = clientOnlyTests.TrimEnd(",")
            End If

            'Session("clientOnlyTests") = clientOnlyTests
        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return clientOnlyTests

    End Function

    Private Function ShowCharts()

        Dim selrunsArr() As String
        Dim selrunsCount As Integer = 0
        selrunsArr = selruns.Split(",")
        selrunsCount = selrunsArr.Length

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        Dim summary As String = String.Empty
        Dim chkSummary As Boolean = False
        summary = Request.QueryString("summary")
        If Not (summary Is Nothing OrElse summary.Length = 0) Then
            chkSummary = Boolean.Parse(summary)
        End If

        Dim memoryTest As Boolean = False
        Dim refsetTest As Boolean = False
        Dim latencyTest As Boolean = False

        If Not (runtype Is Nothing OrElse runtype.Length = 0) Then
            memoryTest = runtype.ToLower().IndexOf("memory") >= 0
            refsetTest = runtype.ToLower().IndexOf("refset") >= 0
            latencyTest = runtype.ToLower().IndexOf("latency") >= 0 Or runtype.ToLower().IndexOf("startup") >= 0
        End If

        Dim newRunnames As String = String.Empty
        Dim newRunnamesArr() As String
        Dim newRunnamesCount As Integer = 0
        newRunnames = CType(Session("newRunnames"), String)

        If Not (newRunnames Is Nothing OrElse newRunnames.Length = 0) Then
            newRunnamesArr = newRunnames.Split(",")
            newRunnamesCount = newRunnamesArr.Length
        End If

        Dim runs As New Hashtable
        Dim k As Integer = 0

        If selrunsCount = newRunnamesCount Then
            While k < selrunsArr.Length
                runs.Add(selrunsArr(k), newRunnamesArr(k))
                k += 1
            End While
        End If

        sql = "SELECT DISTINCT runs.run, runs.run_id, tests.test, jobruns.test_id, measurements.measured_value, processes.process_id, processes.role_id, variations.variation"
        sql += ", roles.role, metrics.metric"
        sql += " FROM runs INNER JOIN jobruns ON jobruns.run_id = runs.run_id"
        sql += " INNER JOIN tests ON tests.test_id = jobruns.test_id"
        sql += " INNER JOIN processes ON processes.jobrun_id = jobruns.jobrun_id"
        sql += " INNER JOIN measurements ON measurements.process_id = processes.process_id"
        sql += " INNER JOIN variations ON variations.variation_id = processes.variation_id"
        sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
        sql += " INNER JOIN roles on roles.role_id = processes.role_id WHERE "

        'add for RPS run
        If runtype_id = "182" Then
            sql = "SELECT DISTINCT runs.run, runs.run_id, RPS_testRun.createtime, tests.test, jobruns.test_id, measurements.measured_value, processes.process_id, processes.role_id, variations.variation"
            sql += ", roles.role, metrics.metric"
            sql += " FROM runs INNER JOIN jobruns ON jobruns.run_id = runs.run_id"
            sql += " INNER JOIN tests ON tests.test_id = jobruns.test_id"
            sql += " INNER JOIN RPS_testRun on runs.run_id=RPS_testRun.labRunId "
            sql += " INNER JOIN processes ON processes.jobrun_id = jobruns.jobrun_id"
            sql += " INNER JOIN measurements ON measurements.process_id = processes.process_id"
            sql += " INNER JOIN variations ON variations.variation_id = processes.variation_id"
            sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
            sql += " INNER JOIN roles on roles.role_id = processes.role_id WHERE "
        End If

        Dim sql3 As String = String.Empty
        If Not chkSummary Then
            sql3 = "(jobruns.validity = 4) AND "
        End If

        Dim sql1 As String 'runs with role_id only=1
        Dim sql2 As String 'runs with role_id=2 or role_id=9
        Dim clause As String
        Dim testClause As String

        If selectedTests <> -1 Then
            testClause = String.Format("(jobruns.test_id IN ({0})) AND ", selectedTests)
        Else
            testClause = ""
        End If

        If memoryTest Then
            clause = "(metrics.metric like '%Module Count%' OR metrics.metric like '%Thread Count%' OR metrics.metric like '%Working Set%')"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 1, 2)
        ElseIf refsetTest Then
            clause = "(metrics.metric like '%UniqueFileBacked%' OR metrics.metric like '%PeakDynamic%')"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 1, 9)
        ElseIf latencyTest Then
            'clause = "(metrics.metric in ('AverageLatency','95thPercentileLatency'))"
            clause = "(metrics.metric in ('AverageLatency'))"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3}, {4})) ", selruns, clause, 1, 2, 9)
        Else
            clause = "(measurements.metric_id = 56)"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 2, 9)
        End If

        'sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3}, {4})) ", Session("SelectedTests"), selruns, 56, 2, 9)
        sql1 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3})) ", clientOnlyTests, selruns, 56, 1)

        If Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0) Then
            sql = sql & "(" & sql1 & ") OR (" & sql2 & ")"
        Else
            sql = sql & sql2
        End If

        'add for RPS run
        If runtype_id = "182" Then
            sql += " ORDER BY tests.test, processes.role_id, variations.variation, metrics.metric, RPS_testRun.createtime, processes.process_id"
        Else
            sql += " ORDER BY tests.test, processes.role_id, variations.variation, metrics.metric, runs.run_id, processes.process_id"
        End If


        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        command = New SqlCommand(sql, connection)
        command.CommandTimeout = 120

        dr = command.ExecuteReader()

        Dim lastVariation As String
        lastVariation = String.Empty

        Dim lastTest As String
        lastTest = String.Empty

        Dim lastRole As String
        lastRole = String.Empty

        Dim lastMetric As String
        lastMetric = String.Empty

        Dim i As Integer = 0

        Dim test As String
        Dim run As String
        Dim variation As String
        Dim result As Double
        Dim run_id As String
        Dim role As String
        Dim metric As String

        Dim xValues As String = String.Empty
        Dim yValues As String = String.Empty

        Dim changeRunname As Boolean = (Not (newRunnames Is Nothing OrElse newRunnames.Length = 0)) And (selrunsCount = newRunnamesCount)

        Dim deltaSum As Double
        Dim average As Double
        Dim stdev As Double

        Dim isUnstable As Boolean
        Dim regressions As String
        Dim improvements As String

        Dim filter As Double = 5.0
        Dim newYValues As String
        Dim newLastRole As String

        Dim yV() As String
        Dim xV() As String
        Dim x As Double


        Dim j As Integer = 0
        Dim h As Integer

        While dr.Read()

            test = CType(dr.Item("test"), String)
            variation = CType(dr.Item("variation"), String)
            run = CType(dr.Item("run"), String)
            result = CType(dr.Item("measured_value"), Double)
            run_id = CType(dr.Item("run_id"), String)
            role = CType(dr.Item("role"), String)
            metric = CType(dr.Item("metric"), String)

            If i = 0 Then
                lastVariation = variation
                lastTest = test
                lastRole = role
                lastMetric = metric

                i += 1
            End If

            If (variation <> lastVariation Or test <> lastTest Or role <> lastRole Or metric <> lastMetric) Then

                xValues = xValues.Substring(0, xValues.Length - 1)
                yValues = yValues.Substring(0, yValues.Length - 1)
                lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")

                'CalculateStatistics(yValues, average, deltaSum, stdev)
                'AnalyzeData(yValues, lastMetric, isUnstable, containsRegression, containsPotentialRegression, containsImprovement)
                'lastRole = lastRole & " REGRESSIONS " & xValues '& " -- Sum=" & deltaSum.ToString() & " Avg=" & average & " stdev=" & stdev

                newYValues = FilterOutSpikes(yValues, filter)
                AnalyzeData(newYValues, lastMetric, isUnstable, regressions, improvements)

                Dim newLastRoleForRegressions As String
                newLastRole = lastRole

                newLastRoleForRegressions = lastRole

                If Not regressions Is Nothing And regressions <> String.Empty Then
                    yV = regressions.Split(",")
                    xV = xValues.Split(",")
                    'lastRole = lastRole & " REGRESSIONS: " & xValues
                    'newLastRole = lastRole & " REGRESSIONS: " & regressions

                    j = 0
                    h = 0

                    While j < yV.Length
                        h = Convert.ToInt32(yV(j))
                        newLastRoleForRegressions = newLastRoleForRegressions & " " & xV(h) & ", "
                        j += 1
                    End While
                End If
                'CalculateStatistics(newYValues, average, deltaSum, stdev)
                'newLastRole = lastRole '& " -- Sum=" & deltaSum.ToString() & " Avg=" & average & " stdev=" & stdev

                If isUnstable = True Then
                    'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblUnstableTests)
                    AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblUnstableTests)
                ElseIf Not regressions Is Nothing And regressions <> String.Empty Then
                    'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
                    'newLastRole = lastRole & " REGRESSIONS: " & regressions
                    AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblRegressions, regressions)
                ElseIf Not improvements Is Nothing And improvements <> String.Empty Then
                    'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblImprovements)
                    'newLastRole = lastRole & " IMPROVEMENTS: " & improvements
                    AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblImprovements, improvements)
                Else
                    'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblConstantTests)
                    AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblConstantTests)
                End If

                deltaSum = 0.0
                average = 0.0
                stdev = 0.0

                isUnstable = False
                regressions = String.Empty
                improvements = String.Empty

                lastVariation = variation
                lastTest = test
                lastRole = role
                lastMetric = metric

                xValues = ""
                yValues = ""

            End If

            If changeRunname Then
                xValues += runs(run_id) & ","
            Else
                xValues += run & ","
            End If

            yValues += result & ","

        End While

        If (xValues <> Nothing And xValues.Length > 0) And xValues.EndsWith(",") Then
            xValues = xValues.TrimEnd(",")
        End If

        If (yValues <> Nothing And yValues.Length > 0) And yValues.EndsWith(",") Then
            yValues = yValues.TrimEnd(",")
        End If

        If (lastTest <> Nothing And lastTest.Length > 0) Then
            lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")
        End If

        'CalculateStatistics(yValues, average, deltaSum, stdev)
        'lastRole = lastRole & " -- Sum=" & deltaSum.ToString() & " Avg=" & average & " stdev=" & stdev

        newYValues = FilterOutSpikes(yValues, filter)
        AnalyzeData(newYValues, lastMetric, isUnstable, regressions, improvements)

        yV = regressions.Split(",")
        xV = xValues.Split(",")

        j = 0
        h = 0

        While j < yV.Length
            'h = Convert.ToInt32(yV(j))
            'lastRole = lastRole & " " & xValues 'xV(h) & ", "
            j += 1
        End While
        'CalculateStatistics(newYValues, average, deltaSum, stdev)
        'newLastRole = lastRole '& " -- Sum=" & deltaSum.ToString() & " Avg=" & average & " stdev=" & stdev

        If isUnstable = True Then
            'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblUnstableTests)
            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblUnstableTests)
        ElseIf Not regressions Is Nothing And regressions <> String.Empty Then
            'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
            'newLastRole = lastRole & " REGRESSIONS: " & regressions
            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblRegressions, regressions)
        ElseIf Not improvements Is Nothing And improvements <> String.Empty Then
            'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblImprovements)
            'newLastRole = lastRole & " IMPROVEMENTS: " & improvements
            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblImprovements, improvements)
        Else
            'AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblConstantTests)
            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, newYValues, tblConstantTests)
        End If

    End Function

    Private Function AnalyzeRPS() 'add for RPS, it set the test result database field and send email
        Dim selrunsArr() As String
        Dim selrunsCount As Integer = 0
        selrunsArr = selruns.Split(",")
        selrunsCount = selrunsArr.Length

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        Dim summary As String = String.Empty
        Dim chkSummary As Boolean = False
        summary = Request.QueryString("summary")
        If Not (summary Is Nothing OrElse summary.Length = 0) Then
            chkSummary = Boolean.Parse(summary)
        End If

        Dim memoryTest As Boolean = False
        Dim refsetTest As Boolean = False
        Dim latencyTest As Boolean = False

        If Not (runtype Is Nothing OrElse runtype.Length = 0) Then
            memoryTest = runtype.ToLower().IndexOf("memory") >= 0
            refsetTest = runtype.ToLower().IndexOf("refset") >= 0
            latencyTest = runtype.ToLower().IndexOf("latency") >= 0 Or runtype.ToLower().IndexOf("startup") >= 0
        End If

        Dim newRunnames As String = String.Empty
        Dim newRunnamesArr() As String
        Dim newRunnamesCount As Integer = 0
        newRunnames = CType(Session("newRunnames"), String)

        If Not (newRunnames Is Nothing OrElse newRunnames.Length = 0) Then
            newRunnamesArr = newRunnames.Split(",")
            newRunnamesCount = newRunnamesArr.Length
        End If

        Dim runs As New Hashtable
        Dim k As Integer = 0

        If selrunsCount = newRunnamesCount Then
            While k < selrunsArr.Length
                runs.Add(selrunsArr(k), newRunnamesArr(k))
                k += 1
            End While
        End If

        sql = "SELECT DISTINCT runs.run, runs.run_id, RPS_testRun.createtime, tests.test, jobruns.test_id, measurements.measured_value, processes.process_id, processes.role_id, variations.variation"
        sql += ", roles.role, metrics.metric"
        sql += " FROM runs INNER JOIN jobruns ON jobruns.run_id = runs.run_id"
        sql += " INNER JOIN tests ON tests.test_id = jobruns.test_id"
        sql += " INNER JOIN RPS_testRun on runs.run_id=RPS_testRun.labRunId "
        sql += " INNER JOIN processes ON processes.jobrun_id = jobruns.jobrun_id"
        sql += " INNER JOIN measurements ON measurements.process_id = processes.process_id"
        sql += " INNER JOIN variations ON variations.variation_id = processes.variation_id"
        sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
        sql += " INNER JOIN roles on roles.role_id = processes.role_id WHERE "

        Dim sql3 As String = String.Empty
        If Not chkSummary Then
            sql3 = "(jobruns.validity = 4) AND "
        End If

        Dim sql1 As String 'runs with role_id only=1
        Dim sql2 As String 'runs with role_id=2 or role_id=9
        Dim clause As String
        Dim testClause As String

        If selectedTests <> -1 Then
            testClause = String.Format("(jobruns.test_id IN ({0})) AND ", selectedTests)
        Else
            testClause = ""
        End If

        If memoryTest Then
            clause = "(metrics.metric like '%Module Count%' OR metrics.metric like '%Thread Count%' OR metrics.metric like '%Working Set%')"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 1, 2)
        ElseIf refsetTest Then
            clause = "(metrics.metric like '%UniqueFileBacked%' OR metrics.metric like '%PeakDynamic%')"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 1, 9)
        ElseIf latencyTest Then
            'clause = "(metrics.metric in ('AverageLatency','95thPercentileLatency'))"
            clause = "(metrics.metric in ('AverageLatency'))"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3}, {4})) ", selruns, clause, 1, 2, 9)
        Else
            clause = "(measurements.metric_id = 56)"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 2, 9)
        End If

        'sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3}, {4})) ", Session("SelectedTests"), selruns, 56, 2, 9)
        sql1 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3})) ", clientOnlyTests, selruns, 56, 1)

        If Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0) Then
            sql = sql & "(" & sql1 & ") OR (" & sql2 & ")"
        Else
            sql = sql & sql2
        End If

        sql += " ORDER BY tests.test, processes.role_id, variations.variation, metrics.metric, RPS_testRun.createtime, processes.process_id"

        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        command = New SqlCommand(sql, connection)
        command.CommandTimeout = 120

        dr = command.ExecuteReader()

        Dim lastVariation As String
        lastVariation = String.Empty

        Dim lastTest As String
        lastTest = String.Empty

        'add for RPS
        Dim lastTest_id As String
        lastTest_id = String.Empty

        Dim lastRole As String
        lastRole = String.Empty

        Dim lastMetric As String
        lastMetric = String.Empty

        Dim i As Integer = 0

        Dim test As String
        Dim run As String
        Dim variation As String
        Dim result As Double
        Dim run_id As String
        Dim last_run_id As Integer = 0 'used to fix the problem when some variation failed or result not uploaded
        Dim test_id As String 'add for RPS
        Dim role As String
        Dim metric As String

        Dim xValues As String = String.Empty
        Dim yValues As String = String.Empty

        Dim changeRunname As Boolean = (Not (newRunnames Is Nothing OrElse newRunnames.Length = 0)) And (selrunsCount = newRunnamesCount)

        Dim regressions As String = String.Empty
        Dim regressionsCompareOne As String = String.Empty

        Dim filter As Double = 5.0


        Dim j As Integer = 0

        Dim values() As String

        Dim curVal As Double
        Dim prevVal As Double
        Dim delta As Double
        Dim deltaAve As Double
        Dim deltaAveHalf As Double
        Dim averageHalf As Double

        While dr.Read()

            test = CType(dr.Item("test"), String)
            variation = CType(dr.Item("variation"), String)
            run = CType(dr.Item("run"), String)
            result = CType(dr.Item("measured_value"), Double)
            run_id = CType(dr.Item("run_id"), String)
            role = CType(dr.Item("role"), String)
            metric = CType(dr.Item("metric"), String)
            test_id = CType(dr.Item("test_id"), String)

            If last_run_id < Integer.Parse(run_id) Then 'to fix some varation failed or upload results failed
                last_run_id = Integer.Parse(run_id)
            End If

            If i = 0 Then
                lastVariation = variation
                lastTest = test
                lastRole = role
                lastMetric = metric
                lastTest_id = test_id 'add for RPS

                i += 1
            End If

            If (variation <> lastVariation Or test <> lastTest Or role <> lastRole Or metric <> lastMetric) Then

                xValues = xValues.Substring(0, xValues.Length - 1)
                yValues = yValues.Substring(0, yValues.Length - 1)
                lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")
                values = yValues.Split(",")


                'check regressions
                curVal = values(values.Length - 1)
                If (values.Length > 1) Then
                    prevVal = values(values.Length - 2)
                End If


                If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, False) Then 'regression happens compare previous one
                    regressionsCompareOne += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
                    If (showRPSchart And comparePrevious = 1) Then
                        AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
                    End If
                End If

                If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, True) Then 'regression happens compare with previous five
                    regressions += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
                    If (showRPSchart And (Not comparePrevious = 1)) Then
                        AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
                    End If
                End If


                'check if regression
                'If comparePrevious = 1 Then 'compare with previous one
                '    If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, False) Then 'regression happens
                '        curVal = values(values.Length - 1)
                '        prevVal = values(values.Length - 2)
                '        regressions += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
                '        If showRPSchart Then
                '            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
                '        End If
                '    End If
                'Else
                '    If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, True) Then 'regression happens
                '        curVal = values(values.Length - 1)
                '        prevVal = values(values.Length - 2)
                '        regressions += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
                '        If showRPSchart Then
                '            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
                '        End If
                '    End If
                'End If


                lastVariation = variation
                lastTest = test
                lastRole = role
                lastMetric = metric
                lastTest_id = test_id 'add for RPS

                xValues = ""
                yValues = ""

            End If

            If changeRunname Then
                xValues += runs(run_id) & ","
            Else
                xValues += run & ","
            End If

            yValues += result & ","

        End While

        If (xValues <> Nothing And xValues.Length > 0) And xValues.EndsWith(",") Then
            xValues = xValues.TrimEnd(",")
        End If

        If (yValues <> Nothing And yValues.Length > 0) And yValues.EndsWith(",") Then
            yValues = yValues.TrimEnd(",")
        End If

        If (lastTest <> Nothing And lastTest.Length > 0) Then
            lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")
        End If

        values = yValues.Split(",")

        If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, False) Then 'regression happens compare previous one
            regressionsCompareOne += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
            If (showRPSchart And comparePrevious = 1) Then
                AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
            End If
        End If

        If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, True) Then 'regression happens compare with previous five
            regressions += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
            If (showRPSchart And (Not comparePrevious = 1)) Then
                AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
            End If
        End If



        'check for regression
        'If comparePrevious = 1 Then 'compare with previous one
        '    If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, False) Then 'regression happens
        '        regressions += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
        '        If ShowRunsStats() Then
        '            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
        '        End If
        '    End If
        'Else 'compare with previous five
        '    If CheckRPSregression(values, lastMetric.ToLower(), delta, deltaAveHalf, deltaAve, True) Then 'regression happens
        '        regressions += lastTest & ":" & lastTest_id & ":" & lastVariation & ":" & delta & ":" & deltaAveHalf & ":" & deltaAve & ":" & prevVal & ":" & curVal & ","
        '        If ShowRunsStats() Then
        '            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues, tblRegressions)
        '        End If
        '    End If
        'End If






        dr.Close()


        If Not showRPSchart Then
            'set the testresult field for RPS test run in database
            Dim updateSql As String
            Dim compareOneCol As String = "testresultCompareOne"
            Dim compareFiveCol As String = "testresult"
            Dim compareOneResult As String
            Dim compareFiveResult As String
            Dim largestRegression As Double = 0

            Dim regressionValues() As String = regressionsCompareOne.Split(",")
            For Each variationRegress As String In regressionValues
                If Not (variationRegress Is Nothing Or variationRegress = String.Empty) Then
                    Dim variaitonsRegContent() As String = variationRegress.Split(":")
                    Dim tempDelta As Double = Double.Parse(variaitonsRegContent(3))
                    If tempDelta < largestRegression Then
                        largestRegression = tempDelta
                    End If
                End If
            Next

            If Not (regressionsCompareOne Is Nothing Or regressionsCompareOne = String.Empty) Then 'if regression compare one
                compareOneResult = "Possible_regression_" & largestRegression & "%"
            Else
                compareOneResult = "No_regression"
            End If

            If Not (regressions Is Nothing Or regressions = String.Empty) Then 'if regression compare five
                compareFiveResult = "Possible_regression_" & largestRegression & "%"
            Else
                compareFiveResult = "No_regression"
            End If

            updateSql = "update RPS_testRun set " & compareOneCol & " = '" & compareOneResult & "', " & compareFiveCol & " = '" & compareFiveResult & "' where labRunId = " & last_run_id

            'If comparePrevious = 1 Then 'compare with previous one
            '    columnName = "testresultCompareOne"
            'Else
            '    columnName = "testresult"
            'End If

            'If Not (regressions Is Nothing Or regressions = String.Empty) Then 'if regression
            '    updateSql = "update RPS_testRun set " & columnName & " = 'Possible_regression' where labRunId = " & last_run_id
            'Else
            '    updateSql = "update RPS_testRun set " & columnName & " = 'No_regression' where labRunId = " & last_run_id
            'End If


            DBUtil.ExecNonQuery(updateSql)

            regressions = regressions.Trim(",")
            If Not (regressions Is Nothing Or regressions = String.Empty Or comparePrevious = 1) Then 'send warn email if regression compare five
                'get the RPS build number
                Dim buildNumberSql As String
                Dim buildNumber As String = String.Empty
                buildNumberSql = "select buildnumber from RPS_testRun where labrunid = " & last_run_id
                command = New SqlCommand(buildNumberSql, connection)
                command.CommandTimeout = 120

                dr = command.ExecuteReader()
                If (dr.Read()) Then
                    buildNumber = CType(dr.Item("buildnumber"), String)
                    'send email if regressions
                    Dim mailMessage As MailMessage = New MailMessage()
                    mailMessage.From = New MailAddress("indgaunt@microsoft.com")
                    mailMessage.To.Add("xwspla@microsoft.com")
                    mailMessage.Subject = "regression for RPS run: " & buildNumber
                    mailMessage.Body = vbNewLine & "regression for RPS " & buildNumber & vbNewLine & vbNewLine
                    mailMessage.Body += "http://xws-perf-cc/indiperfRPS/AnalyzeRun.aspx?&runid="
                    mailMessage.Body += last_run_id.ToString()
                    mailMessage.Body += "&testid=-1&testname=-1&count=30&analyzeRPSrun=true&showRPSchart=true" & vbNewLine & vbNewLine & vbNewLine


                    'contains regressions for each variaiton
                    Dim testRegressions() As String = regressions.Split(",")
                    For Each variationRegress As String In testRegressions
                        If Not (variationRegress Is Nothing Or variationRegress = String.Empty) Then
                            Dim variaitonsRegContent() As String = variationRegress.Split(":")
                            mailMessage.Body += "Test: " & variaitonsRegContent(0) & vbNewLine
                            mailMessage.Body += "Variation: " & variaitonsRegContent(2) & vbNewLine
                            mailMessage.Body += "Delta: " & variaitonsRegContent(3) & vbNewLine & vbNewLine & vbNewLine
                        End If
                    Next

                    Dim SmtpMail As New SmtpClient("smtphost.redmond.corp.microsoft.com")
                    SmtpMail.UseDefaultCredentials = True
                    'SmtpMail.Credentials = New System.Net.NetworkCredential("indgaunt@microsoft.com", "BigBoom#12")
                    SmtpMail.Send(mailMessage)
                End If
                dr.Close()

            End If
        End If

            Dim regressionResult As String = "Regressions: " & "<br>"
            Dim buildRegressions() As String = regressions.Split(",")
            For Each variationRegress As String In buildRegressions
                If Not (variationRegress Is Nothing Or variationRegress = String.Empty) Then
                    Dim variaitonsRegContent() As String = variationRegress.Split(":")
                    regressionResult += "Test: " & variaitonsRegContent(0) & ", "
                    regressionResult += "Variation: " & variaitonsRegContent(2) & ", "
                    regressionResult += "Delta: " & variaitonsRegContent(3) & "<br>"
                End If
            Next

            'get change list
            Dim changelistSql As String
            Dim changelist As String = String.Empty
            Dim build_Number As String = String.Empty
            changelistSql = "select changeList, buildnumber from RPS_testRun where labrunid = " & last_run_id
            command = New SqlCommand(changelistSql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()
            If (dr.Read()) Then
                changelist = CType(dr.Item("changeList"), String)
                build_Number = CType(dr.Item("buildnumber"), String)
            End If
            dr.Close()

            regressionResult += "<br>Change List: "

            Dim changelistLink As String = String.Empty
            If Not (changelist.Equals(String.Empty) Or build_Number.Equals(String.Empty)) Then
                Dim changes As String() = changelist.Split(",")
                If changes.Length > 0 Then
                    Dim i1 As Integer
                    For i1 = 0 To (changes.Length - 1)
                        regressionResult += "<a href=""\\cdffile01\Drops\RPS\" & build_Number & "\snapmail_mail_checkin" & i1 & ".html"">" & changes(i1) & "</a>" & ","
                    Next i1
                End If
            End If

            Response.Write(regressionResult)


    End Function

    Private Function CheckRPSregression(ByVal values As String(), ByVal type As String, ByRef delta As Double, ByRef deltaAveHalf As Double, ByRef deltaAve As Double, ByVal compareAve As Boolean) As Boolean 'add for RPS analyzer
        'sanity check
        If (values Is Nothing) Then
            Return False
        End If

        'sanity check, return false if there are too few values
        Dim length As Integer = values.Length
        If (length <= 1 Or (length <= comparePrevious And compareAve)) Then
            Return False
        End If

        Dim curVal As Double
        Dim prevVal As Double
        Dim signOfDelta As Integer
        Dim signOfDeltaAve As Integer
        Dim signOfDeltaAveHalf As Integer
        Dim startIndex As Integer

        'first calculate comparison with previous one
        curVal = Double.Parse(values(length - 1))
        prevVal = Double.Parse(values(length - 2))
        If (curVal = 0 And prevVal = 0) Then
            delta = 0
        Else
            delta = Math.Round(((curVal - prevVal) / prevVal) * 100, 5)
        End If
        If type.ToLower() <> "throughput" Then
            delta = -delta
        End If
        signOfDelta = Math.Sign(delta)
        If (Math.Abs(delta) < threshold Or signOfDelta > 0) Then 'no regression
            Return False
        End If

        'second compare with average of previouse 5 runs
        If compareAve Then
            startIndex = length \ 2
            If startIndex >= 3 Then
                startIndex = 0
            End If
            Dim averageHalf As Double = GetAverage(values, startIndex, length - 2) 'do not include the current one when calculate average
            If (curVal = 0 And averageHalf = 0) Then
                deltaAveHalf = 0
            Else
                deltaAveHalf = Math.Round(((curVal - averageHalf) / averageHalf) * 100, 5)
            End If
            If type.ToLower() <> "throughput" Then
                deltaAveHalf = -deltaAveHalf
            End If
            signOfDeltaAveHalf = Math.Sign(deltaAveHalf)
            If (Math.Abs(deltaAveHalf) < threshold Or signOfDeltaAveHalf > 0) Then 'no regression
                Return False
            End If
        End If


        'finally compare with average of all the previous runs
        'startIndex = 0
        'Dim average As Double = GetAverage(values, startIndex, length - 2)
        'If (curVal = 0 And average = 0) Then
        'deltaAve = 0
        'Else
        'deltaAve = Math.Round(((curVal - average) / average) * 100, 5)
        'End If
        'If type.ToLower() <> "throughput" Then
        'deltaAve = -deltaAve
        'End If
        'signOfDeltaAve = Math.Sign(deltaAve)
        'If (Math.Abs(deltaAve) < threshold Or signOfDeltaAve > 0) Then 'no regression
        'Return False
        'End If

        Return True

    End Function

    Private Function GetAverage(ByVal values As String(), ByVal startIndex As Integer, ByVal endIndex As Integer) As Double 'add for RPS
        Dim maxValue As Double = Double.Parse(values(startIndex))
        Dim minValue As Double = Double.Parse(values(startIndex))
        Dim sum As Double = 0
        Dim i As Integer
        For i = startIndex To endIndex
            sum += Double.Parse(values(i))
            If maxValue <= Double.Parse(values(i)) Then
                maxValue = Double.Parse(values(i))
            End If
            If minValue >= Double.Parse(values(i)) Then
                minValue = Double.Parse(values(i))
            End If
        Next i
        Return (sum - minValue - maxValue) / (endIndex - startIndex - 1)
    End Function

    Private Function FilterOutSpikes(ByVal y As String, ByVal filter As Double) As String

        Dim values() As String

        If y Is Nothing Or y.Length = 0 Then
            Return y
        End If

        values = y.Split(",")

        If values Is Nothing Or values.Length <= 2 Then
            Return y
        End If

        Dim z(values.Length) As Double
        Dim v(values.Length) As Double
        Dim ret As String

        Dim i As Integer = 2

        z(0) = Convert.ToDouble(values(0))
        z(1) = Convert.ToDouble(values(1))

        v(0) = z(0)
        v(1) = z(1)

        Dim tempMax As Double
        Dim tempMin As Double
        Dim temp As Double

        Dim delta1 As Double
        Dim delta2 As Double

        'Dim noise As Double = 0.2

        Dim lastAveraged As Integer = -1 ' this is to avoid averaging 2nd point in seesaw-like patterns

        While i < values.Length

            z(i) = Convert.ToDouble(values(i))
            v(i) = z(i)

            'temp = AverageOfThree(z(i - 2), z(i - 1), z(i))
            delta1 = Math.Round((z(i - 1) - z(i - 2)) * 100 / z(i - 2), 1)
            delta2 = Math.Round((z(i) - z(i - 1)) * 100 / z(i - 1), 1)

            Dim absD1 As Double = Math.Abs(delta1)
            Dim absD2 As Double = Math.Abs(delta2)

            Dim absDelta As Double = Math.Abs(z(i - 2) - z(i - 1))

            Dim largerDelta As Double = AverageOfTwo(absD1, absD2)

            ' (delta1 < -filter And delta2 > -filter) Or (delta1 > filter And delta2 < filter)
            'If (Math.Sign(delta1) = -Math.Sign(delta2) And Math.Abs(delta1) > threshold And Math.Abs(delta2) > threshold And (z(i) < (z(i - 2) + noise * absDelta) And z(i) > (z(i - 2) - noise * absDelta))) Then
            'If (Math.Sign(delta1) = -Math.Sign(delta2) And (Math.Round(absD1 / absD2, 0) = 1.0 Or Math.Round(absD2 / absD1, 0) = 1.0)) Then
            If (Math.Sign(delta1) = -Math.Sign(delta2) And Math.Abs(delta1) > threshold And Math.Abs(z(i - 2) - z(i)) < noiseCoefficient * absDelta) And lastAveraged <> (i - 2) Then
                v(i - 1) = AverageOfTwo(z(i - 2), z(i))
                lastAveraged = i - 1
            End If

            i += 1
        End While

        i = 0

        While i < values.Length
            ret += Convert.ToString(v(i)) & ","

            i += 1
        End While

        ret = ret.TrimEnd(",")

        Return ret

    End Function

    Private Function AverageOfTwo(ByVal x1 As Double, ByVal x2 As Double) As Double
        Return (x1 + x2) / 2.0
    End Function

    Private Function AverageOfThree(ByVal x1 As Double, ByVal x2 As Double, ByVal x3 As Double) As Double
        Return (x1 + x2 + x3) / 3.0
    End Function

    Private Function MaxOfThree(ByVal x1 As Double, ByVal x2 As Double, ByVal x3 As Double) As Double

        Dim tempMax As Double

        tempMax = Math.Max(x1, x2)
        tempMax = Math.Max(tempMax, x3)

        Return tempMax
    End Function

    Private Function MinOfThree(ByVal x1 As Double, ByVal x2 As Double, ByVal x3 As Double) As Double

        Dim tempMin As Double

        tempMin = Math.Min(x1, x2)
        tempMin = Math.Min(tempMin, x3)

        Return tempMin
    End Function

    Private Function AnalyzeData(ByVal y As String, ByVal metric As String, ByRef isUnstable As Boolean, ByRef regressions As String, ByRef improvements As String)

        ' Defining regression as a sequence of at least two consecutive results where delta stayed below 5%
        Dim values() As String

        Dim curVal As Double
        Dim prevVal As Double

        If y Is Nothing Or y = String.Empty Then
            isUnstable = False
            regressions = String.Empty
            improvements = String.Empty
            Exit Function
        End If

        values = y.Split(",")
        Dim deltas(values.Length - 1) As Double

        'Return false if less than three results
        If values.Length <= 2 Then
            isUnstable = False
            regressions = String.Empty
            improvements = String.Empty
            Exit Function
        End If

        'Dim indexOfLastRegression As Integer
        Dim totalHighDeltas As Integer
        Dim withinNoiseLength As Integer = 1
        Dim indexOfLastHighDelta As Integer

        Dim deltaSum As Double

        Dim i As Integer = 1

        Dim signOfLastHighDelta As Integer
        Dim signOfLastDelta As Integer

        While i < values.Length

            curVal = Double.Parse(values(i))
            prevVal = Double.Parse(values(i - 1))
            If (curVal = 0 And prevVal = 0) Then
                deltas(i - 1) = 0
            Else
                deltas(i - 1) = Math.Round(((curVal - prevVal) / prevVal) * 100, 1)
            End If

            If metric.ToLower() <> "throughput" Then
                deltas(i - 1) = -deltas(i - 1)
            End If

            signOfLastDelta = Math.Sign(deltas(i - 1))

            If Math.Abs(deltas(i - 1)) >= threshold Then
                If withinNoiseLength >= leftWindowInterval Then
                    indexOfLastHighDelta = i - 1
                    signOfLastHighDelta = Math.Sign(deltas(indexOfLastHighDelta))
                ElseIf indexOfLastHighDelta = i - 2 And signOfLastHighDelta = signOfLastDelta Then
                    'indexOfLastHighDelta = i - 2 ' remains the same
                Else
                    indexOfLastHighDelta = 0 'reset 
                End If
                withinNoiseLength = 1
                totalHighDeltas += 1
            Else
                If withinNoiseLength >= rightWindowInterval And indexOfLastHighDelta <> 0 Then
                    If Math.Sign(deltas(indexOfLastHighDelta)) = -1 Then
                        regressions += (indexOfLastHighDelta + 1).ToString() & ","
                    Else
                        improvements += (indexOfLastHighDelta + 1).ToString() & ","
                    End If
                    indexOfLastHighDelta = 0
                End If
                withinNoiseLength += 1
            End If

            deltaSum += deltas(i - 1)
            i += 1

        End While

        Dim ratio As Double = Convert.ToDouble(totalHighDeltas) / Convert.ToDouble(values.Length)

        If ratio > unstabilityCoefficient Then
            isUnstable = True
        Else
            isUnstable = False
        End If

        If Not regressions Is Nothing And regressions <> String.Empty Then
            regressions = regressions.TrimEnd(",")
        End If

        If Not improvements Is Nothing And improvements <> String.Empty Then
            improvements = improvements.TrimEnd(",")
        End If

    End Function


    'Private Function AnalyzeData(ByVal y As String, ByVal metric As String, ByRef isUnstable As Boolean, ByRef regressions As String, ByRef possibleRegression As String, ByRef improvements As String)

    '    ' Defining regression as a sequence of at least two consecutive results where delta stayed below 5%
    '    Dim values() As String

    '    Dim curVal As Double
    '    Dim prevVal As Double

    '    Dim window As Integer = 8

    '    If y Is Nothing Or y.Length = 0 Then
    '        isUnstable = False
    '        regressions = String.Empty
    '        possibleRegression = String.Empty
    '        improvements = String.Empty
    '        Exit Function
    '    End If

    '    values = y.Split(",")
    '    Dim deltas(values.Length - 1) As Double
    '    'Return false if less than three results
    '    If values.Length <= window Then
    '        isUnstable = False
    '        regressions = String.Empty
    '        possibleRegression = String.Empty
    '        improvements = String.Empty
    '        Exit Function
    '    End If

    '    Dim averageCount As Integer = 5

    '    Dim leftAverage As Double
    '    Dim rightAverage As Double
    '    Dim rightSum As Double

    '    Dim filter As Double = -0.1
    '    Dim ratio As Double

    '    Dim i As Integer = 4

    '    While i < values.Length - 3

    '        leftAverage = (Double.Parse(values(i - 4)) + Double.Parse(values(i - 3)) + Double.Parse(values(i - 2)) + Double.Parse(values(i - 1)) + Double.Parse(values(i))) / averageCount

    '        Dim k As Integer = i + 2
    '        Dim m As Integer = 0

    '        rightSum = 0

    '        While m < 2 And (k + m) < values.Length
    '            rightSum += Double.Parse(values(k + m))
    '            m += 1
    '        End While

    '        rightAverage = rightSum / 2

    '        ratio = (leftAverage - rightAverage) / leftAverage

    '        If metric.ToLower() = "throughput" Then
    '            ratio = -ratio
    '        End If

    '        If (ratio < filter) Then
    '            regressions += i.ToString() & ","
    '        End If

    '        i += 1

    '    End While

    '    If Not regressions Is Nothing And regressions <> String.Empty Then
    '        regressions = regressions.TrimEnd(",")
    '    End If


    'End Function

    Private Function ConvertToDoubles(ByVal y As String, ByRef yD() As Double)

    End Function
    Private Function CalculateStatistics(ByVal yValues As String, ByRef average As Double, ByRef deltaSum As Double, ByRef stdev As Double)

        Dim values() As String

        If yValues Is Nothing Or yValues.Length = 0 Then
            average = 0.0
            deltaSum = 0.0
            stdev = 0.0
            Exit Function
        End If

        values = yValues.Split(",")

        Dim y(values.Length) As Double
        Dim deltas(values.Length - 1) As Double

        y(0) = Double.Parse(values(0))

        If values.Length = 1 Then
            average = y(0)
            deltaSum = 0.0
            stdev = 0.0
            Exit Function
        End If

        Dim sum As Double = y(0)
        Dim sumOfSquaredValues As Double = y(0) * y(0)

        Dim curVal As Double
        Dim prevVal As Double

        Dim i As Integer = 1

        While i < values.Length
            y(i) = Double.Parse(values(i))
            sum += y(i)
            sumOfSquaredValues += y(i) * y(i)
            curVal = y(i)
            prevVal = y(i - 1)
            If (curVal = 0 And prevVal = 0) Then
                deltas(i - 1) = 0
            Else
                deltas(i - 1) = ((curVal - prevVal) / prevVal) * 100
            End If

            deltaSum += deltas(i - 1)

            i += 1

        End While

        deltaSum = Math.Round(deltaSum, 2)
        average = Math.Round(sum / y.Length, 6)
        stdev = Math.Round(Math.Sqrt((sumOfSquaredValues - sum * sum / y.Length) / (y.Length - 1)), 6)

    End Function

    Private Function ContainsRegression(ByVal y As String, ByVal metric As String) As Double

        ' Defining regression as a sequence of at least two consecutive results where delta stayed below 5%
        Dim values() As String

        Dim curVal As Double
        Dim prevVal As Double

        If y Is Nothing Or y.Length = 0 Then
            Return 0.0 'False
        End If

        values = y.Split(",")
        Dim deltas(values.Length - 1) As Double
        'Return false if less than three results
        If values.Length <= 2 Then
            Return 0.0 'False
        End If

        Dim i As Integer = 1
        Dim foundRegression As Boolean = False
        Dim regressionCounter As Integer
        Dim indexOfLastRegression As Integer

        Dim deltaSum As Double

        While i < values.Length
            curVal = Double.Parse(values(i))
            prevVal = Double.Parse(values(i - 1))
            If (curVal = 0 And prevVal = 0) Then
                deltas(i - 1) = 0
            Else
                deltas(i - 1) = Math.Round(((curVal - prevVal) / prevVal) * 100, 1)
            End If

            If metric.ToLower() <> "throughput" Then
                deltas(i - 1) = -deltas(i - 1)
            End If

            'If deltas(i) <= -5.0 Then
            '    indexOfLastRegression = i
            '    'diffCell.BackColor = Color.Red
            '    'diffCell.ForeColor = Color.White
            'ElseIf deltas(i) >= 5.0 Then
            '    If i > indexOfLastRegression Then
            '        foundRegression = False
            '    End If
            '    'diffCell.BackColor = Color.ForestGreen
            '    'diffCell.ForeColor = Color.White
            'Else
            '    If i > indexOfLastRegression Then
            '        regressionCounter += 1
            '    Else
            '        regressionCounter = 0
            '    End If

            'End If

            deltaSum += deltas(i - 1)

            i += 1

        End While

        'If regressionCounter >= 2 Then
        '    foundRegression = True
        'End If

        'If deltaSum <= -3.0 Then
        '    foundRegression = True
        'Else
        '    foundRegression = False
        'End If

        Return deltaSum

    End Function

    Private Function ShowRunsStats()

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        pnlRuns.Height = Unit.Pixel(100)

        tblRunsStats.CellPadding = 3
        tblRunsStats.CellSpacing = 0
        tblRunsStats.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblRunsStats.BorderStyle = BorderStyle.Solid
        tblRunsStats.GridLines = System.Web.UI.WebControls.GridLines.Both
        tblRunsStats.BorderWidth = Unit.Pixel(3)

        Dim i As Integer = 0

        Dim tests As String
        Dim run As String
        Dim variations As String
        Dim failedVariations As String
        Dim testRuns As String

        sql = "select r.run_id,r.run,r.tests,r.test_runs,r.variations,r.failed_variations"
        sql += " from runs r"
        sql += " where r.run_id in (" + selruns + ")"
        sql += " order by r.run_id"

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            While dr.Read()

                tests += CType(dr.Item("tests"), String) & ","
                variations += CType(dr.Item("variations"), String) & ","
                run += CType(dr.Item("run"), String) & ","
                failedVariations += CType(dr.Item("failed_variations"), Double) & ","
                testRuns += CType(dr.Item("test_runs"), String) & ","

            End While

            If (tests <> Nothing And tests.Length > 0) And tests.EndsWith(",") Then
                tests = tests.TrimEnd(",")
            End If

            If (variations <> Nothing And variations.Length > 0) And variations.EndsWith(",") Then
                variations = variations.TrimEnd(",")
            End If

            If (run <> Nothing And run.Length > 0) And run.EndsWith(",") Then
                run = run.TrimEnd(",")
            End If

            If (failedVariations <> Nothing And failedVariations.Length > 0) And failedVariations.EndsWith(",") Then
                failedVariations = failedVariations.TrimEnd(",")
            End If

            If (testRuns <> Nothing And testRuns.Length > 0) And testRuns.EndsWith(",") Then
                testRuns = testRuns.TrimEnd(",")
            End If

            AddRowToStatsTable(run, tests, "Number of Tests")
            AddRowToStatsTable(run, testRuns, "Number of Test Iterations")
            AddRowToStatsTable(run, variations, "Number of Variations")
            AddRowToStatsTable(run, failedVariations, "Number of Failed Variations")

        Catch ex As Exception

        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function

    Private Function AddRowToStatsTable(ByVal run As String, ByVal metric As String, ByVal chartTitle As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow
        Dim chartLink As String

        chartLink = "<img src='ShowCharts.aspx?x=" & run & "&y=" & metric & "&Title=" & chartTitle & "&Metric=" & "Count" & "&Style=Line'>"

        AddSimpleChartCell(chartLink, row)

        tblRunsStats.Rows.Add(row)

    End Function

    Private Function ShowRunsTable()

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        pnlRuns.Height = Unit.Pixel(100)

        tblRunsData.CellPadding = 3
        tblRunsData.CellSpacing = 0
        tblRunsData.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblRunsData.BorderStyle = BorderStyle.Solid
        tblRunsData.GridLines = System.Web.UI.WebControls.GridLines.Both
        tblRunsData.BorderWidth = Unit.Pixel(3)

        Dim runId As String = "<b>Run ID</b>"
        Dim run As String = "<b>Run</b>"
        Dim runtype As String = "<b>Run Type</b>"
        Dim frameworkBuild As String = "<b>CLR</b>"
        Dim wcfBuild As String = "<b>WCF</b>"
        Dim netfxBuild As String = "<b>Netfx3.5</b>"
        Dim wfBuild As String = "<b>WF</b>"
        Dim osloBuild As String = "<b>Oslo</b>"
        Dim runDate As String = "<b>Date</b>"

        sql = "select distinct r.run_id,r.run,rt.runtype,b.build as WCF_build,nb.netfxbuild as Netfx35_build,"
        sql += " wb.wfbuild as WF_build,convert(varchar(10),r.start_date,101) as start_date,"
        sql += " ob.oslobuild as oslo_build, r.tests,r.test_runs,r.variations,r.failed_variations,f.framework"
        sql += " from runs r inner join builds b on r.build_id=b.build_id "
        sql += " inner join netfxbuilds nb on r.netfxbuild_id=nb.netfxbuild_id"
        sql += " inner join wfbuilds wb on r.wfbuild_id=wb.wfbuild_id"
        sql += " inner join oslobuilds ob on r.oslobuild_id=ob.oslobuild_id"
        sql += " inner join runtypes rt on r.runtype_id=rt.runtype_id"
        sql += " inner join jobruns j on j.run_id=r.run_id"
        sql += " inner loop join processes p on p.jobrun_id=j.jobrun_id"
        sql += " inner join frameworks f on f.framework_id=p.framework_id"
        sql += " where r.run_id in (" + selruns + ")"
        sql += " order by r.run_id desc "

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            AddRowToRunsTable(runId, run, runtype, frameworkBuild, wcfBuild, netfxBuild, wfBuild, osloBuild, runDate)

            While dr.Read()

                runId = CType(dr.Item("run_id"), String)
                runId = String.Format("<a href=explorer.aspx?rc=1&rid1={0}>{0}</a>", runId)
                run = CType(dr.Item("run"), String)
                run = run.Substring(5)
                runtype = CType(dr.Item("runtype"), String)
                frameworkBuild = CType(dr.Item("framework"), String)
                wcfBuild = CType(dr.Item("wcf_build"), String)
                netfxBuild = CType(dr.Item("netfx35_build"), String)
                wfBuild = CType(dr.Item("WF_build"), String)
                osloBuild = CType(dr.Item("oslo_build"), String)
                runDate = CType(dr.Item("start_date"), String)

                AddRowToRunsTable(runId, run, runtype, frameworkBuild, wcfBuild, netfxBuild, wfBuild, osloBuild, runDate)

            End While
        Catch ex As Exception

        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function


    Private Function AddRowToRunsTable(ByVal runId As String, ByVal run As String, ByVal runtype As String, ByVal frameworkBuild As String, ByVal wcfBuild As String, ByVal netfxBuild As String, ByVal wfBuild As String, ByVal osloBuild As String, ByVal runDate As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(runId, row)
        AddSimpleCell(run, row)
        AddSimpleCell(runtype, row)
        AddSimpleCell(frameworkBuild, row)
        AddSimpleCell(wcfBuild, row)
        AddSimpleCell(wfBuild, row)
        AddSimpleCell(netfxBuild, row)
        AddSimpleCell(osloBuild, row)
        AddSimpleCell(runDate, row)

        tblRunsData.Rows.Add(row)

    End Function


    Private Function Add2Cells(ByVal cell1 As String, ByVal cell2 As String, ByRef tbl As System.Web.UI.WebControls.Table)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(cell1, row)
        AddSimpleCell(cell2, row)

        tbl.Rows.Add(row)

    End Function

    Private Function AddSimpleCell(ByVal item As String, ByRef row As TableRow)
        Dim cell As TableCell = New System.Web.UI.WebControls.TableCell
        cell.Text = item
        row.Cells.Add(cell)
    End Function

    Private Function AddSimpleChartCell(ByVal item As String, ByRef row As TableRow)
        Dim cell As TableCell = New System.Web.UI.WebControls.TableCell
        cell.ColumnSpan = 8
        cell.Text = item
        row.Cells.Add(cell)
    End Function

    Private Function AddValuesRow(ByVal x As String, ByVal y As String, ByVal metric As String, ByRef tblOut As System.Web.UI.WebControls.Table)

        Dim tbl As Table = New Table

        tbl.CellPadding = 3
        tbl.CellSpacing = 0
        tbl.BorderColor = Color.FromArgb(13421721) '#cccc99
        tbl.BorderStyle = BorderStyle.Solid
        tbl.GridLines = System.Web.UI.WebControls.GridLines.Both
        tbl.BorderWidth = Unit.Pixel(1)

        Dim cell As TableCell
        Dim row As TableRow
        Dim diffCell As TableCell
        Dim diffRow As TableRow

        Dim xArr() As String
        xArr = x.Split(",")

        Dim yArr() As String
        yArr = y.Split(",")

        Dim j As Integer = 0

        While j < xArr.Length

            row = New System.Web.UI.WebControls.TableRow
            diffRow = New System.Web.UI.WebControls.TableRow

            Dim k As Integer = 0

            While (k < 10 And (j + k) < xArr.Length)
                cell = New System.Web.UI.WebControls.TableCell

                cell.Font.Size = FontUnit.XXSmall
                cell.BackColor = Color.LightSteelBlue
                cell.Text = xArr(j + k).Substring(5)
                row.Cells.Add(cell)

                k += 1
            End While

            tbl.Rows.Add(row)

            Dim curVal As Double
            Dim prevVal As Double
            Dim delta As Double
            row = New System.Web.UI.WebControls.TableRow

            k = 0

            While (k < 10 And (j + k) < xArr.Length)
                cell = New System.Web.UI.WebControls.TableCell

                cell.Font.Size = FontUnit.XXSmall
                cell.HorizontalAlign = HorizontalAlign.Center
                cell.Text = yArr(j + k)
                row.Cells.Add(cell)

                diffCell = New System.Web.UI.WebControls.TableCell

                diffCell.Font.Size = FontUnit.XXSmall
                diffCell.HorizontalAlign = HorizontalAlign.Center

                If k = 0 And j = 0 Then
                    diffCell.Text = "Delta %"
                    diffCell.BackColor = Color.LightGray
                Else
                    curVal = Double.Parse(yArr(j + k))
                    prevVal = Double.Parse(yArr(j - 1 + k))
                    If (curVal = 0 And prevVal = 0) Then
                        delta = 0
                    Else
                        delta = Math.Round(((curVal - prevVal) / prevVal) * 100, 1)
                    End If

                    If metric.ToLower() <> "throughput" Then
                        delta = -delta
                    End If

                    If delta <= -threshold Then
                        diffCell.BackColor = Color.Red
                        diffCell.ForeColor = Color.White
                    ElseIf delta >= threshold Then
                        diffCell.BackColor = Color.ForestGreen
                        diffCell.ForeColor = Color.White
                    End If
                    diffCell.Text = delta.ToString()

                End If
                diffRow.Cells.Add(diffCell)

                k += 1
            End While

            tbl.Rows.Add(row)
            tbl.Rows.Add(diffRow)

            row = New System.Web.UI.WebControls.TableRow
            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(tbl)
            cell.ColumnSpan = 2
            row.Cells.Add(cell)

            tblOut.Rows.Add(row)

            j += 10

        End While

    End Function


    Private Function AddValuesRow(ByVal x As String, ByVal y As String, ByVal metric As String, ByRef tblOut As System.Web.UI.WebControls.Table, ByVal specialCells As String)

        Dim tbl As Table = New Table

        tbl.CellPadding = 3
        tbl.CellSpacing = 0
        tbl.BorderColor = Color.FromArgb(13421721) '#cccc99
        tbl.BorderStyle = BorderStyle.Solid
        tbl.GridLines = System.Web.UI.WebControls.GridLines.Both
        tbl.BorderWidth = Unit.Pixel(1)

        Dim cell As TableCell
        Dim xCell As TableCell
        Dim yCell As TableCell
        Dim row As TableRow
        Dim xRow As TableRow
        Dim yRow As TableRow
        Dim diffCell As TableCell
        Dim diffRow As TableRow

        Dim specialCellsArr() As String
        specialCellsArr = specialCells.Split(",")

        Dim xArr() As String
        xArr = x.Split(",")

        Dim yArr() As String
        yArr = y.Split(",")

        Dim j As Integer = 0
        Dim i As Integer = 0
        Dim innerIndex As Integer = 0

        While j < xArr.Length

            If i < specialCellsArr.Length Then
                innerIndex = Convert.ToInt32(specialCellsArr(i))
                i += 1
            End If

            xRow = New System.Web.UI.WebControls.TableRow
            yRow = New System.Web.UI.WebControls.TableRow
            diffRow = New System.Web.UI.WebControls.TableRow

            Dim k As Integer = 0

            'While (k < 10 And (j + k) < xArr.Length)
            '    cell = New System.Web.UI.WebControls.TableCell

            '    cell.Font.Size = FontUnit.XXSmall

            '    If (j + k) = innerIndex Then
            '        cell.BackColor = Color.LightSteelBlue
            '    Else
            '        cell.BackColor = Color.LightSteelBlue

            '    End If

            '    cell.Text = xArr(j + k).Substring(5)
            '    yRow.Cells.Add(cell)

            '    k += 1
            'End While

            'tbl.Rows.Add(yRow)

            Dim curVal As Double
            Dim prevVal As Double
            Dim delta As Double

            While (k < 10 And (j + k) < xArr.Length)

                ' Y Row
                yCell = New System.Web.UI.WebControls.TableCell

                yCell.Font.Size = FontUnit.XXSmall
                yCell.BackColor = Color.LightSteelBlue
                yCell.Text = xArr(j + k).Substring(5)

                ' X Row
                xCell = New System.Web.UI.WebControls.TableCell

                xCell.Font.Size = FontUnit.XXSmall
                xCell.HorizontalAlign = HorizontalAlign.Center
                xCell.Text = yArr(j + k)

                ' Delta Row
                diffCell = New System.Web.UI.WebControls.TableCell

                diffCell.Font.Size = FontUnit.XXSmall
                diffCell.HorizontalAlign = HorizontalAlign.Center

                If k = 0 And j = 0 Then
                    diffCell.Text = "Delta %"
                    diffCell.BackColor = Color.LightGray
                Else
                    curVal = Double.Parse(yArr(j + k))
                    prevVal = Double.Parse(yArr(j - 1 + k))
                    If (curVal = 0 And prevVal = 0) Then
                        delta = 0
                    Else
                        delta = Math.Round(((curVal - prevVal) / prevVal) * 100, 1)
                    End If

                    If metric.ToLower() <> "throughput" Then
                        delta = -delta
                    End If

                    If delta <= -threshold Then
                        diffCell.BackColor = Color.Red
                        diffCell.ForeColor = Color.White
                        If (j + k) = innerIndex Then
                            xCell.BackColor = Color.Red
                            xCell.ForeColor = Color.White
                            yCell.BackColor = Color.Red
                            yCell.ForeColor = Color.White
                        End If
                    ElseIf delta >= threshold Then
                        diffCell.BackColor = Color.ForestGreen
                        diffCell.ForeColor = Color.White
                        If (j + k) = innerIndex Then
                            xCell.BackColor = Color.ForestGreen
                            xCell.ForeColor = Color.White
                            yCell.BackColor = Color.ForestGreen
                            yCell.ForeColor = Color.White
                        End If
                    End If
                    diffCell.Text = delta.ToString()

                End If
                xRow.Cells.Add(xCell)
                yRow.Cells.Add(yCell)
                diffRow.Cells.Add(diffCell)

                k += 1
            End While

            tbl.Rows.Add(yRow)
            tbl.Rows.Add(xRow)
            tbl.Rows.Add(diffRow)

            row = New System.Web.UI.WebControls.TableRow
            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(tbl)
            cell.ColumnSpan = 2
            row.Cells.Add(cell)

            tblOut.Rows.Add(row)

            j += 10

        End While

    End Function

    Private Function AddChartCell(ByVal lastRole As String, ByVal lastTest As String, ByVal lastVariation As String, ByVal lastMetric As String, ByVal x As String, ByVal y As String, ByRef tbl As System.Web.UI.WebControls.Table)

        Dim title As String
        Dim roleInfo1 As String
        Dim roleInfo2 As String
        Dim testInfo1 As String
        Dim testInfo2 As String
        Dim variationInfo1 As String
        Dim variationInfo2 As String

        Dim cell As TableCell
        Dim row As TableRow

        title = lastRole & " -- " & lastTest & " - " & lastVariation

        roleInfo1 = "<b>Role:  </b>"
        roleInfo2 = lastRole
        Add2Cells(roleInfo1, roleInfo2, tbl)

        testInfo1 = "<b>Test:  </b>"
        testInfo2 = lastTest
        Add2Cells(testInfo1, testInfo2, tbl)

        variationInfo1 = "<b>Variation:  </b>"
        variationInfo2 = lastVariation
        Add2Cells(variationInfo1, variationInfo2, tbl)

        AddValuesRow(x, y, lastMetric, tbl)

        cell = New System.Web.UI.WebControls.TableCell
        row = New System.Web.UI.WebControls.TableRow

        Session("xValues") = x
        Session("yValues") = y

        cell.ColumnSpan = 2
        cell.Text = "<img src='ShowCharts.aspx?x=" & x & "&y=" & y & "&Title=" & title & "&Metric=" & lastMetric & "&Style=Line'>"
        row.Cells.Add(cell)
        tbl.Rows.Add(row)
    End Function

    Private Function AddChartCell(ByVal lastRole As String, ByVal lastTest As String, ByVal lastVariation As String, ByVal lastMetric As String, ByVal x As String, ByVal y As String, ByRef tbl As System.Web.UI.WebControls.Table, ByVal markedCells As String)

        Dim title As String
        Dim roleInfo1 As String
        Dim roleInfo2 As String
        Dim testInfo1 As String
        Dim testInfo2 As String
        Dim variationInfo1 As String
        Dim variationInfo2 As String

        Dim cell As TableCell
        Dim row As TableRow

        title = lastRole & " -- " & lastTest & " - " & lastVariation

        roleInfo1 = "<b>Role:  </b>"
        roleInfo2 = lastRole
        Add2Cells(roleInfo1, roleInfo2, tbl)

        testInfo1 = "<b>Test:  </b>"
        testInfo2 = lastTest
        Add2Cells(testInfo1, testInfo2, tbl)

        variationInfo1 = "<b>Variation:  </b>"
        variationInfo2 = lastVariation
        Add2Cells(variationInfo1, variationInfo2, tbl)

        AddValuesRow(x, y, lastMetric, tbl, markedCells)

        cell = New System.Web.UI.WebControls.TableCell
        row = New System.Web.UI.WebControls.TableRow

        Session("xValues") = x
        Session("yValues") = y

        cell.ColumnSpan = 2
        cell.Text = "<img src='ShowCharts.aspx?x=" & x & "&y=" & y & "&Title=" & title & "&Metric=" & lastMetric & "&Style=Line'>"
        row.Cells.Add(cell)
        tbl.Rows.Add(row)
    End Function


End Class




