Imports System.Data.SqlClient
Imports System.Collections.Specialized

Partial Class orcassp1reportcard
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents RunNav As LeftNav
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label


    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Const sm_NotFound As String = "N/A"
    Const sm_Disabled As String = ""
    Const ShowRCLinks As Boolean = True

    Dim RegressionCalculated As Boolean = False
    Dim ds As DataSet = New DataSet("myDataSet")
    Dim htBugs As New Hashtable
    Dim slBugs As New StringCollection
    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim dsIndigoThData As DataSet
    Dim dsComparativeThData As DataSet
    Dim dsScenarios As DataSet
    'Dim reportcard_id As Integer = 1
    Enum ReportCards
        ThroughputId = 1
        ThroughputId2 = 2
        ThroughputId3 = 3
        SMPThroughputId = 20
        ThroughputId4 = 101 'tier1 orcas reportcards
        ThroughputId5 = 102 'tier2 orcas reportcards
        ThroughputId6 = 103 ' asr
        ThroughputId7 = 130 'tier1 orcas sp1 reportcards
        ThroughputId8 = 131 'orcas sp1 ars
        ThroughputId9 = 132 'orcas sp1 featureteams

    End Enum
    Dim rcRun As Integer
    Dim regression_run As Integer

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' hides Run navigator on left side
        RunNav.ShowRunNavigator = False

        ' Used to set default.aspx to either reportcard or explorer depending on last visited
        'Dim cookie As New HttpCookie("PerfPage", "orreportcard")
        'cookie.Expires = DateTime.MaxValue
        'Response.Cookies.Add(cookie)

        'All report cards are on one page, but each metric is a different report card in DB
        ' Currently only one (rc=1) report card.
        ' If Convert.ToInt32(Request("rc")) > 0 Then
        ' reportcard_id = Convert.ToInt32(Request("rc"))
        ' Else
        '     reportcard_id = 1
        ' End If

        ' Not clear when this page is a post-back; main table has no forms, 
        ' and leftNav forms cause this to be reloaded with IsPostBack = false.
        If Not IsPostBack Then

            'Populates throughput reportcard grid (table)
            ShowRCThroughputStatus()
            ShowASRThroughputStatus()
            ShowFeatureTeamScorecardsStatus()

            ' Show when page was created
            CreatedStamp.Text = "Created: " + Now().ToShortDateString + " " + Now().ToLongTimeString
        End If

    End Sub
    ' Version 2.0: now using a table view to do all ratio calculations.
    Private Sub ShowRCThroughputStatus()

        ' Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        '   Gets this reportcard's data (id, purpose, criteria, enabled, OGF) and place in table.
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0} " + _
        "ORDER BY sort_order", ReportCards.ThroughputId7.ToString("d"))
        DBUtil.ExecDataSet(ds, selectString, "RCThroughputStatus")

        ' Bind table to datagrid.
        RCThroughput.DataSource = ds.Tables("RCThroughputStatus")
        RCThroughput.DataBind()

    End Sub

    Private Sub ShowASRThroughputStatus()

        '   Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        '   Gets this reportcard's data (id, purpose, criteria, enabled, OGF) and place in table.
        'Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0} " + _
        'Dim selectString As String = String.Format("SELECT * FROM w_reportcard_criteria_ogf WHERE reportcard_id = {0} " + _
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0} " + _
        "ORDER BY scenario_id", ReportCards.ThroughputId8.ToString("d"))
        DBUtil.ExecDataSet(ds, selectString, "ASRThroughputStatus")

        ' Bind table to datagrid.
        ASRThroughput.DataSource = ds.Tables("ASRThroughputStatus")
        ASRThroughput.DataBind()

    End Sub

    ' Also see FTScorecards_ItemDataBound for coloring logic
    Private Sub ShowFeatureTeamScorecardsStatus()
        '   Dataset that contains the table that will be bound to the grid
        Dim ds As New DataSet

        '   Gets this scorecards data and place in table.
        Dim selectString As String = String.Format("SELECT * FROM w_orcas_sp1_featureteams_scorecards_progress_ogf ORDER BY team")
        DBUtil.ExecDataSet(ds, selectString, "OrcasFTScorecardsStatus")

        ' Bind table to datagrid.
        OrcasFTScorecards.DataSource = ds.Tables("OrcasFTScorecardsStatus")
        OrcasFTScorecards.DataBind()
    End Sub

    ' version 1.0: fill in feature team scorecard from simple table
    Private Sub OrcasFTScorecards_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles OrcasFTScorecards.ItemDataBound
        Dim TeamColumn As Integer = 0
        Dim OwnerColumn As Integer = 1
        Dim BugsColumn As Integer = 2
        Dim ChartColumn As Integer = 3
        Dim OGFColumn As Integer = 3

        Dim psqLink As String

        'If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "ogf_color")) Then
        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim OGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "ogf_color"), String)
            Dim psq As String
            'Dim bugs As String = CType(DataBinder.Eval(e.Item.DataItem, "bugs"), String)

            If OGFColor.ToLower = "blue" Then
                e.Item.Cells(OGFColumn).BackColor = System.Drawing.Color.LightBlue
            Else
                e.Item.Cells(OGFColumn).BackColor = System.Drawing.Color.FromName(OGFColor)
            End If

            If OGFColor.ToLower = "green" Or OGFColor.ToLower = "red" Then
                'e.Item.Cells(OGFColumn).ForeColor = Color.White
                If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "link")) Then
                    psq = CType(DataBinder.Eval(e.Item.DataItem, "link"), String)
                    psqLink = String.Format("<a href='{0}' style='COLOR: {1}'>{2}</a>", psq, "#FFFFFF", OGFColor.ToLower)
                    e.Item.Cells(OGFColumn).Text = psqLink
                Else
                    e.Item.Cells(OGFColumn).ForeColor = Color.White
                End If
            End If

            If OGFColor.ToLower = "red" Or OGFColor.ToLower = "yellow" Then
                If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "issue")) Then
                    e.Item.Cells(OGFColumn).ToolTip = CType(DataBinder.Eval(e.Item.DataItem, "issue"), String)
                End If
            End If

            'Dim chartLinkText As String = CType(DataBinder.Eval(e.Item.DataItem, "link"), String)

            'If chartLinkText = "N/A" Then
            '    e.Item.Cells(ChartColumn).Text = "N/A"
            'End If
            'End If
        End If

    End Sub

    ' version 2.0: simplified; new coloring logic for report card scenarios
    Private Sub RCThroughput_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles RCThroughput.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns by number
        ' not used: Dim IDColumn As Integer = 0
        Dim DescriptionColumn As Integer = 1
        Dim ComparisonColumn As Integer = 2
        Dim CriteriaColumn As Integer = 3
        Dim V1Column As Integer = 4
        Dim OwnerColumn As Integer = 5
        Dim CommentsColumn As Integer = 6

        'Add link to glossary with detailed descriptions
        e.Item.Cells(DescriptionColumn).Text = String.Format("<a href='glossary.aspx#orcas_sp1_rc' style='COLOR: {0}'>{1}</a>", _
                                            "#3366cc", e.Item.Cells(DescriptionColumn).Text)

        'Get data; is scenario enabled? If not no data or goals yet.
        Dim IsEnabled As Boolean = CType(DataBinder.Eval(e.Item.DataItem, "enabled"), Boolean)

        'scenario id goes into construction of details link
        Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)

        Dim linkColor As String '= "#3366cc"

        'Only build links, add data, etc., for enabled tests
        If IsEnabled Then
            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria")) Then
                'Whidbey is compared with the criteria to determine the OGF
                'color the Criteria, because I can't get font coloring to work with hyperlinks
                Dim RTMOGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "rtm_ogf_color"), String)

                e.Item.Cells(V1Column).BackColor = System.Drawing.Color.FromName(RTMOGFColor)
                If RTMOGFColor = "green" Or RTMOGFColor = "red" Then
                    'e.Item.Cells(V1Column).ForeColor = Color.White
                    linkColor = "#FFFFFF"

                End If
            Else
                e.Item.Cells(V1Column).Text = "TBD"
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If

            Dim WhidbeyText As String

            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio")) Then
                Dim WhidbeyRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double))
                WhidbeyText = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}' style='COLOR: {4}'>{3}%</a>", 130, ScenarioId, True, WhidbeyRatio, linkColor)
                'Dim WhidbeyText As String = String.Format("{0}%", WhidbeyRatio)
                e.Item.Cells(V1Column).Text = WhidbeyText
            Else
                WhidbeyText = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}&tbd=true' style='COLOR: {3}'>TBD</a>", 130, ScenarioId, True, linkColor)
                e.Item.Cells(V1Column).Text = WhidbeyText
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If
        Else
            'no data if not enabled
            e.Item.Cells(V1Column).Text = "TBD"
            e.Item.Cells(V1Column).BackColor = Color.White
            e.Item.Cells(CriteriaColumn).Text = "TBD"
        End If

    End Sub

    Private Sub ASRThroughput_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles ASRThroughput.ItemDataBound

        'make sure we have a row element
        If e.Item.ItemType <> ListItemType.Item And e.Item.ItemType <> ListItemType.AlternatingItem Then
            Return
        End If

        'Don't have a better way to label columns by number
        ' not used: Dim IDColumn As Integer = 0
        Dim DescriptionColumn As Integer = 1
        Dim ComparisonColumn As Integer = 2
        Dim CriteriaColumn As Integer = 3
        Dim V1Column As Integer = 4
        Dim OwnerColumn As Integer = 5

        'Add link to glossary with detailed descriptions
        e.Item.Cells(DescriptionColumn).Text = String.Format("<a href='glossary.aspx#orcas_rc' style='COLOR: {0}'>{1}</a>", _
                                            "#3366cc", e.Item.Cells(DescriptionColumn).Text)

        'Get data; is scenario enabled? If not no data or goals yet.
        Dim IsEnabled As Boolean = CType(DataBinder.Eval(e.Item.DataItem, "enabled"), Boolean)

        'scenario id goes into construction of details link
        Dim ScenarioId As Integer = CType(DataBinder.Eval(e.Item.DataItem, "scenario_id"), Integer)

        Dim linkColor As String '= "#3366cc"

        'Only build links, add data, etc., for enabled tests
        If IsEnabled Then
            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "criteria")) Then
                'Whidbey is compared with the criteria to determine the OGF
                'color the Criteria, because I can't get font coloring to work with hyperlinks
                Dim RTMOGFColor As String = CType(DataBinder.Eval(e.Item.DataItem, "rtm_ogf_color"), String)

                e.Item.Cells(V1Column).BackColor = System.Drawing.Color.FromName(RTMOGFColor)
                If RTMOGFColor = "green" Or RTMOGFColor = "red" Then
                    'e.Item.Cells(V1Column).ForeColor = Color.White
                    linkColor = "#FFFFFF"

                End If
            Else
                e.Item.Cells(V1Column).Text = "TBD"
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If

            Dim WhidbeyText As String

            If Not IsDBNull(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio")) Then
                Dim WhidbeyRatio As Double = Math.Floor(CType(DataBinder.Eval(e.Item.DataItem, "whidbey_ratio"), Double))
                WhidbeyText = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}' style='COLOR: {4}'>{3}%</a>", 131, ScenarioId, True, WhidbeyRatio, linkColor)
                'Dim WhidbeyText As String = String.Format("{0}%", WhidbeyRatio)
                e.Item.Cells(V1Column).Text = WhidbeyText
            Else
                WhidbeyText = String.Format("<a href='drilldown.aspx?rc={0}&scen={1}&w={2}&tbd=true' style='COLOR: {3}'>TBD</a>", 131, ScenarioId, True, linkColor)
                e.Item.Cells(V1Column).Text = WhidbeyText
                e.Item.Cells(CriteriaColumn).Text = "TBD"
            End If
        Else
            'no data if not enabled
            e.Item.Cells(V1Column).Text = "TBD"
            e.Item.Cells(V1Column).BackColor = Color.White
            e.Item.Cells(CriteriaColumn).Text = "TBD"
        End If

    End Sub
End Class

