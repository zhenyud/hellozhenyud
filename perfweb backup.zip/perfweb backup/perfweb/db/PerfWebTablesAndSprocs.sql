if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_csv]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_csv]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_csv_by_test]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_csv_by_test]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_comp_run_measurements2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_comp_run_measurements2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_goal_measurements]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_goal_measurements]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_jobrun_measurements]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_jobrun_measurements]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_measurement_types]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_measurement_types]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_reportcard_details]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_reportcard_details]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_run_details]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_run_details]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_run_measurements2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_run_measurements2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_get_testname2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_get_testname2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_getnotes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_getnotes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_goals2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_goals2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_jobruns]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_jobruns]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_rc_descriptions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_rc_descriptions]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_rc_runs2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_rc_runs2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_reportcard2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_reportcard2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_runstats]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_runstats]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_set_comparative]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_set_comparative]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_sp_trending2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [PerformanceAdmin].[w_sp_trending2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[FK_w_query_values_w_query_types]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [PerformanceAdmin].[w_query_values] DROP CONSTRAINT FK_w_query_values_w_query_types
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_w_scenarios_w_reportcards]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[w_scenarios] DROP CONSTRAINT FK_w_scenarios_w_reportcards
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[FK_w_reportcard2_w_scenario_details]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [PerformanceAdmin].[w_reportcard2_old] DROP CONSTRAINT FK_w_reportcard2_w_scenario_details
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_comparative]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [PerformanceAdmin].[w_comparative]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[w_query_types]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[w_query_types]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_query_values]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [PerformanceAdmin].[w_query_values]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[w_reportcards]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[w_reportcards]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[w_scenario_details]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[w_scenario_details]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[w_scenarios]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[w_scenarios]
GO

CREATE TABLE [PerformanceAdmin].[w_comparative] (
	[measured_value] [float] NOT NULL ,
	[variation] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[scenario_number] [int] NULL ,
	[comparative_tech] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[variation_id] [int] NOT NULL ,
	[measurement_type_id] [int] NULL ,
	[reportcard_id] [int] NULL ,
	[run_id] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[w_query_types] (
	[measurement_type_id] [int] IDENTITY (1, 1) NOT NULL ,
	[measurement_type] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[description] [char] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[showInGlossary] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [PerformanceAdmin].[w_query_values] (
	[scenario_id] [int] NOT NULL ,
	[measurement_type_id] [int] NULL ,
	[scenario_name] [varchar] (75) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[enabled] [bit] NULL ,
	[t_test_id] [int] NOT NULL ,
	[c_test_id] [int] NULL ,
	[c_goal_test_id] [int] NULL ,
	[t_labconfig_id] [int] NOT NULL ,
	[t_variation_id] [int] NOT NULL ,
	[t_role_id] [int] NOT NULL ,
	[t_metric_id] [int] NOT NULL ,
	[t_baseline] [float] NULL ,
	[t_goal] [float] NULL ,
	[t_criteria] [float] NULL ,
	[id] [int] IDENTITY (1, 1) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[w_reportcards] (
	[reportcard_id] [int] IDENTITY (1, 1) NOT NULL ,
	[description] [char] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[enabled] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[w_scenario_details] (
	[scenario_id] [int] NOT NULL ,
	[description] [char] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[comparative_tech] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Transport] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MEP] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[WSSec] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[WSRM] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Durable] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Tx] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Interop] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UsingSerializer] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProcessModel] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[w_scenarios] (
	[scenario_id] [int] IDENTITY (1, 1) NOT NULL ,
	[scenario_number] [int] NULL ,
	[reportcard_id] [int] NULL ,
	[description] [char] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[comparative_tech] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Transport] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MEP] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[WSSec] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[WSRM] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Durable] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Tx] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Interop] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UsingSerializer] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ProcessModel] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO



SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_csv 

@jobrun_id int

AS


SELECT     dbo.runs.run, dbo.jobruns.run_id, dbo.jobruns.jobrun_id, dbo.labconfigs.labconfig, dbo.machines.machine, dbo.roles.role, dbo.metrics.metric, 
                      dbo.variations.variation, dbo.measurements.measured_value
FROM         dbo.jobruns INNER JOIN
                      dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id INNER JOIN
                      dbo.metrics ON dbo.measurements.metric_id = dbo.metrics.metric_id INNER JOIN
                      dbo.labconfigs ON dbo.jobruns.labconfig_id = dbo.labconfigs.labconfig_id INNER JOIN
                      dbo.runs ON dbo.jobruns.run_id = dbo.runs.run_id INNER JOIN
                      dbo.machines ON dbo.processes.machine_id = dbo.machines.machine_id INNER JOIN
                      dbo.roles ON dbo.processes.role_id = dbo.roles.role_id INNER JOIN
                      dbo.variations ON dbo.processes.variation_id = dbo.variations.variation_id
WHERE     (dbo.jobruns.jobrun_id = @jobrun_id)
ORDER BY dbo.jobruns.run_id, dbo.jobruns.jobrun_id, dbo.labconfigs.labconfig, dbo.machines.machine, dbo.roles.role, dbo.metrics.metric, 
                      dbo.variations.variation
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_csv_by_test 

	@run_id Int,
	@test_id Int


AS

SELECT     dbo.runs.run, dbo.jobruns.run_id, dbo.jobruns.jobrun_id, dbo.labconfigs.labconfig, dbo.machines.machine, dbo.roles.role, dbo.metrics.metric, 
                      dbo.variations.variation, dbo.measurements.measured_value
FROM         dbo.jobruns INNER JOIN
                      dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id INNER JOIN
                      dbo.metrics ON dbo.measurements.metric_id = dbo.metrics.metric_id INNER JOIN
                      dbo.labconfigs ON dbo.jobruns.labconfig_id = dbo.labconfigs.labconfig_id INNER JOIN
                      dbo.runs ON dbo.jobruns.run_id = dbo.runs.run_id INNER JOIN
                      dbo.machines ON dbo.processes.machine_id = dbo.machines.machine_id INNER JOIN
                      dbo.roles ON dbo.processes.role_id = dbo.roles.role_id INNER JOIN
                      dbo.variations ON dbo.processes.variation_id = dbo.variations.variation_id
WHERE     (dbo.jobruns.test_id = @test_id) AND (dbo.jobruns.run_id = @run_id)
ORDER BY dbo.jobruns.run_id, dbo.jobruns.jobrun_id, dbo.labconfigs.labconfig, dbo.machines.machine, dbo.roles.role, dbo.metrics.metric, 
                      dbo.variations.variation
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_comp_run_measurements2

	@run_id Int,
	@scenario_number Int,
	@metric Int,
	@reportcard_id Int = 1

AS

SELECT     dbo.measurements.measured_value, dbo.variations.variation
FROM         dbo.jobruns INNER JOIN
                      dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      w_query_values wrc ON dbo.jobruns.test_id = wrc.c_test_id AND dbo.jobruns.run_id = @run_id AND dbo.jobruns.validity = 2 AND 
                      wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                      dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id AND 
                      wrc.measurement_type_id = @metric INNER JOIN
                      dbo.variations ON dbo.processes.variation_id = dbo.variations.variation_id AND dbo.processes.variation_id = dbo.variations.variation_id INNER JOIN
                      dbo.w_scenarios ON wrc.scenario_id = dbo.w_scenarios.scenario_id
WHERE     (dbo.w_scenarios.scenario_id = @scenario_number AND dbo.w_scenarios.reportcard_id = @reportcard_id)
ORDER BY CAST(REPLACE(REPLACE(REPLACE(dbo.variations.variation, 'K', '000'), 'M', '000000'), 'bytes', '') AS FLOAT)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_goal_measurements

	@scenario_number Int,
	@metric Int,
	@reportcard_id Int = 1
 AS

SELECT     measured_value, variation, run_id
FROM         w_comparative
WHERE     (scenario_number =@scenario_number) AND (measurement_type_id = @metric) AND (reportcard_id = @reportcard_id)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_jobrun_measurements

	@metric_id Int,
	@jobrun_id Int

AS


SELECT     SUM(dbo.measurements.measured_value) AS measured_value, dbo.variations.variation, dbo.roles.role, dbo.roles.role_id
FROM         dbo.measurements INNER JOIN
                      dbo.processes ON dbo.processes.process_id = dbo.measurements.process_id INNER JOIN
                      dbo.roles ON dbo.roles.role_id = dbo.processes.role_id INNER JOIN
                      dbo.variations ON dbo.variations.variation_id = dbo.processes.variation_id
WHERE     (dbo.processes.jobrun_id = @jobrun_id) AND (dbo.measurements.metric_id = @metric_id)
GROUP BY dbo.variations.variation, dbo.roles.role, dbo.roles.role_id
HAVING      (dbo.roles.role_id = 2)
ORDER BY MIN(dbo.processes.[date]), dbo.variations.variation, dbo.roles.role
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_measurement_types AS

SELECT     measurement_type, [description]
FROM         dbo.w_query_types
WHERE     (showInGlossary = 1)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_reportcard_details 

	@reportcard_id Int =1

AS

SELECT     dbo.w_scenarios.scenario_number, dbo.w_reportcards.reportcard_id, dbo.w_scenarios.comparative_tech, dbo.w_scenarios.description, 
                      dbo.w_scenarios.Transport, dbo.w_scenarios.MEP, dbo.w_scenarios.WSSec, dbo.w_scenarios.WSRM, dbo.w_scenarios.Durable, dbo.w_scenarios.Tx, 
                      dbo.w_scenarios.Interop, dbo.w_scenarios.UsingSerializer, dbo.w_scenarios.ProcessModel
FROM         dbo.w_scenarios INNER JOIN
                      dbo.w_reportcards ON dbo.w_scenarios.reportcard_id = dbo.w_reportcards.reportcard_id
WHERE     (dbo.w_reportcards.reportcard_id = @reportcard_id)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_get_run_details 

@run_id integer

AS

SELECT     TOP 1 dbo.runs.run_id, dbo.runs.run, dbo.runs.validity,
                          (SELECT     MIN(date)
                            FROM          jobruns INNER JOIN
                                                   processes ON processes.jobrun_id = jobruns.jobrun_id
                            WHERE      jobruns.run_id = runs.run_id) AS run_date, dbo.frameworks.framework
FROM         dbo.runs INNER JOIN
                      dbo.jobruns ON dbo.runs.run_id = dbo.jobruns.run_id AND dbo.runs.run_id = dbo.jobruns.run_id INNER JOIN
                      dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      dbo.frameworks ON dbo.processes.framework_id = dbo.frameworks.framework_id
WHERE     (dbo.runs.run_id = @run_id)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_run_measurements2

	@run_id Int,
	@scenario_number Int,
	@metric Int,
	@reportcard_id Int = 1

AS

SELECT     dbo.measurements.measured_value, dbo.variations.variation
FROM         dbo.jobruns INNER JOIN
                      dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      w_query_values wrc ON dbo.jobruns.test_id = wrc.t_test_id AND dbo.jobruns.run_id = @run_id AND dbo.jobruns.validity = 2 AND 
                      wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                      dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id AND 
                      wrc.measurement_type_id = @metric INNER JOIN
                      dbo.variations ON dbo.processes.variation_id = dbo.variations.variation_id AND dbo.processes.variation_id = dbo.variations.variation_id INNER JOIN
                      dbo.w_scenarios ON wrc.scenario_id = dbo.w_scenarios.scenario_id
WHERE     (dbo.w_scenarios.scenario_id = @scenario_number AND dbo.w_scenarios.reportcard_id = @reportcard_id)
ORDER BY CAST(REPLACE(REPLACE(REPLACE(dbo.variations.variation, 'K', '000'), 'M', '000000'), 'bytes', '') AS FLOAT)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_get_testname2 

	@scenario_number Int,
	@reportcard_id int = 1,
	@metric int = 1
	-- 1 = reportcard test
	-- 2 = comparative tech
	-- 3 = reportcard goals

AS

SELECT     (SELECT     dbo.tests.test
                       FROM          dbo.w_scenarios INNER JOIN
                                              w_query_values ON dbo.w_scenarios.scenario_id = w_query_values.scenario_id INNER JOIN
                                              dbo.tests ON w_query_values.t_test_id = dbo.tests.test_id
                       WHERE      (dbo.w_scenarios.scenario_number = @scenario_number) AND (dbo.w_scenarios.reportcard_id = @reportcard_id) AND (w_query_values.measurement_type_id = @metric)) 
                      + ';' +
                          (SELECT     dbo.tests.test
                            FROM          dbo.w_scenarios INNER JOIN
                                                   w_query_values ON dbo.w_scenarios.scenario_id = w_query_values.scenario_id INNER JOIN
                                                   dbo.tests ON w_query_values.c_test_id = dbo.tests.test_id
                            WHERE      (dbo.w_scenarios.scenario_number = @scenario_number) AND (dbo.w_scenarios.reportcard_id = @reportcard_id) AND (w_query_values.measurement_type_id = @metric)) 
                      + ';' +
                          (SELECT     dbo.tests.test
                            FROM          dbo.w_scenarios INNER JOIN
                                                   w_query_values ON dbo.w_scenarios.scenario_id = w_query_values.scenario_id INNER JOIN
                                                   dbo.tests ON w_query_values.c_goal_test_id = dbo.tests.test_id
                            WHERE      (dbo.w_scenarios.scenario_number = @scenario_number) AND (dbo.w_scenarios.reportcard_id = @reportcard_id) AND (w_query_values.measurement_type_id = @metric)) 
                      AS TestNames
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_getnotes

	@jobrun_id Int

 AS

SELECT     dbo.jobrun_notes.note, dbo.jobrun_notes.username, dbo.jobrun_notes.[date], dbo.jobrun_notes.jobrun_id, dbo.jobruns.run_id
FROM         dbo.jobrun_notes INNER JOIN
                      dbo.jobruns ON dbo.jobrun_notes.jobrun_id = dbo.jobruns.jobrun_id
WHERE     (dbo.jobrun_notes.jobrun_id = @jobrun_id)
ORDER BY dbo.jobrun_notes.[date]
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_goals2

	@reportcard_id Int = 1

 AS

SELECT     wrc.scenario_number AS #, wrc.comparative_tech AS scenario_name,
                          (SELECT     t_goal
                            FROM          w_query_values
                            WHERE      measurement_type_id = 1 AND wrc.scenario_id = scenario_id AND enabled = 1) * 100 AS t_goal,
                          (SELECT     t_goal
                            FROM          w_query_values
                            WHERE      measurement_type_id = 2 AND wrc.scenario_id = scenario_id AND enabled = 1) * 100 AS l_goal,
                          (SELECT     t_criteria
                            FROM          w_query_values
                            WHERE      measurement_type_id = 1 AND wrc.scenario_id = scenario_id AND enabled = 1) * 100 AS t_criteria,
                          (SELECT     t_criteria
                            FROM          w_query_values
                            WHERE      measurement_type_id = 2 AND wrc.scenario_id = scenario_id AND enabled = 1) * 100 AS l_criteria,
(SELECT     w_comparative.measured_value
			FROM         w_query_values INNER JOIN
	                      dbo.w_scenarios ON w_query_values.scenario_id = dbo.w_scenarios.scenario_id INNER JOIN
	             	         w_comparative ON dbo.w_scenarios.scenario_number = w_comparative.scenario_number AND 
	             	         w_query_values.t_variation_id = w_comparative.variation_id AND w_query_values.measurement_type_id = w_comparative.measurement_type_id AND
	             	          dbo.w_scenarios.reportcard_id = w_comparative.reportcard_id
			WHERE     (w_comparative.measurement_type_id = 1) AND (w_comparative.reportcard_id = @reportcard_id) AND (w_comparative.scenario_number = wrc.scenario_number)) as t_Baseline,
(SELECT     w_comparative.measured_value
			FROM         w_query_values INNER JOIN
	                      dbo.w_scenarios ON w_query_values.scenario_id = dbo.w_scenarios.scenario_id INNER JOIN
	             	         w_comparative ON dbo.w_scenarios.scenario_number = w_comparative.scenario_number AND 
	             	         w_query_values.t_variation_id = w_comparative.variation_id AND w_query_values.measurement_type_id = w_comparative.measurement_type_id AND
	             	          dbo.w_scenarios.reportcard_id = w_comparative.reportcard_id
			WHERE     (w_comparative.measurement_type_id = 2) AND (w_comparative.reportcard_id = @reportcard_id) AND (w_comparative.scenario_number = wrc.scenario_number)) as l_Baseline
FROM         dbo.w_scenarios wrc INNER JOIN
                      dbo.w_reportcards ON wrc.reportcard_id = dbo.w_reportcards.reportcard_id INNER JOIN
                      w_query_values ON wrc.scenario_id = wrc.scenario_id INNER JOIN
                      dbo.w_query_types ON w_query_values.measurement_type_id = dbo.w_query_types.measurement_type_id AND 
                      w_query_values.measurement_type_id = dbo.w_query_types.measurement_type_id
WHERE     (dbo.w_reportcards.reportcard_id = @reportcard_id)
GROUP BY wrc.scenario_id, wrc.scenario_number, wrc.comparative_tech
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO


CREATE  PROCEDURE w_sp_jobruns

	@run_id int

 AS

SELECT     dbo.tests.test, dbo.labconfigs.labconfig, jr.jobrun_id ,
                          (SELECT     COUNT(DISTINCT dbo.processes.variation_id) AS Failed
                            FROM          dbo.jobruns INNER JOIN
                                                   dbo.processes ON (dbo.jobruns.jobrun_id = dbo.processes.jobrun_id)
                            WHERE      (dbo.jobruns.jobrun_id = jr.jobrun_id) AND dbo.processes.failed = 1) AS Failed,
                          (SELECT     COUNT(DISTINCT dbo.processes.variation_id) AS Failed
                            FROM          dbo.jobruns INNER JOIN
                                                   dbo.processes ON (dbo.jobruns.jobrun_id = dbo.processes.jobrun_id)
                            WHERE      (dbo.jobruns.jobrun_id = jr.jobrun_id)) AS Total, MIN(dbo.processes.[date]) AS Date ,loglocation, dbo.tests.test_id
			
FROM         dbo.jobruns jr INNER JOIN
                      dbo.processes ON jr.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      dbo.variations ON dbo.processes.variation_id = dbo.variations.variation_id INNER JOIN
                      dbo.tests ON jr.test_id = dbo.tests.test_id INNER JOIN
                      dbo.labconfigs ON jr.labconfig_id = dbo.labconfigs.labconfig_id
WHERE     (jr.run_id = @run_id)
GROUP BY dbo.tests.test, dbo.tests.test_id, dbo.labconfigs.labconfig, jr.jobrun_id, loglocation
ORDER BY dbo.tests.test, MIN(dbo.processes.[date]) DESC, dbo.labconfigs.labconfig

GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_rc_descriptions

 AS


SELECT     w_reportcard2.measurement_type_id, dbo.w_measurement_types.measurement_type, w_reportcard2.t_metric_id, dbo.metrics.metric, 
                      w_reportcard2.scenario_number, dbo.w_scenario_details.comparative_tech, dbo.labconfigs.labconfig, w_reportcard2.t_labconfig_id, 
                      w_reportcard2.t_variation_id, dbo.variations.variation, w_reportcard2.t_test_id, dbo.tests.test, w_reportcard2.scenario_id, dbo.roles.role, 
                      w_reportcard2.t_role_id, w_reportcard2.t_criteria, w_reportcard2.t_goal, w_reportcard2.t_baseline, w_reportcard2.enabled, 
                      w_reportcard2.scenario_name
FROM         w_reportcard2 INNER JOIN
                      dbo.w_measurement_types ON w_reportcard2.measurement_type_id = dbo.w_measurement_types.measurement_type_id LEFT OUTER JOIN
                      dbo.roles ON w_reportcard2.t_role_id = dbo.roles.role_id LEFT OUTER JOIN
                      dbo.w_scenario_details ON w_reportcard2.scenario_number = dbo.w_scenario_details.scenario_id LEFT OUTER JOIN
                      dbo.tests ON w_reportcard2.t_test_id = dbo.tests.test_id LEFT OUTER JOIN
                      dbo.variations ON w_reportcard2.t_variation_id = dbo.variations.variation_id LEFT OUTER JOIN
                      dbo.labconfigs ON w_reportcard2.t_labconfig_id = dbo.labconfigs.labconfig_id LEFT OUTER JOIN
                      dbo.metrics ON w_reportcard2.t_metric_id = dbo.metrics.metric_id
ORDER BY w_reportcard2.scenario_number, w_reportcard2.measurement_type_id
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_rc_runs2

	@reportcard_id int =1

 AS

SELECT     TOP 100 PERCENT dbo.runs.run, dbo.runs.run_id, MIN(dbo.processes.[date]) AS run_date, COUNT(DISTINCT dbo.jobruns.jobrun_id) AS jobrun_count, 
                      3 AS Validity
FROM         dbo.runs INNER JOIN
                      dbo.jobruns ON dbo.jobruns.run_id = dbo.runs.run_id INNER JOIN
                      w_query_values wrc ON wrc.t_test_id = dbo.jobruns.test_id AND wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.enabled = 1 AND wrc.measurement_type_id <= 2 INNER JOIN
                      dbo.processes ON dbo.processes.jobrun_id = dbo.jobruns.jobrun_id AND wrc.t_role_id = dbo.processes.role_id AND 
                      wrc.t_variation_id = dbo.processes.variation_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                      dbo.processes.process_id = dbo.measurements.process_id AND wrc.t_metric_id = dbo.measurements.metric_id INNER JOIN
                      dbo.w_scenarios ON wrc.scenario_id = dbo.w_scenarios.scenario_id
WHERE     (dbo.runs.validity = 2) AND (dbo.jobruns.validity = 2) AND (dbo.w_scenarios.reportcard_id = @reportcard_id)
GROUP BY dbo.runs.run, dbo.runs.run_id
HAVING      (COUNT(DISTINCT dbo.jobruns.jobrun_id) =
                          (SELECT     COUNT(*)
                            FROM          w_query_values INNER JOIN
                                                   dbo.w_scenarios ON w_query_values.scenario_id = dbo.w_scenarios.scenario_id
                            WHERE      (w_query_values.enabled = 1) AND (dbo.w_scenarios.reportcard_id = @reportcard_id)))
ORDER BY MIN(dbo.processes.[date]) DESC
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_reportcard2

	@run_id int,
	@regression_run_id int,
	@reportcard_id int =1

 AS


SELECT     w2.scenario_number AS scenario, w2.description AS Technology,
                          (SELECT     dbo.measurements.measured_value
                            FROM          dbo.jobruns INNER JOIN
                                                   dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                                                   w_query_values wrc ON dbo.jobruns.test_id = wrc.t_test_id AND dbo.jobruns.run_id = @run_id AND dbo.jobruns.validity = 2 AND 
                                                   wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id AND 
                                                   wrc.t_variation_id = dbo.processes.variation_id INNER JOIN
                                                   dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                                                   dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id AND 
                                                   wrc.measurement_type_id = 1 AND wrc.enabled = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS Throughput,
                          (SELECT     dbo.measurements.measured_value
                            FROM          dbo.jobruns INNER JOIN
                                                   dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                                                   w_query_values wrc ON dbo.jobruns.test_id = wrc.t_test_id AND dbo.jobruns.run_id = @regression_run_id AND dbo.jobruns.validity = 2 AND 
                                                   wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id AND 
                                                   wrc.t_variation_id = dbo.processes.variation_id INNER JOIN
                                                   dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                                                   dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id AND 
                                                   wrc.measurement_type_id = 1 AND wrc.enabled = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS Regression_Throughput,
                          (SELECT     dbo.measurements.measured_value
                            FROM          dbo.jobruns INNER JOIN
                                                   dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                                                   w_query_values wrc ON dbo.jobruns.test_id = wrc.t_test_id AND dbo.jobruns.run_id = @run_id AND dbo.jobruns.validity = 2 AND 
                                                   wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id AND 
                                                   wrc.t_variation_id = dbo.processes.variation_id INNER JOIN
                                                   dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                                                   dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id AND 
                                                   wrc.measurement_type_id = 2 AND wrc.enabled = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS Latency,
                          (SELECT     dbo.measurements.measured_value
                            FROM          dbo.jobruns INNER JOIN
                                                   dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                                                   w_query_values wrc ON dbo.jobruns.test_id = wrc.t_test_id AND dbo.jobruns.run_id = @regression_run_id AND dbo.jobruns.validity = 2 AND 
                                                   wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id AND 
                                                   wrc.t_variation_id = dbo.processes.variation_id INNER JOIN
                                                   dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                                                   dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id AND 
                                                   wrc.measurement_type_id = 2 AND wrc.enabled = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS Regression_Latency,
                        	(SELECT     w_comparative.measured_value
			FROM         w_query_values INNER JOIN
	                      dbo.w_scenarios ON w_query_values.scenario_id = dbo.w_scenarios.scenario_id INNER JOIN
	             	         w_comparative ON dbo.w_scenarios.scenario_number = w_comparative.scenario_number AND 
	             	         w_query_values.t_variation_id = w_comparative.variation_id AND w_query_values.measurement_type_id = w_comparative.measurement_type_id AND
	             	          dbo.w_scenarios.reportcard_id = w_comparative.reportcard_id
			WHERE     (w_comparative.measurement_type_id = 1) AND (w_comparative.reportcard_id = @reportcard_id) AND (w_comparative.scenario_number = w2.scenario_number)) as ThroughputBaseline,
		(SELECT     w_comparative.measured_value
			FROM         w_query_values INNER JOIN
	                      dbo.w_scenarios ON w_query_values.scenario_id = dbo.w_scenarios.scenario_id INNER JOIN
	             	         w_comparative ON dbo.w_scenarios.scenario_number = w_comparative.scenario_number AND 
	             	         w_query_values.t_variation_id = w_comparative.variation_id AND w_query_values.measurement_type_id = w_comparative.measurement_type_id AND
	             	          dbo.w_scenarios.reportcard_id = w_comparative.reportcard_id
			WHERE     (w_comparative.measurement_type_id = 2) AND (w_comparative.reportcard_id = @reportcard_id) AND (w_comparative.scenario_number = w2.scenario_number)) as LatencyBaseline,
                          (SELECT     t_goal
                            FROM          w_query_values INNER JOIN
                                                   w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id AND measurement_type_id = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS ThroughputGoal,
                          (SELECT     t_goal
                            FROM          w_query_values INNER JOIN
                                                   w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id AND measurement_type_id = 2
                            WHERE      wrc.scenario_id = w2.scenario_id) AS LatencyGoal,
                          (SELECT     t_Criteria
                            FROM          w_query_values INNER JOIN
                                                   w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id AND measurement_type_id = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS ThroughputCriteria,
                          (SELECT     t_Criteria
                            FROM          w_query_values INNER JOIN
                                                   w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id AND measurement_type_id = 2
                            WHERE      wrc.scenario_id = w2.scenario_id) AS LatencyCriteria,
	             (SELECT     enabled
                            FROM          w_query_values INNER JOIN
                                                   w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id AND measurement_type_id = 1
                            WHERE      wrc.scenario_id = w2.scenario_id) AS ThroughputEnabled,
	             (SELECT     enabled
                            FROM          w_query_values INNER JOIN
                                                   w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id AND measurement_type_id = 2
                            WHERE      wrc.scenario_id = w2.scenario_id) AS LatencyEnabled
FROM         dbo.w_scenarios w2 INNER JOIN
                      dbo.w_reportcards ON w2.reportcard_id = dbo.w_reportcards.reportcard_id INNER JOIN
                      w_query_values ON w2.scenario_id = w2.scenario_id INNER JOIN
                      dbo.w_query_types ON w_query_values.measurement_type_id = dbo.w_query_types.measurement_type_id AND 
                      w_query_values.measurement_type_id = dbo.w_query_types.measurement_type_id
WHERE     (dbo.w_reportcards.reportcard_id = @reportcard_id)
GROUP BY w2.scenario_id, w2.scenario_number, w2.description
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_runstats

	@run_id as int

 AS

SELECT     dbo.runs.run_id, dbo.runs.run, dbo.runs.validity, dbo.builds.build,
                          (SELECT     MIN(date)
                            FROM          jobruns INNER JOIN
                                                   processes ON processes.jobrun_id = jobruns.jobrun_id
                            WHERE      jobruns.run_id = runs.run_id) AS run_date,
                          (SELECT     COUNT(DISTINCT jobruns.test_id)
                            FROM          jobruns
                            WHERE      jobruns.run_id = runs.run_id) AS test_count,
                          (SELECT     COUNT(*)
                            FROM          jobruns
                            WHERE      jobruns.run_id = runs.run_id) AS jobrun_count,
                          (SELECT     COUNT(DISTINCT cast(jobruns.jobrun_id AS nvarchar) + cast(test_id AS nvarchar) + cast(variation_id AS nvarchar))
                            FROM          jobruns INNER JOIN
                                                   processes ON processes.jobrun_id = jobruns.jobrun_id
                            WHERE      jobruns.run_id = runs.run_id) AS variation_count,
                          (SELECT     COUNT(DISTINCT cast(jobruns.jobrun_id AS nvarchar) + cast(test_id AS nvarchar) + cast(variation_id AS nvarchar))
                            FROM          jobruns INNER JOIN
                                                   processes ON processes.jobrun_id = jobruns.jobrun_id
                            WHERE      jobruns.run_id = runs.run_id AND processes.failed = 1) AS failed_variation_count
FROM         dbo.runs INNER JOIN
                      dbo.builds ON dbo.builds.build_id = dbo.runs.build_id
WHERE     (dbo.runs.run_id = @run_id)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_set_comparative

	@run_id int,
	@reportcard_id int = 1

 AS

--if exists (select * from dbo.sysobjects where id = object_id(N'[PerformanceAdmin].[w_comparative]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--drop table [PerformanceAdmin].[w_comparative]

SELECT     dbo.measurements.measured_value, dbo.variations.variation, dbo.w_scenarios.scenario_number, dbo.w_scenarios.comparative_tech, 
                      dbo.processes.variation_id, wrc.measurement_type_id, @reportcard_id as reportcard_id, @run_id as run_id
INTO w_comparative
FROM         dbo.jobruns INNER JOIN
                      dbo.processes ON dbo.jobruns.jobrun_id = dbo.processes.jobrun_id INNER JOIN
                      w_query_values wrc ON dbo.jobruns.test_id = wrc.c_goal_test_id AND dbo.jobruns.run_id = @run_id  AND dbo.jobruns.validity = 2 AND 
                      wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.t_role_id = dbo.processes.role_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                      dbo.processes.process_id = dbo.measurements.process_id AND dbo.measurements.metric_id = wrc.t_metric_id INNER JOIN
                      dbo.variations ON dbo.processes.variation_id = dbo.variations.variation_id AND dbo.processes.variation_id = dbo.variations.variation_id INNER JOIN
                      dbo.w_scenarios ON wrc.scenario_id = dbo.w_scenarios.scenario_id
WHERE     (wrc.enabled = 1) AND (dbo.w_scenarios.reportcard_id = @reportcard_id)
ORDER BY dbo.w_scenarios.scenario_number, CAST(REPLACE(REPLACE(REPLACE(dbo.variations.variation, 'K', '000'), 'M', '000000'), 'bytes', '') AS FLOAT)
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

setuser N'PerformanceAdmin'
GO

CREATE PROCEDURE w_sp_trending2

	@scenario_number int,
	@metric int,
	@reportcard_id int = 1

AS

declare @baseline Int

SELECT     @baseline = w_comparative.measured_value
FROM         w_query_values INNER JOIN
                      dbo.w_scenarios wrc ON w_query_values.scenario_id = wrc.scenario_id INNER JOIN
                      w_comparative ON w_query_values.scenario_id = w_comparative.scenario_number AND 
                      w_query_values.t_variation_id = w_comparative.variation_id AND w_comparative.measurement_type_id =@metric
WHERE     (wrc.scenario_number = @scenario_number) AND wrc.reportcard_id = @reportcard_id


SELECT     TOP 100 PERCENT dbo.runs.run, dbo.runs.run_id, MIN(dbo.processes.[date]) AS run_date, COUNT(DISTINCT dbo.jobruns.jobrun_id) AS jobrun_count, 
                      ROUND(dbo.measurements.measured_value /
                          (@baseline * wrc.t_goal) * 100, 2) 
                      AS measured_value, dbo.jobruns.validity AS Validity
FROM         dbo.runs INNER JOIN
                      dbo.jobruns ON dbo.jobruns.run_id = dbo.runs.run_id INNER JOIN
                      w_query_values wrc ON wrc.t_test_id = dbo.jobruns.test_id AND wrc.t_labconfig_id = dbo.jobruns.labconfig_id AND wrc.enabled = 1 INNER JOIN
                      dbo.processes ON dbo.processes.jobrun_id = dbo.jobruns.jobrun_id AND wrc.t_role_id = dbo.processes.role_id AND 
                      wrc.t_variation_id = dbo.processes.variation_id INNER JOIN
                      dbo.measurements ON dbo.processes.process_id = dbo.measurements.process_id AND 
                      dbo.processes.process_id = dbo.measurements.process_id AND wrc.t_metric_id = dbo.measurements.metric_id INNER JOIN
                      dbo.w_scenarios ON wrc.scenario_id = dbo.w_scenarios.scenario_id
WHERE     (dbo.runs.validity = 2) AND (dbo.jobruns.validity = 2) AND (wrc.measurement_type_id = @metric) AND (dbo.w_scenarios.scenario_number = @scenario_number) AND (dbo.w_scenarios.reportcard_id = @reportcard_id)
GROUP BY dbo.runs.run, dbo.runs.run_id, dbo.measurements.measured_value, dbo.jobruns.validity, ROUND(dbo.measurements.measured_value /
                          (@baseline * wrc.t_goal) * 100, 2)
ORDER BY MIN(dbo.processes.[date]) DESC
GO
setuser
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

