Imports System.Data
Imports System.Data.SqlClient

Public Class ReportCardDB
    Shared perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Public Shared Function GetReportCardDataGeoMean(ByVal ReportCardId As Integer, ByVal RunId As Integer) As Double
        Dim ds As DataSet = GetReportCardStatus(ReportCardId, RunId)
        Return CalcGeoMean(ds, "measure_value", "comp_th")
    End Function
    '[AML] version 2.0 Simply return a table view containing all reportcard data
    Public Shared Function GetReportCardStatus(ByVal ReportCardId As Integer, ByVal tableName As String) As DataSet
        Dim ds As New DataSet
        Dim selectString As String = String.Format("SELECT * FROM w_reportcard_scenarios_status WHERE reportcard_id = {0}", ReportCardId)
        DBUtil.ExecDataSet(ds, selectString, tableName)
    End Function

    Private Shared Sub MergeData(ByRef Master As DataSet, ByVal Detail As DataSet)
        Dim row As DataRow
        Dim comprows() As DataRow
        Dim IndigoTh As Double
        Dim CompTh As Double
        Dim ThProduct As Double = 1
        Dim VariationCount As Integer = 0
        If Not Master.Tables(0) Is Nothing AndAlso Not Detail.Tables(0) Is Nothing Then
            Master.Tables(0).Columns.Add("comp_th", GetType(Double))
            Master.Tables(0).DefaultView.Sort = "scenario_id, variation_id"
            For Each row In Master.Tables(0).Rows
                comprows = Detail.Tables(0).Select(String.Format("scenario_id={0} AND variation_id={1}", row("scenario_id"), row("variation_id")))
                If Not (comprows Is Nothing) AndAlso comprows.Length > 0 Then
                    row("comp_th") = comprows(0)("measured_value")
                End If

            Next
        End If
    End Sub
    Private Shared Function CalcGeoMean(ByRef ds As DataSet, ByVal numerator As String, ByVal denominator As String) As Double
        Dim gm As Double
        If Not ds.Tables(0) Is Nothing Then
            Dim row As DataRow
            Dim count As Integer
            Dim product As Double = 1
            For Each row In ds.Tables(0).Rows
                product = product * (row(numerator) / row(denominator))
                count += 1
            Next
            gm = Math.Pow(product, 1 / count)
        End If
        Return gm
    End Function
        '[AML] Returns Report Card scenario data for all approved runs, sorted so that most recent is last. Data is placed in three tables
    Public Shared Sub GetScenarioData(ByRef ds As DataSet, ByVal ScenarioId As Integer)
        '[AML] Change order to date then jobrun_id, since jobrun_id is when database is updated, not when data is collected; build number would be better
        '[AML] metric_id=56 means throughput (in ops/sec) (see metrics table)
        '[AML] role_id=2 means server (see roles table), Indigo throughput reportcard is 1, and passed scenario ID
        '[AML] Sort by variation sort order also, to simplify logic for comparing runs.
        '[AML] Changed SQL views so that they only return allowed variations
        Dim whereString As String = String.Format("WHERE metric_id=56 AND role_id=2 AND reportcard_id = 1 AND scenario_id={0} ", ScenarioId)
        Dim orderString As String = "ORDER BY run_date, jobrun_id, variation_sortorder "

        '[AML] Get Indigo results
        DBUtil.ExecDataSet(ds, "SELECT * FROM w_rc_indigo_data " + whereString + orderString, "MainData")

        '[AML] Get Everett results
        DBUtil.ExecDataSet(ds, "SELECT * FROM w_rc_comparative_data " + whereString + orderString, "ComparativeData")

        '[AML] Get Whidbey results
        DBUtil.ExecDataSet(ds, "SELECT * FROM w_rc_whidbey_comparative_data " + whereString + orderString, "WhidbeyComparativeData")

    End Sub
    '[AML] Returns the Report Card Scenario definitions, RTM criteria, and OGF
    Public Shared Sub GetScenarios(ByRef ds As DataSet, ByVal TableName As String)
        DBUtil.ExecDataSet(ds, "SELECT scenario_id, scenario_purpose, throughput_criteria, enabled, ogf_color FROM w_reportcard_tests ORDER BY scenario_id", TableName)
    End Sub
End Class
