vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Mar 2004 23:45:11 -0000
vti_extenderversion:SR|6.0.2.5516
vti_cacheddtm:TX|18 Mar 2004 17:04:21 -0000
vti_filesize:IR|20556
vti_backlinkinfo:VX|
vti_modifiedby:SR|REDMOND\\a-clau
