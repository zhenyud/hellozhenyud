vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Feb 2004 23:44:37 -0000
vti_extenderversion:SR|6.0.2.5516
vti_cacheddtm:TX|24 Feb 2004 23:44:37 -0000
vti_filesize:IR|923
vti_backlinkinfo:VX|
