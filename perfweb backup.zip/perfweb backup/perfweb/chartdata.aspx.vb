Imports System.Data.SqlClient
Imports System.Collections.Specialized
Imports System.Web.UI.WebControls

Partial Class ChartData
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents lblError As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Friend perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Friend ScenarioDetail As String
    Private ds As DataSet
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Dim c As New base.PerfChart(Chart1, "Title", "xtitle", "y title")
        'c.AddSeries()


        Dim run_id As String = Request2String("rid")
        Dim jobrun_id As Integer = Request2Int("jrid")
        Dim metric_id As Integer = Request2Int("metric")
        Dim reportcard_id As Integer = Request2Int("rc", 1)
        Dim SeriesLabels() As String
        ds = New DataSet
        lblTest.Text = Server.UrlDecode(Request("test"))

        Try
            Dim runDisplay As runDetails = CType(Me.FindControl("RunDetails1"), runDetails)
            runDisplay.GetRunInfo(run_id)

            Dim c0 As New base.PerfChart(Chart1, "CPU Utilization at Throughput", "Operations per second", "")
            c0.size = "90,100,75,50"
            c0.yFieldName = "measured_value"
            c0.xFieldName = "variation"
            c0.AxisXMargin = True
            Dim tableName As String = jobrun_id.ToString()
            getJobRun(jobrun_id, 56, 2, 9, ds, tableName)

            Try
                If ds.Tables(tableName).Rows.Count > 0 Then
                    CreateValuesTable(ds, tableName, tblValues1, "Throughput (ops/Sec)")
                    'tblValues1.Caption = "Throughput (ops/Sec)"
                    'tblValues1.CaptionAlign = TableCaptionAlign.Left
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c0.AddSeries(ds.Tables(tableName).DefaultView, "variation", "measured_value", "Throughput / CPU Utilization", Dundas.Charting.WebControl.MarkerStyle.None, Color.Indigo, "Column")
                    tableName += "-Labels"
                    getJobRun(jobrun_id, 128, 2, 9, ds, tableName)
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c0.AddSeriesDataPointValueLabels("Throughput / CPU Utilization", ds.Tables(tableName).Rows, Color.Blue)
                    c0.ShowChart()
                Else
                    Chart1.Visible = False
                    'lblError1.Visible = True
                    'lblError1.Text = "Throughput measurements were not found in this job run"
                End If
            Catch ex As Exception
                Chart1.Visible = False
                lblError1.Visible = True
                lblError1.Text = "Error while plotting throughput chart: " + ex.ToString()
            End Try

            Dim checkTable As String = jobrun_id.ToString() + "-CheckForClientOnlyTests"
            getJobRunClientOnlyInfo(jobrun_id, ds, checkTable)

            Dim c4 As New base.PerfChart(Chart5, "Sum of Client Throughputs", "Operations per second", "")
            c4.size = "90,100,75,50"
            c4.yFieldName = "measured_value"
            c4.xFieldName = "variation"
            c4.AxisXMargin = True
            tableName = jobrun_id.ToString() + "-Sum of Client Throughput"
            getJobRunClientSum(jobrun_id, 56, 1, 9, ds, tableName)
            Try
                If ds.Tables(tableName).Rows.Count > 0 Then
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c4.AddSeries(ds.Tables(tableName).DefaultView, "variation", "measured_value", "Throughput", Dundas.Charting.WebControl.MarkerStyle.None, Color.BlueViolet, "Column")
                    'tableName += "-Labels"
                    'getJobRunClientSum(jobrun_id, 128, 1, 9, ds, tableName)
                    'ds.Tables(tableName).DefaultView.Sort = "Date"
                    'c4.AddSeriesDataPointValueLabels("Throughput / CPU Utilization", ds.Tables(tableName).Rows, Color.AliceBlue)
                    If ds.Tables(checkTable).Rows.Count > 0 Then
                        'tblValues5.Caption = "Sum of Client Throughputs (ops/sec)"
                        'tblValues5.CaptionAlign = TableCaptionAlign.Left
                        CreateValuesTable(ds, tableName, tblValues5, "Sum of Client Throughputs (ops/sec)")
                        c4.ShowChart()
                    Else
                        Chart5.Visible = False
                    End If

                Else
                    Chart5.Visible = False
                End If
            Catch ex As Exception
                Chart5.Visible = False
                lblError5.Visible = True
                lblError5.Text = "Error while plotting Sum of Client Throughputs chart: " + ex.ToString()
            End Try

            Dim c1 As New base.PerfChart(Chart2, "CPU Utilization at Latency", "seconds", "")
            c1.yFieldName = "measured_value"
            c1.xFieldName = "variation"
            c1.AxisXMargin = True
            tableName = jobrun_id.ToString() + "-Latency"
            getJobRun(jobrun_id, 87, 1, 9, ds, tableName)


            Try
                If ds.Tables(tableName).Rows.Count > 0 Then
                    CreateValuesTable(ds, tableName, tblValues2, "Latency (seconds)")
                    'tblValues2.Caption = "Latency (seconds)"
                    'tblValues2.CaptionAlign = TableCaptionAlign.Left
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c1.AddSeries(ds.Tables(tableName).DefaultView, "variation", "measured_value", "Latency / CPU Utilization", Dundas.Charting.WebControl.MarkerStyle.None, Color.Indigo, "Column")
                    tableName += "-Labels"
                    getJobRun(jobrun_id, 128, 1, 9, ds, tableName)
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c1.AddSeriesDataPointValueLabels("Latency / CPU Utilization", ds.Tables(tableName).Rows, Color.Blue)
                    c1.ShowChart()
                Else
                    Chart2.Visible = False
                    'lblError2.Visible = True
                    'lblError2.Text = "Latency measurements were not found in this job run"
                End If
            Catch ex As Exception
                Chart2.Visible = False
                lblError2.Visible = True
                lblError2.Text = "Latency measurements were not found in this job run"

            End Try

            Dim c2 As New base.PerfChart(Chart3, "Working Set", "Pages", "")
            c2.size = "90,100,75,50"
            c2.yFieldName = "measured_value"
            c2.xFieldName = "variation_and_role"
            c2.AxisXMargin = True
            tableName = jobrun_id.ToString() + "-Working Set"
            getJobRun(jobrun_id, 140, 1, 2, ds, tableName)


            Try
                If ds.Tables(tableName).Rows.Count > 0 Then
                    CreateValuesTable(ds, tableName, tblValues3, "Working Set (Pages)")
                    'tblValues3.Caption = "Working Set (Pages)"
                    'tblValues3.CaptionAlign = TableCaptionAlign.Left
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c2.AddSeries(ds.Tables(tableName).DefaultView, "variation_and_role", "measured_value", "Working Set", Dundas.Charting.WebControl.MarkerStyle.None, Color.Indigo, "Column")
                    c2.ShowChart()
                Else
                    Chart3.Visible = False
                    'lblError3.Visible = True
                    'lblError3.Text = "Working Set measurements were not found in this job run"
                End If
            Catch ex As Exception
                Chart3.Visible = False
                lblError3.Visible = True
                lblError3.Text = "Error while plotting Working Set chart: " + ex.ToString()
            End Try

            Dim c3 As New base.PerfChart(Chart4, "Reference Set", "MB", "")
            c3.size = "90,100,75,50"
            c3.yFieldName = "measured_value"
            c3.xFieldName = "variation"
            c3.AxisXMargin = True
            tableName = jobrun_id.ToString() + "-Unique File Backed"
            getJobRun(jobrun_id, 483, 1, 9, ds, tableName)

            Try
                If ds.Tables(tableName).Rows.Count > 0 Then

                    CreateValuesTable(ds, tableName, tblValues4, "Unique File Backed (MB)")
                    'tblValues4.Caption = "Unique File Backed (MB)"
                    'tblValues4.CaptionAlign = TableCaptionAlign.Left
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c3.AddSeries(ds.Tables(tableName).DefaultView, "variation", "measured_value", "Unique File Backed", Dundas.Charting.WebControl.MarkerStyle.None, Color.Indigo, "StackedColumn")
                    c3.AddSeriesDataPointValueLabels("Unique File Backed", ds.Tables(tableName).Rows, Color.Yellow, False)
                    tableName = jobrun_id.ToString() + "-Peak Dynamic"
                    getJobRun(jobrun_id, 484, 1, 9, ds, tableName)
                    'tblValues6.Caption = "Peak Dynamic (MB)"
                    'tblValues6.CaptionAlign = TableCaptionAlign.Left
                    CreateValuesTable(ds, tableName, tblValues6, "Peak Dynamic (MB)")
                    ds.Tables(tableName).DefaultView.Sort = "Date"
                    c3.AddSeries(ds.Tables(tableName).DefaultView, "variation", "measured_value", "Peak Dynamic", Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "StackedColumn")
                    c3.AddSeriesDataPointValueLabels("Peak Dynamic", ds.Tables(tableName).Rows, Color.Yellow, False)
                    c3.ShowChart()
                Else
                    Chart4.Visible = False
                    'lblError4.Visible = True
                    'lblError4.Text = "Unique File Backed measurements were not found in this job run"
                End If
            Catch ex As Exception
                Chart4.Visible = False
                lblError4.Visible = True
                lblError4.Text = "Error while plotting Unique File Backed  chart: " + ex.ToString()
            End Try

        Catch ex As Exception
        End Try
    End Sub

    Public Sub getJobRun(ByVal jobrun_id As String, ByVal metric As Integer, ByVal role_id As Integer, ByVal role_id2 As Integer, ByRef ds As DataSet, ByVal tableName As String)

        Dim myCommand As SqlCommand = New SqlCommand("w_sp_get_jobrun_measurements")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@metric_id", SqlDbType.Int)
            .Parameters(0).Value = metric

            .Parameters.Add("@jobrun_id", SqlDbType.Int)
            .Parameters(1).Value = jobrun_id

            .Parameters.Add("@role_id", SqlDbType.Int)
            .Parameters(2).Value = role_id

            .Parameters.Add("@role_id2", SqlDbType.Int)
            .Parameters(3).Value = role_id2
        End With

        DBUtil.ExecDataSet(ds, myCommand, tableName)

    End Sub

    Public Sub getJobRunClientSum(ByVal jobrun_id As String, ByVal metric As Integer, ByVal role_id As Integer, ByVal role_id2 As Integer, ByRef ds As DataSet, ByVal tableName As String)

        Dim myCommand As SqlCommand = New SqlCommand("w_sp_get_jobrun_measurements_sum_clients")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@metric_id", SqlDbType.Int)
            .Parameters(0).Value = metric

            .Parameters.Add("@jobrun_id", SqlDbType.Int)
            .Parameters(1).Value = jobrun_id

            .Parameters.Add("@role_id", SqlDbType.Int)
            .Parameters(2).Value = role_id

            .Parameters.Add("@role_id2", SqlDbType.Int)
            .Parameters(3).Value = role_id2

        End With

        DBUtil.ExecDataSet(ds, myCommand, tableName)

    End Sub

    Public Sub getJobRunClientOnlyInfo(ByVal jobrun_id As String, ByRef ds As DataSet, ByVal tableName As String)

        Dim myCommand As SqlCommand = New SqlCommand("w_sp_verify_jobrun_for_client_only_variations")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@jobrun_id", SqlDbType.Int)
            .Parameters(0).Value = jobrun_id
        End With

        DBUtil.ExecDataSet(ds, myCommand, tableName)

    End Sub

    Protected Function Request2String(ByVal key As String, Optional ByVal DefaultValue As String = Nothing) As String
        Try
            Return Request(key)
        Catch ex As Exception
            Return DefaultValue
        End Try
    End Function

    Protected Function Request2Int(ByVal key As String, Optional ByVal DefaultValue As Integer = 0) As Integer

        Try
            Dim Num As Integer = Convert.ToInt32(Request(key))
            If Num = 0 Then
                Return DefaultValue
            Else
                Return Num
            End If
        Catch ex As Exception
            Return DefaultValue
        End Try

    End Function

    Private Function CreateValuesTable(ByVal ds As DataSet, ByVal tblName As String, ByRef tbl As Table, ByVal caption As String)
        Dim cell As TableCell
        Dim row As TableRow
        Dim headers As String
        Dim values As String

        tbl.CellPadding = 3
        tbl.CellSpacing = 0
        tbl.BorderColor = Color.FromArgb(13421721) '#cccc99
        tbl.BorderStyle = BorderStyle.Solid
        tbl.GridLines = GridLines.Both
        tbl.BorderWidth = Unit.Pixel(1)
        tbl.Font.Size = FontUnit.XXSmall
        tbl.Font.Name = "Arial"

        row = New System.Web.UI.WebControls.TableRow

        Dim r As DataRow
        Dim k As Integer = 0
        Dim variation As String

        For Each r In ds.Tables(tblName).Rows
            cell = New System.Web.UI.WebControls.TableCell
            variation = ds.Tables(tblName).Rows(k).Item(1)
            cell.Text = variation
            headers += variation.Replace(",", ";") + ","
            row.Cells.Add(cell)
            k += 1
        Next

        headers.TrimEnd(",")

        tbl.Rows.Add(row)

        row = New System.Web.UI.WebControls.TableRow
        k = 0
        Dim val As String

        For Each r In ds.Tables(tblName).Rows
            cell = New System.Web.UI.WebControls.TableCell
            val = ds.Tables(tblName).Rows(k).Item(0)
            cell.Text = val
            values += val.Replace(",", ";") + ","
            row.Cells.Add(cell)
            k += 1
        Next

        tbl.Rows.Add(row)
        values.TrimEnd(",")

        Dim Link As String = caption.Substring(0, caption.IndexOf(" "))
        Dim csvLink As String = String.Format("&nbsp;&nbsp;<a href='csv.aspx?file={0}&type=table&headers={1}&values={2}'>csv</a>&nbsp;&nbsp;", Link, headers, values)
        tbl.Caption = caption + csvLink
        tbl.CaptionAlign = TableCaptionAlign.Left
    End Function

End Class

