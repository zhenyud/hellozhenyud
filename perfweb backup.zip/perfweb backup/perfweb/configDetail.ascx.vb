Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Xml
Imports System.Xml.XPath


Partial Class configDetail
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Structure MachineInfo
        Dim name As String
        Dim role As String
        Dim os As String
        Dim numOfProcs As String
        Dim avgCpuSpeed As String
        Dim memory As String
    End Structure

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim jobrun_id As Integer

        jobrun_id = Convert.ToInt32(Request.QueryString("jrid"))

        GetNotes(jobrun_id)

    End Sub

    Function GetNotes(ByVal jobrun_id As Integer)

        Dim role As System.Web.UI.WebControls.TableCell
        Dim machine As System.Web.UI.WebControls.TableCell
        Dim machine_config_id As System.Web.UI.WebControls.TableCell
        Dim osCell As System.Web.UI.WebControls.TableCell
        Dim numCpuCell As System.Web.UI.WebControls.TableCell
        Dim avgSpeedCpuCell As System.Web.UI.WebControls.TableCell
        Dim memoryCell As System.Web.UI.WebControls.TableCell

        Dim note As System.Web.UI.WebControls.TableCell
        Dim row As System.Web.UI.WebControls.TableRow

        Dim myConnection As SqlConnection
        Dim sqlCommand As SqlCommand
        Dim dr As SqlDataReader

        Dim headerDisplayed As Boolean = False

        Dim thisMachine As New MachineInfo

        Try
            myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            myConnection.Open()

            sqlCommand = New SqlCommand("w_sp_get_machineconfigs", myConnection)
            sqlCommand.CommandType = CommandType.StoredProcedure
            sqlCommand.Parameters.Add(New SqlParameter("@jobrun_id", jobrun_id))
            sqlCommand.ExecuteNonQuery()
            dr = sqlCommand.ExecuteReader()

            tblConfigDetails.CellPadding = 3
            tblConfigDetails.CellSpacing = 0
            tblConfigDetails.BorderColor = Color.FromArgb(13421721) '#cccc99
            tblConfigDetails.BorderStyle = BorderStyle.Solid
            'tblConfigDetails.BorderStyle = BorderStyle.None
            tblConfigDetails.BorderWidth = Unit.Pixel(2)
            tblConfigDetails.Width = Unit.Pixel(500)
            While dr.Read()

                If headerDisplayed = False Then

                    Dim title As New System.Web.UI.WebControls.TableCell
                    title.Text = "<IMG src=""Images/configdetails.gif"">"
                    title.ColumnSpan = 7
                    row = New System.Web.UI.WebControls.TableRow
                    row.Cells.Add(title)
                    tblConfigDetails.Rows.Add(row)

                    role = New System.Web.UI.WebControls.TableCell
                    machine = New System.Web.UI.WebControls.TableCell
                    machine_config_id = New System.Web.UI.WebControls.TableCell
                    osCell = New System.Web.UI.WebControls.TableCell
                    numCpuCell = New System.Web.UI.WebControls.TableCell
                    avgSpeedCpuCell = New System.Web.UI.WebControls.TableCell
                    memoryCell = New System.Web.UI.WebControls.TableCell
                    row = New System.Web.UI.WebControls.TableRow

                    role.Text = "Role"
                    machine.Text = "Machine"
                    machine_config_id.Text = "Config Id"
                    osCell.Text = "OS"
                    numCpuCell.Text = "Procs"
                    avgSpeedCpuCell.Text = "Cpu"
                    memoryCell.Text = "Memory"

                    row.Cells.Add(role)
                    row.Cells.Add(machine)
                    row.Cells.Add(osCell)
                    row.Cells.Add(numCpuCell)
                    row.Cells.Add(avgSpeedCpuCell)
                    row.Cells.Add(memoryCell)
                    row.Cells.Add(machine_config_id)

                    row.HorizontalAlign = HorizontalAlign.Center
                    tblConfigDetails.Rows.Add(row)

                    headerDisplayed = True

                End If

                role = New System.Web.UI.WebControls.TableCell
                machine = New System.Web.UI.WebControls.TableCell
                machine_config_id = New System.Web.UI.WebControls.TableCell
                osCell = New System.Web.UI.WebControls.TableCell
                numCpuCell = New System.Web.UI.WebControls.TableCell
                avgSpeedCpuCell = New System.Web.UI.WebControls.TableCell
                memoryCell = New System.Web.UI.WebControls.TableCell
                row = New System.Web.UI.WebControls.TableRow

                role.Text = dr.Item("role")
                machine.Text = dr.Item("machine")
                machine_config_id.Text = "<a href='showConfigDetails.aspx?configId=" & dr.Item("machine_config_id") & "' target='_blank'>" & dr.Item("machine_config_id") & "</a>"

                thisMachine = ShowMachineConfigs(Convert.ToString(dr.Item("machine_config_id")))
                thisMachine.name = machine.Text
                thisMachine.role = role.Text

                osCell.Text = thisMachine.os
                numCpuCell.Text = thisMachine.numOfProcs
                avgSpeedCpuCell.Text = thisMachine.avgCpuSpeed
                memoryCell.Text = thisMachine.memory

                row.Cells.Add(role)
                row.Cells.Add(machine)
                row.Cells.Add(osCell)
                row.Cells.Add(numCpuCell)
                row.Cells.Add(avgSpeedCpuCell)
                row.Cells.Add(memoryCell)
                row.Cells.Add(machine_config_id)

                row.HorizontalAlign = HorizontalAlign.Center
                tblConfigDetails.Rows.Add(row)

            End While

        Catch ex As Exception

            Dim errorMessage As String
            errorMessage = New String("Message: " & ex.Message & "\n" & "Source: " & ex.Source & "\n" & ex.StackTrace)
            Response.Write(errorMessage)

        Finally
            myConnection.Close()
            dr.Close()
        End Try

    End Function

    Private Function ShowMachineConfigs(ByVal machine_config_id As Integer) As MachineInfo

        Dim machine As New MachineInfo

        Dim myConnection As SqlConnection
        Dim sqlCommand As SqlCommand
        Dim dr As SqlDataReader
        Dim dbXml() As Byte

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myConnection.Open()

        sqlCommand = New SqlCommand("P_GetMachineConfig", myConnection)
        sqlCommand.CommandType = CommandType.StoredProcedure
        sqlCommand.Parameters.Add(New SqlParameter("@machine_config_id", machine_config_id))
        dr = sqlCommand.ExecuteReader()

        While dr.Read()

            dbXml = CType(dr.Item("xml"), Byte())
            Dim s As New System.IO.MemoryStream(dbXml)
            Dim textReader As New XmlTextReader(s)
            Dim rootNode As XmlNode

            Dim numOfProcs As New String("//machine/cpu/numberOfProcs")
            Dim avgSpeedOfProcs As New String("//machine/cpu/averageCpuSpeed")
            Dim memory As New String("//machine/memory/machineInfo/ramSize")
            Dim majorOs As New String("//machine/os/runtime/majorversion")
            Dim minorOs As New String("//machine/os/runtime/minorversion")
            Dim buildOs As New String("//machine/os/runtime/buildnumber")

            Dim gigs As Double

            Dim doc As XmlDocument = New XmlDocument
            doc.Load(textReader)
            rootNode = doc.SelectSingleNode("//machine")

            machine.numOfProcs = GetNodeInfo(rootNode, numOfProcs)
            machine.avgCpuSpeed = GetNodeInfo(rootNode, avgSpeedOfProcs) & " MHz"

            gigs = Convert.ToDouble(GetNodeInfo(rootNode, memory)) / (1024 * 1024 * 1024)
            machine.memory = String.Format("{0:n} GB", gigs)

            machine.os = GetNodeInfo(rootNode, buildOs)

        End While

        Return machine

    End Function

    Private Function GetNodeInfo(ByRef root As XmlNode, ByVal nodePath As String) As String

        Dim child As XmlNode
        Dim nr As XmlNodeReader
        Dim nodeInfo As String

        child = root.SelectSingleNode(nodePath)
        nr = New XmlNodeReader(child)
        nodeInfo = nr.ReadElementString()

        If IsDBNull(nodeInfo) Then
            nodeInfo = ""
        End If

        Return nodeInfo

    End Function


End Class
