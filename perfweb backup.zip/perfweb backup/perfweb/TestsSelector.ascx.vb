Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.McsMx.Web.Chart

Partial Class TestsSelector
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object
    Protected WithEvents DIV1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtError As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtException As System.Web.UI.WebControls.TextBox

    Protected runListsInitialized As Boolean = False

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

        If Not runListsInitialized Then
            GetRuntypes()
            runListsInitialized = True
            'Criteria.SelectedIndex = 0
        End If

    End Sub

#End Region
    Private table As DataTable
    Private ds As New DataSet
    Private dv As DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then

            btnCompare.Enabled = False
            btnRuns.Enabled = False
            chkAdvancedMode.Checked = False
            chkAdvancedMode.Enabled = False
            pnlAdvanced.Visible = False
            btnCharts.Enabled = False

            'btnCharts.Attributes.Add("onclick", "window.open('CreateCharts.aspx')")
            btnCharts.Attributes.Add("value", "New Window")

        End If
    End Sub
    Private Sub GetRuntypes()
        Dim connection As SqlConnection

        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        ' Fill in the list of runtypes for the "new run" runtype selector
        Dim sql As String
        Dim today As DateTime = DateTime.Now
        Dim selectedTimeSpan As Integer

        sql = "select distinct r.runtype_id,rt.runtype from runtypes rt inner join runs r on rt.runtype_id=r.runtype_id "

        If lstRecentTests.SelectedValue <> "All" Then
            selectedTimeSpan = Convert.ToInt16(lstRecentTests.SelectedValue)

            Dim diff1 As System.TimeSpan = New System.TimeSpan(selectedTimeSpan, 0, 0, 0)

            Dim selectedRunsDate As System.DateTime

            selectedRunsDate = today.Subtract(diff1)

            sql += " where r.start_date >= Cast('" + selectedRunsDate.ToShortDateString + "' As DateTime)"
        End If

        sql += " order by r.runtype_id"

        Dim sqlCommand As New SqlCommand(sql, connection)
        Dim sqlDataReader As SqlDataReader
        sqlDataReader = sqlCommand.ExecuteReader()

        Criteria.DataSource = sqlDataReader
        Criteria.DataTextField = "runtype"
        Criteria.DataValueField = "runtype_id"
        Criteria.DataBind()
        sqlDataReader.Close()
        connection.Close()

        Criteria.Items.Add(New ListItem("All", "-1"))

    End Sub

    Private Sub GetTests()
        Dim rowAll As System.Data.DataRow
        Dim cellAll As System.Data.DataRow

        ds = New DataSet
        Dim sql As String = "SELECT DISTINCT"

        Dim today As DateTime = DateTime.Now
        Dim selectedTimeSpan As Integer

        If lstRecentTests.SelectedValue <> "All" Then
            selectedTimeSpan = Convert.ToInt16(lstRecentTests.SelectedValue)

            sql += " Jobruns.Test_Id,Tests.Test FROM Tests INNER JOIN jobruns on jobruns.test_id=Tests.test_id INNER JOIN runs on runs.run_id=jobruns.run_id "

        Else
            sql += " Tests.Test_id, Tests.Test FROM Tests INNER JOIN jobruns on jobruns.test_id=Tests.test_id INNER JOIN runs on runs.run_id=jobruns.run_id "
        End If

        Dim diff1 As System.TimeSpan = New System.TimeSpan(selectedTimeSpan, 0, 0, 0)

        Dim selectedRunsDate As System.DateTime

        selectedRunsDate = today.Subtract(diff1)


        If Criteria.SelectedValue <> "All" Then
            sql += " WHERE runs.runtype_id=" & Criteria.SelectedValue.ToString() & " and "
        Else
            sql += " WHERE "
        End If

        If txtTestFilter.Text = "< string >" Then
            txtTestFilter.Text = ""
        End If

        sql += "Tests.Test Like '%" + txtTestFilter.Text + "%'"

        If lstRecentTests.SelectedValue <> "All" Then
            sql += " and runs.start_date >= Cast('" + selectedRunsDate.ToShortDateString + "' As DateTime)"
        End If

        DBUtil.ExecDataSet(ds, sql, "Tests")
        'ds.Tables("Tests").Rows.Add("All Tests")

        TestList.DataSource = ds.Tables("Tests")
        TestList.DataTextField = "Test"
        TestList.DataValueField = "Test_Id"
        TestList.DataBind()

        TestList.Items.Insert(0, "All Tests")

        Session("AllTests") = ds
    End Sub

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        GetTests()

        TestList.Enabled = True
        TestList.Visible = True
        dgRuns.Visible = False
        btnRuns.Enabled = True
        btnCompare.Enabled = False
        dgData.Visible = False


        txtAdvancedRunIDList.Text = ""
        txtAdvancedRunnameList.Text = ""

    End Sub

    Private Sub btnRuns_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRuns.Click
        'TO DO figure out how to get a list of what was selected
        'get runs that contain data for all of the selected tests
        Dim l As ListItem
        Dim s As String
        Dim al As New ArrayList
        Dim selectAll As Boolean = False

        If TestList.Items(0).Selected Then
            selectAll = True
        End If

        For Each l In TestList.Items
            'skip the 0th index
            If l.Value <> "All Tests" Then
                If l.Selected Or selectAll Then
                    If Not (s Is Nothing OrElse s.Length = 0) Then
                        s += ","
                    End If
                    s += l.Value
                    al.Add(l.Value)
                End If
            End If
        Next

        'txtError.Text = 
        Dim sql As String

        If (al.Count > 0) Then
            Session("SelectedTests") = s

            sql = "SELECT DISTINCT newruns.run_id, newruns.run, newruns.[description], newruns.labconfig_description FROM ("
            sql += " SELECT DISTINCT runs.run_id, runs.run, isNull(runtypes.[description], runtypes.runtype) as description, labconfigs.description as labconfig_description, jobruns.test_id  FROM jobruns"
            sql += " INNER JOIN runs ON jobruns.run_id=runs.run_id"
            sql += " INNER JOIN tests ON jobruns.test_id = tests.test_id"
            sql += " INNER JOIN runtypes ON runs.runtype_id = runtypes.runtype_id"
            sql += " INNER JOIN labconfigs ON runs.labconfig_id = labconfigs.labconfig_id"
            sql += " WHERE "

            If lstRuns.SelectedValue <> "All" Then
                Dim today As DateTime = DateTime.Now
                Dim selectedTimeSpan As Integer = Convert.ToInt16(lstRuns.SelectedValue)

                Dim diff1 As System.TimeSpan = New System.TimeSpan(selectedTimeSpan, 0, 0, 0)

                Dim selectedRunsDate As System.DateTime

                selectedRunsDate = today.Subtract(diff1)

                sql += "runs.start_date >= Cast('" + selectedRunsDate.ToShortDateString + "' As DateTime) AND "
            End If

            Dim i As Integer
            Dim summaryClause As String
            If Not chkSummary.Checked Then
                'only runs that have summary data
                summaryClause = "jobruns.validity=4 AND "
            Else
                summaryClause = ""
            End If

            Dim validityClause As String
            If chkValidity.Checked Then
                'only runs that have summary data
                validityClause = "runs.validity=2 AND "
            Else
                validityClause = ""
            End If

            sql += summaryClause + validityClause + "(jobruns.test_id=" + al(0)

            Dim tests As String = " or jobruns.test_id={0}"

            'start from second item because first item is already used above
            For i = 1 To al.Count - 1
                sql += String.Format(tests, al(i))
            Next

            sql += ") ) as newruns"

            If Not chkOR.Checked Then
                sql += " GROUP BY newruns.run_id, newruns.run, newruns.[description], newruns.labconfig_description HAVING count(*) = " + (al.Count).ToString()
            End If

            sql += " ORDER BY newruns.run_id DESC"
            'txtError.Text = sql

            ds = New DataSet

            Try

                DBUtil.ExecDataSet(ds, sql, "Runs")
                dv = New DataView(ds.Tables("Runs"))
                Session("dsRuns") = ds
                dgRuns.DataSource = dv 'ds.Tables("Runs")
                dgRuns.DataBind()

            Catch ex As Exception
                'txtException.Text = ex.Message
            End Try

            dgRuns.Visible = True

            'automatically select latest 3 runs
            Dim chkSelected As CheckBox
            Dim dgItem As DataGridItem
            Dim numSelectedRuns As Integer

            If chkSelectAll.Checked Then
                numSelectedRuns = dgRuns.Items.Count
            Else
                numSelectedRuns = 2
            End If

            For i = 0 To Math.Min(numSelectedRuns, dgRuns.Items.Count - 1)
                dgItem = dgRuns.Items(i)
                chkSelected = dgItem.FindControl("chkSelect")
                chkSelected.Checked = True
            Next

            'Make sure user can't change selected tests
            'TestList.Enabled = False
            btnCompare.Enabled = True
            btnCharts.Enabled = True
            chkAdvancedMode.Enabled = True
            'btnRuns.Enabled = False
            dgData.Visible = False

        End If
    End Sub

    Private Sub btnCompare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompare.Click
        'get selected tests
        'get selected runs
        'if chksummary is checked
        'get all data for selected runs and tests
        'else
        'get summary data for selected runs and tests
        'create a table per test to show history
        'Dim l As ListItem
        'Dim selruns As String

        'Try

        GetSelectedRuns()

        Dim selruns As String
        Dim clientOnlyTests As String

        selruns = CType(Session("selruns"), String)
        clientOnlyTests = CType(Session("clientOnlyTests"), String)

        Dim sql As String = "SELECT DISTINCT runs.run, runs.run_id, tests.test, jobruns.jobrun_id, jobruns.validity AS validity"
        sql += ", runtypes.runtype,  jobruns.test_id, measurements.measured_value, processes.role_id, processes.[date]"
        sql += ", variations.variation, variations.variation_sortorder, roles.role, metrics.metric"
        sql += ", isNull(runtypes.[description], runtypes.runtype) as description, labconfigs.description as labconfig_description"
        sql += " FROM runs INNER JOIN jobruns ON runs.run_id = jobruns.run_id"
        sql += " INNER JOIN tests ON jobruns.test_id = tests.test_id"
        sql += " INNER JOIN runtypes ON runs.runtype_id = runtypes.runtype_id"
        'sql += " INNER JOIN w_run_view ON runtypes.runtype_id = w_run_view.runtype_id"
        sql += " INNER JOIN processes ON jobruns.jobrun_id = processes.jobrun_id"
        sql += " INNER JOIN measurements ON processes.process_id = measurements.process_id"
        sql += " INNER JOIN variations ON processes.variation_id = variations.variation_id"
        sql += " INNER JOIN labconfigs ON runs.labconfig_id = labconfigs.labconfig_id"
        sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
        sql += " INNER JOIN roles on processes.role_id = roles.role_id WHERE "

        Dim sql3 As String = String.Empty
        If Not chkSummary.Checked Then
            sql3 = "(jobruns.validity = 4) AND "
        End If

        Dim sql1 As String 'runs with role_id only=1
        Dim sql2 As String 'runs with role_id=2 or role_id=9
        Dim clause As String

        'Dim typeOfTest As String = Criteria.SelectedValue.ToString()

        If (Criteria.SelectedItem.Text.IndexOf("Memory", 0) > 0) Then
            clause = "(metrics.metric like '%Module Count%' OR metrics.metric like '%Thread Count%' OR metrics.metric like '%Working Set%')"
            sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3}, {4}, {5})) ", Session("SelectedTests"), selruns, clause, 1, 2, 9)
        ElseIf (Criteria.SelectedItem.Text.IndexOf("Ref", 0) > 0) Then
            clause = "(metrics.metric like '%UniqueFileBacked%' OR metrics.metric like '%PeakDynamic%')"
            sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3}, {4}, {5})) ", Session("SelectedTests"), selruns, clause, 1, 2, 9)
        ElseIf ((Criteria.SelectedItem.Text.IndexOf("Startup", 0) > 0) Or (Criteria.SelectedItem.Text.IndexOf("Latency", 0) > 0)) Then
            clause = "(metrics.metric in ('AverageLatency','95thPercentileLatency'))"
            sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3}, {4}, {5})) ", Session("SelectedTests"), selruns, clause, 1, 2, 9)
        Else
            clause = "(measurements.metric_id = 56)"
            sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3}, {4})) ", Session("SelectedTests"), selruns, clause, 2, 9)
        End If

        sql1 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND {2} AND (processes.role_id IN ({3})) ", Session("clientOnlyTests"), selruns, clause, 1)

        If Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0) Then
            sql = sql & "(" & sql1 & ") OR (" & sql2 & ")"
        Else
            sql = sql & sql2
        End If

        sql += " ORDER BY jobruns.test_id, processes.role_id, variations.variation, metrics.metric, runs.run_id"

        'txtError.Text = sql

        ds = New DataSet
        DBUtil.ExecDataSet(ds, sql, "Data")
        dgData.DataSource = ds.Tables("Data")
        dgData.DataBind()
        'Catch ex As Exception
        '    txtException.Text += ex.Message & ex.Source & ex.StackTrace
        'End Try

        dgData.Visible = True
    End Sub

    Private Sub dgRuns_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles dgRuns.SortCommand

        Dim dataGrid As DataGrid = source
        Dim strSort = dataGrid.Attributes("SortExpression")
        Dim strASC = dataGrid.Attributes("SortASC")

        dataGrid.Attributes("SortExpression") = e.SortExpression
        dataGrid.Attributes("SortASC") = "Yes"

        If e.SortExpression = strSort Then
            If strASC = "Yes" Then
                dataGrid.Attributes("SortASC") = "No"
            Else
                dataGrid.Attributes("SortASC") = "Yes"
            End If
        End If

        ds = Session("dsRuns")
        dv = New DataView(ds.Tables("Runs"))

        dv.Sort = dataGrid.Attributes("SortExpression")

        If dataGrid.Attributes("SortASC") = "No" Then
            dv.Sort &= " DESC"
        End If

        dgRuns.DataSource = dv
        dgRuns.DataBind()

        'automatically select latest 3 runs
        Dim chkSelected As CheckBox
        Dim dgItem As DataGridItem
        Dim numSelectedRuns As Integer
        Dim i As Integer

        If chkSelectAll.Checked Then
            numSelectedRuns = dgRuns.Items.Count
        Else
            numSelectedRuns = 2
        End If

        For i = 0 To Math.Min(numSelectedRuns, dgRuns.Items.Count - 1)
            dgItem = dgRuns.Items(i)
            chkSelected = dgItem.FindControl("chkSelect")
            chkSelected.Checked = True
        Next
    End Sub

    Private Sub btnCharts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCharts.Click

        Dim summary As Boolean = False
        Dim advanced As Boolean = False
        Dim rcMemory As Boolean = False
        Dim indigoLatency As Boolean = False
        Dim rcRefset As Boolean = False

        If chkSummary.Checked Then
            summary = True
        End If

        If chkAdvancedMode.Checked Then
            advanced = True
        End If

        If (Criteria.SelectedItem.Text.IndexOf("Memory", 0) > 0) Then
            rcMemory = True
        ElseIf (Criteria.SelectedItem.Text.IndexOf("Refset", 0) > 0) Then
            rcRefset = True
        ElseIf ((Criteria.SelectedItem.Text.IndexOf("Startup", 0) > 0) Or (Criteria.SelectedItem.Text.IndexOf("Latency", 0) > 0)) Then
            indigoLatency = True
        End If

        GetSelectedRuns()

        Response.Redirect("CreateCharts.aspx?summary=" & summary.ToString() & "&advanced=" & advanced.ToString() & "&rcMemory=" & rcMemory.ToString() & "&rcRefset=" & rcRefset.ToString() & "&indigoLatency=" & indigoLatency.ToString())

    End Sub

    Private Function GetSelectedRuns()

        'get selected tests
        'get selected runs
        'get tests using only role_id=1

        Dim l As ListItem
        Dim selruns As String

        Dim dgItem As DataGridItem
        Dim chkSelected As CheckBox

        For Each dgItem In dgRuns.Items
            chkSelected = dgItem.FindControl("chkSelect")

            If chkSelected.Checked Then
                If Not (selruns Is Nothing OrElse selruns.Length = 0) Then
                    selruns += ","
                End If

                selruns += dgItem.Cells(1).Text

            End If
        Next

        Session("selruns") = selruns

        If chkAdvancedMode.Checked Then
            Session("selruns") = txtAdvancedRunIDList.Text
            Session("newRunnames") = txtAdvancedRunnameList.Text
        End If

        Dim sqlRole1 As String = "SELECT newruns.test_id FROM ( SELECT DISTINCT processes.role_id, jobruns.test_id"
        sqlRole1 += " FROM processes INNER JOIN jobruns ON jobruns.jobrun_id = processes.jobrun_id"
        sqlRole1 += String.Format(" WHERE processes.role_id IN ({0},{1},{2}) AND jobruns.run_id IN ({3}) AND jobruns.test_id IN ({4})", 1, 2, 9, selruns, Session("SelectedTests"))
        sqlRole1 += " ) AS newruns GROUP BY newruns.test_id HAVING count(*) = 1"

        'txtException.Text = sqlRole1

        Dim clientOnlyTests As String = String.Empty

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection

        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        command = New SqlCommand(sqlRole1, connection)

        dr = command.ExecuteReader()

        While dr.Read()
            clientOnlyTests += dr.Item("test_id") & ","
        End While

        If (Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0)) And clientOnlyTests.EndsWith(",") Then
            clientOnlyTests = clientOnlyTests.TrimEnd(",")
        End If

        Session("clientOnlyTests") = clientOnlyTests
    End Function

    Private Sub chkAdvancedMode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAdvancedMode.CheckedChanged

        If chkAdvancedMode.Checked Then
            pnlAdvanced.Visible = True
            pnlAdvanced.Height = Unit.Pixel(110)
        Else
            pnlAdvanced.Visible = False
            pnlAdvanced.Height = Unit.Pixel(0)
            Session("newRunnames") = ""
        End If

    End Sub

    Private Sub Criteria_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Criteria.SelectedIndexChanged

        'GetRuntypes()

    End Sub

    Private Sub lstRecentTests_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstRecentTests.SelectedIndexChanged
        GetRuntypes()
    End Sub
End Class
