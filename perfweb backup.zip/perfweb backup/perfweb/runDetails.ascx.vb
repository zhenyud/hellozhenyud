Imports System.Data.SqlClient
Imports System.Xml
Imports System.Xml.XPath

Partial Class runDetails
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim _RunID As Integer
    Dim _RunName As String



    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Public ReadOnly Property RunID() As Integer
        Get
            Return _RunID
        End Get
    End Property

    Public ReadOnly Property RunName() As String
        Get
            Return _RunName
        End Get
    End Property


    Public Property Run() As String
        Get
            Return lblRun.Text
        End Get
        Set(ByVal Value As String)
            lblRun.Text = Value
        End Set
    End Property

    Public Property RunDate() As String
        Get
            Return lblDate.Text
        End Get
        Set(ByVal Value As String)
            lblDate.Text = Value
        End Set
    End Property
    Public Property RunType() As String
        Get
            Return lblRuntype.Text
        End Get
        Set(ByVal Value As String)
            lblRuntype.Text = Value
        End Set
    End Property

    Public Property FxBuild() As String
        Get
            Return lblClrBuild.Text
        End Get
        Set(ByVal Value As String)
            lblClrBuild.Text = Value
        End Set
    End Property

    Public Property Build() As String
        Get
            Return lblBuild.Text
        End Get
        Set(ByVal Value As String)
            lblBuild.Text = Value
        End Set
    End Property
    Public Property NetFxBuild() As String
        Get
            Return lblNetFxBuild.Text
        End Get
        Set(ByVal Value As String)
            lblNetFxBuild.Text = Value
        End Set
    End Property

    Public Property WfBuild() As String
        Get
            Return lblWfBuild.Text
        End Get
        Set(ByVal Value As String)
            lblWfBuild.Text = Value
        End Set
    End Property
    Public Property OsloBuild() As String
        Get
            Return lblOsloBuild.Text
        End Get
        Set(ByVal Value As String)
            lblOsloBuild.Text = Value
        End Set
    End Property

    Public Property OsVersion() As String
        Get
            Return lblOSVersion.Text
        End Get
        Set(ByVal Value As String)
            lblOSVersion.Text = Value
        End Set
    End Property

    Private Structure runDetails
        Dim RunId As String
        Dim Run As String
        Dim BuildNumber As String
        Dim OsloBuildNumber As String
        Dim NetFxBuildNumber As String
        Dim WfBuildNumber As String
        Dim FrameworkBuildNumber As String
        Dim Os As String
        Dim RunDate As String
        Dim RunType As String
    End Structure

    Public Sub GetRunInfo(ByVal run_id As Integer)
        Dim myRunDetails As runDetails = GetRunDetails(run_id)
        Me.Build = myRunDetails.BuildNumber
        Me.OsloBuild = myRunDetails.OsloBuildNumber
        Me.NetFxBuild = myRunDetails.NetFxBuildNumber
        Me.WfBuild = myRunDetails.WfBuildNumber
        Me.FxBuild = myRunDetails.FrameworkBuildNumber
        Me.Run = String.Format("{0} ({1})", myRunDetails.RunId, myRunDetails.Run)
        Me.RunDate = myRunDetails.RunDate
        Me.RunType = myRunDetails.RunType
        Me.OsVersion = myRunDetails.Os
        Session.Add("runid", myRunDetails.RunId)
    End Sub

    Private Function GetRunDetails(ByVal run_id As Integer) As runDetails

        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String
        Dim myRunDetails As runDetails
        Dim myConnection As SqlConnection

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myCommand = New SqlCommand("w_sp_runinfo", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure
        myCommand.Parameters.Add("@run_id", run_id)
        myCommand.CommandTimeout = 120
        myConnection.Open()
        myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

        If myReader.HasRows Then

            While myReader.Read()
                myRunDetails.RunId = myReader("run_id")
                myRunDetails.BuildNumber = myReader("build")
                If IsDBNull(myReader("netfxbuild")) Then
                    myRunDetails.NetFxBuildNumber = "No Data"
                Else
                    myRunDetails.NetFxBuildNumber = myReader("netfxbuild")
                End If


                If IsDBNull(myReader("oslobuild")) Then
                    myRunDetails.OsloBuildNumber = "No Data"
                Else
                    myRunDetails.OsloBuildNumber = myReader("oslobuild")
                End If

                If IsDBNull(myReader("wfbuild")) Then
                    myRunDetails.WfBuildNumber = "No Data"
                Else
                    myRunDetails.WfBuildNumber = myReader("wfbuild")
                End If

                myRunDetails.FrameworkBuildNumber = myReader("framework")
                myRunDetails.Os = myReader("os")

                Dim osBuildVersion As String = String.Empty

                If Not IsDBNull(myReader.Item("machine_config_id")) Then
                    osBuildVersion = GetOsBuildVersion(Convert.ToString(myReader.Item("machine_config_id")))
                End If

                If Not IsDBNull(osBuildVersion) And osBuildVersion.Length > 0 Then
                    myRunDetails.Os += "(" & osBuildVersion & ")"
                End If
                myRunDetails.RunDate = myReader("date")
                myRunDetails.Run = myReader("run")
                myRunDetails.RunType = myReader("runtype")
                _RunName = myRunDetails.Run
                _RunID = myRunDetails.RunId
            End While
        Else
            myRunDetails.RunId = "No Data"
            myRunDetails.BuildNumber = "No Data"
            myRunDetails.RunDate = "No Data"
            myRunDetails.Run = "No Data"
            myRunDetails.Os = "No Data"
        End If

        myReader.Close()
        myConnection.Close()

        Return myRunDetails

    End Function

    Private Function GetOsBuildVersion(ByVal machine_config_id As Integer) As String

        Dim myConnection As SqlConnection
        Dim sqlCommand As SqlCommand
        Dim dr As SqlDataReader
        Dim dbXml() As Byte
        Dim osBuildVersion As String

        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        sqlCommand = New SqlCommand("P_GetMachineConfig", myConnection)
        sqlCommand.CommandType = CommandType.StoredProcedure
        sqlCommand.Parameters.Add(New SqlParameter("@machine_config_id", machine_config_id))
        myConnection.Open()
        dr = sqlCommand.ExecuteReader()

        While dr.Read()

            dbXml = CType(dr.Item("xml"), Byte())
            Dim s As New System.IO.MemoryStream(dbXml)
            Dim textReader As New XmlTextReader(s)
            Dim rootNode As XmlNode

            Dim buildOs As New String("//machine/os/runtime/buildnumber")

            Dim doc As XmlDocument = New XmlDocument
            doc.Load(textReader)
            rootNode = doc.SelectSingleNode("//machine")

            osBuildVersion = GetNodeInfo(rootNode, buildOs)

        End While

        Return osBuildVersion

    End Function

    Private Function GetNodeInfo(ByRef root As XmlNode, ByVal nodePath As String) As String

        Dim child As XmlNode
        Dim nr As XmlNodeReader
        Dim nodeInfo As String

        child = root.SelectSingleNode(nodePath)
        nr = New XmlNodeReader(child)
        nodeInfo = nr.ReadElementString()

        If IsDBNull(nodeInfo) Then
            nodeInfo = ""
        End If

        Return nodeInfo

    End Function

End Class

