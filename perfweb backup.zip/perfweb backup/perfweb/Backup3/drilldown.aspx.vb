Imports System.Data.SqlClient
Imports System.Collections.Specialized

Partial Class drilldown
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Protected WithEvents grdDrillDown As System.Web.UI.WebControls.DataGrid
    Protected WithEvents LeftNav2 As LeftNav
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '[AML] Hide run navigator on this page
        LeftNav2.ShowRunNavigator = False

        '[AML] Get report card scenario number from either query string or cookie
        Dim scenario_id As Integer = Convert.ToInt32(Request.QueryString("scen"))
        If scenario_id > 0 Then
            Session.Add("scenario_id", scenario_id)
        Else
            scenario_id = Session.Item("scenario_id")
        End If
        Dim reportcard_id As Integer = Convert.ToInt32(Request.QueryString("rc"))
        Session.Add("reportcard_id", reportcard_id)

        '[AML] the "w" query string argument marks whether drilldown comparison is for whidbey (w=true) or everett (w=false)
        Dim IsWhidbey As Boolean = Convert.ToBoolean(Request.QueryString("w"))
        Session.Add("whidbey", IsWhidbey)

        Dim IsTbd As Boolean = Convert.ToBoolean(Request.QueryString("tbd"))

        'Populate this scenario's data
        FillDrillDownTable(reportcard_id, scenario_id)

        If Not IsTbd Then
            '[AML] show drilldown chart
            ShowDrillDown(reportcard_id, scenario_id, IsWhidbey)

        '[AML] show variations chart
        ShowVariationsChart(reportcard_id, scenario_id, IsWhidbey)

        '[AML] Add comments with details links
            ShowComments(reportcard_id, scenario_id, IsWhidbey)
        Else
            ShowTbdChart(reportcard_id, scenario_id, IsWhidbey)
        End If


    End Sub
    Private Sub FillDrillDownTable(ByVal ReportcardId As Integer, ByVal ScenarioId As Integer)
        'Fills the temp table used by the rest of the queries to populate graphs.
        'Fill scenario variations vs. time; stored in tempdb.dbo.w_reportcard_data
        Dim myCommand As SqlCommand '= New SqlCommand("sproc_w_reportcard_data")
        ' RK Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_data")

        'With myCommand
        '    .CommandType = CommandType.StoredProcedure
        '    .CommandTimeout = 120
        '    .Parameters.Add("@reportcard_id", SqlDbType.Int)
        '    .Parameters(0).Value = ReportcardId

        '    .Parameters.Add("@scenario_id", SqlDbType.Int)
        '    .Parameters(1).Value = ScenarioId
        'End With
        'DBUtil.ExecNonQuery(myCommand)

        'Fill scenario variation averages vs. time
        myCommand = New SqlCommand("sproc_w_reportcard_scenario_averages")
        ' RK myCommand = New SqlCommand("sproc_w_reportcard_scenario_averages")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportcardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId
        End With
        DBUtil.ExecNonQuery(myCommand)

    End Sub
    '[AML] Version 2.0: complete rewrite
    Private Sub ShowDrillDown(ByVal ReportCardId As Integer, ByVal ScenarioId As Integer, ByVal IsWhidbey As Boolean)
        'Dataset that contains the tables that will be bound to the chart
        Dim rc As New DataSet
        Dim execString As String

        execString = "SELECT * FROM w_reportcard_select_scenario_averages"
        DBUtil.ExecDataSet(rc, execString, "ScenarioAverages")

        'Get chart limits
        Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenario_chart_limits")
        ' RK Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenario_chart_limits")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId
        End With

        DBUtil.ExecDataSet(rc, myCommand, "ChartLimits")

        Dim ScenarioName As String


        '[AML] Creates a new chart bound to the chart web control on the page
        Dim chart As base.PerfChart
        If (ReportCardId = 10) Then
            chart = New base.PerfChart(ThChart, String.Format("Scenario {0} Latency", ScenarioId), "Ratio to comparative technology", "Run date")
        ElseIf (ReportCardId = 15) Then
            chart = New base.PerfChart(ThChart, String.Format("Scenario {0} Refset", ScenarioId), "Ratio to comparative technology", "Run date")
        Else
            chart = New base.PerfChart(ThChart, String.Format("Scenario {0} Throughput", ScenarioId), "Ratio to comparative technology", "Run date")
        End If

        chart.AxisXMargin = False
        chart.size = "90,100,75,50"

        'Add data series to chart and set chart maximum
        If IsWhidbey Then

            If (ReportCardId = 101 Or ReportCardId = 103 Or ReportCardId = 130 Or ReportCardId = 131 Or ReportCardId = 111) Then
                chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "date", _
    "whidbey_ratio", "Orcas Ratio", Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "column")
                chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "date", _
                    "criteria", "Criteria", Dundas.Charting.WebControl.MarkerStyle.Circle, Color.Red, "Line")
                ThChart.ChartAreas("Default").AxisY.Maximum = CType(rc.Tables("ChartLimits").Rows(0).Item("whidbey_limit"), Double)
            Else
                chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "date", _
                    "whidbey_ratio", "Whidbey Ratio", Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "column")
                chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "date", _
                    "criteria", "Criteria", Dundas.Charting.WebControl.MarkerStyle.Circle, Color.Red, "Line")
                ThChart.ChartAreas("Default").AxisY.Maximum = CType(rc.Tables("ChartLimits").Rows(0).Item("whidbey_limit"), Double)
            End If

        Else
            chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "date", _
               "everett_ratio", "Everett Ratio", Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")
            chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "date", _
                "criteria", "Criteria", Dundas.Charting.WebControl.MarkerStyle.Circle, Color.Red, "Line")
            ThChart.ChartAreas("Default").AxisY.Maximum = CType(rc.Tables("ChartLimits").Rows(0).Item("everett_limit"), Double)
        End If

        '[AML] Set ThChart with all perf specific settings.
        chart.ShowChart()

        '[AML] Tune the chart a bit more
        With ThChart.ChartAreas("Default")
            .AxisY.MajorGrid.Interval = 10.0
            .AxisX.Crossing = Double.MinValue
            .AxisY.Crossing = Double.MinValue
            .InnerPlotPosition.Height = .Position.Height - 30
            .InnerPlotPosition.Y = .Position.Y + 5
            .InnerPlotPosition.X = .Position.X + 5
        End With
        chart.AxisXMargin = True
        ThChart.BorderSkin.SkinStyle = Dundas.Charting.WebControl.BorderSkinStyle.None

    End Sub

    '[AML] Version 2.0: complete rewrite
    Private Sub ShowTbdChart(ByVal ReportCardId As Integer, ByVal ScenarioId As Integer, ByVal IsWhidbey As Boolean)
        'Dataset that contains the tables that will be bound to the chart
        Dim rc As New DataSet
        Dim execString As String

        Dim myCommand As SqlCommand = New SqlCommand("P_GetDataForCharts")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId
        End With

        DBUtil.ExecDataSet(rc, myCommand, "ScenarioAverages")

        '[AML] Creates a new chart bound to the chart web control on the page
        Dim chart As base.PerfChart

        chart = New base.PerfChart(ThChart, String.Format("Scenario {0} Throughput", ScenarioId), "Throughput", rc.Tables("ScenarioAverages").Rows(0).Item("variation"))

        chart.AxisXMargin = False
        chart.size = "90,100,75,50"

        'Add data series to chart and set chart maximum
        If IsWhidbey Then

            If (ReportCardId = 101 Or ReportCardId = 103 Or ReportCardId = 130 Or ReportCardId = 131 Or ReportCardId = 111) Then
                chart.AddSeries(rc.Tables("ScenarioAverages").Rows, "run", _
    "measured_value", "Throughput", Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "column")
                'ThChart.ChartAreas("Default").AxisY.Maximum = CType(rc.Tables("ChartLimits").Rows(0).Item("whidbey_limit"), Double)
            End If


        End If

        '[AML] Set ThChart with all perf specific settings.
        chart.ShowChart()

        VariationsChart.Enabled = False
        VariationsChart.Visible = False
        VariationsTable.Enabled = False
        VariationsTable.Visible = False
        grdComments.Visible = False
        grdComments.Enabled = False

        '[AML] Tune the chart a bit more
        'With ThChart.ChartAreas("Default")
        '    .AxisY.MajorGrid.Interval = 10.0
        '    .AxisX.Crossing = Double.MinValue
        '    .AxisY.Crossing = Double.MinValue
        '    .InnerPlotPosition.Height = .Position.Height - 30
        '    .InnerPlotPosition.Y = .Position.Y + 5
        '    .InnerPlotPosition.X = .Position.X + 5
        'End With
        chart.AxisXMargin = True
        ThChart.BorderSkin.SkinStyle = Dundas.Charting.WebControl.BorderSkinStyle.None

    End Sub

    '[AML] Replaces CompChart.aspx 
    Private Sub ShowVariationsChart(ByVal ReportCardId As Integer, ByVal ScenarioId As Integer, ByVal Whidbey As Boolean)

        'Get tables that will be bound to the chart
        Dim rc As New DataSet

        'Get Indigo data
        Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenario_latest")
        ' RK Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenario_latest")

        Dim indigoRuntypeId As Integer
        Dim whidbeyRuntypeId As Integer

        Select Case ReportCardId
            Case 1 ' ReportCard
                indigoRuntypeId = 6
                whidbeyRuntypeId = 26
            Case 10 ' Latency
                indigoRuntypeId = 6
                whidbeyRuntypeId = 26
            Case 15 ' Refset
                indigoRuntypeId = 6
                whidbeyRuntypeId = 26
            Case 20 ' ReportCard SMP
                indigoRuntypeId = 28
                whidbeyRuntypeId = 31
            Case 101 ' Orcas ReportCard
                indigoRuntypeId = 80
                whidbeyRuntypeId = 84
            Case 111 ' Oslo ReportCard
                indigoRuntypeId = 137
                whidbeyRuntypeId = 140
            Case 103 ' Orcas ReportCard ASR
                indigoRuntypeId = 104
                whidbeyRuntypeId = 82
            Case 130 ' Orcas SP1 ReportCard
                indigoRuntypeId = 145
                whidbeyRuntypeId = 149
            Case 131 ' Orcas SP1 ARS
                indigoRuntypeId = 150
                whidbeyRuntypeId = 153
        End Select

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId

            'Indigo is type 6
            .Parameters.Add("@runtype_id", SqlDbType.Int)
            .Parameters(2).Value = indigoRuntypeId
        End With
        DBUtil.ExecDataSet(rc, myCommand, "IndigoData")

        'Get comparative data
        myCommand = New SqlCommand("sproc_w_reportcard_scenario_latest")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId

            'Everett is type 16, Whidbey is 31
            .Parameters.Add("@runtype_id", SqlDbType.Int)
            If Whidbey Then
                .Parameters(2).Value = whidbeyRuntypeId
            Else
                .Parameters(2).Value = 16
            End If
        End With
        DBUtil.ExecDataSet(rc, myCommand, "ComparativeData")
        'End If

        Dim varChart As base.PerfChart
        If (ReportCardId = 10) Then
            varChart = New base.PerfChart(VariationsChart, "Latency Comparison", "Sec", "Test Variation")
        ElseIf (ReportCardId = 15) Then
            varChart = New base.PerfChart(VariationsChart, "Refset Comparison", "MB", "Test Variation")
        ElseIf (ReportCardId = 103 Or ReportCardId = 131) Then
            varChart = New base.PerfChart(VariationsChart, "Throughput Comparison", "Operations/Sec", "Test Name and Variation")
        Else
            varChart = New base.PerfChart(VariationsChart, "Throughput Comparison", "Operations/Sec", "Test Variation")
        End If
        'Populate chart and format

        Dim seriesName As String = rc.Tables("IndigoData").Rows(0).Item("test") & " " & rc.Tables("IndigoData").Rows(0).Item("variation")
        Dim compSeriesName As String = rc.Tables("ComparativeData").Rows(0).Item("test") & " " & rc.Tables("ComparativeData").Rows(0).Item("variation") & " (comp)"

        Dim criteriaName As String

        If (ReportCardId = 101 Or ReportCardId = 103) Then
            criteriaName = "Net 3.0 Criteria"
        ElseIf (ReportCardId = 130 Or ReportCardId = 131 Or ReportCardId = 111) Then
            criteriaName = "Orcas RTM Criteria"
        ElseIf (ReportCardId = 15) Then
            criteriaName = "Whidbey Criteria"
        Else
            criteriaName = "Unknown Criteria"
        End If

        If (ReportCardId = 15) Then
            varChart.AddSeries(rc.Tables("IndigoData").Rows, "metric", _
               "value", rc.Tables("IndigoData").Rows(0).Item("test") & " " & rc.Tables("IndigoData").Rows(0).Item("variation"), _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")

            varChart.AddSeries(rc.Tables("ComparativeData").Rows, "metric", _
                "value", rc.Tables("ComparativeData").Rows(0).Item("test") & " " & rc.Tables("ComparativeData").Rows(0).Item("variation"), _
                Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "Column")

            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
        "whidbey_criteria", criteriaName, Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")

        ElseIf (ReportCardId = 101 Or ReportCardId = 130 Or ReportCardId = 111) Then

            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
               "value", seriesName, _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")
            varChart.AddSeries(rc.Tables("ComparativeData").Rows, "variation", _
                "value", compSeriesName, _
                Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "Column")

            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
"whidbey_criteria", criteriaName, Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
        ElseIf (ReportCardId = 103 Or ReportCardId = 131) Then
            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
               "value", "Current", _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")
            varChart.AddSeries(rc.Tables("ComparativeData").Rows, "variation", _
                "value", "Competitive", _
                Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "Column")

            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
"whidbey_criteria", criteriaName, Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
        Else
            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
               "value", rc.Tables("IndigoData").Rows(0).Item("test"), _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")

            If (ScenarioId = 10 And ReportCardId = 1) Then
                varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
            "whidbey_criteria", "Criteria", Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
            Else
                varChart.AddSeries(rc.Tables("ComparativeData").Rows, "variation", _
                    "value", rc.Tables("ComparativeData").Rows(0).Item("test"), _
                    Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "Column")

                varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
            "whidbey_criteria", "Whidbey Criteria", Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
            End If
        End If


        varChart.ShowChart()
        VariationsChart.Legends("Default").LegendStyle = Dundas.Charting.WebControl.LegendStyle.Table
        VariationsChart.Legends("Default").Docking = Dundas.Charting.WebControl.LegendDocking.Bottom

        'Show table of variations too
        ShowVariationsTable(ReportCardId, rc, ScenarioId)

    End Sub
    Private Sub ShowVariationsTable(ByVal ReportCardId As Integer, ByVal rc As DataSet, ByVal scenarioId As Integer)

        'Fill Table: Columns are variation number, variation, test name, value
        Dim rhead As New TableRow

        Dim c As New TableCell
        c.Text = "Variation"
        rhead.Cells.Add(c)

        c = New TableCell
        c.Text = "Test Variation Type"
        rhead.Cells.Add(c)
        c = New TableCell
        c.Text = "Operations/Sec"
        rhead.Cells.Add(c)

        rhead.Font.Bold = True
        rhead.ForeColor = Color.FromArgb(Val("&HCC6600"))
        rhead.BackColor = Color.Beige

        VariationsTable.Rows.Add(rhead)

        'row pointer for comparative data
        Dim i As Integer = 0

        For Each myRow As DataRow In rc.Tables("IndigoData").Rows

            Dim trcomp As System.Data.DataRow

            'If scenarioId <> 10 Then
            'Comparison data for this sql row
            trcomp = rc.Tables("ComparativeData").Rows(i)
            'End If


            'Used to fill table rows
            Dim rindi = New TableRow
            Dim rcomp = New TableRow
            Dim rcrit = New TableRow

            Dim variationOrdinalIndigo As String
            Dim variationOrdinalComp As String

            If (ReportCardId = 15) Then
                variationOrdinalIndigo = myRow.Item("metric").ToString
                variationOrdinalComp = trcomp.Item("metric").ToString
            Else
                variationOrdinalIndigo = myRow.Item("variation_ordinal").ToString
                variationOrdinalComp = trcomp.Item("variation_ordinal").ToString
            End If

            c = New TableCell
            c.Text = variationOrdinalIndigo
            rindi.Cells.Add(c)

            'If scenarioId <> 10 Then
            c = New TableCell
            c.Text = variationOrdinalComp
            rcomp.Cells.Add(c)
            'End If

            c = New TableCell
            c.Text = variationOrdinalIndigo
            rcrit.Cells.Add(c)

            c = New TableCell
            If (ReportCardId = 15) Then
                c.Text = myRow.Item("test").ToString + ", " + myRow.Item("variation").ToString
            Else
                c.Text = myRow.Item("test").ToString + ", " + myRow.Item("variation").ToString
            End If

            rindi.Cells.Add(c)

            'If scenarioId <> 10 Then
            c = New TableCell
            c.Text = trcomp.Item("test").ToString + ", " + trcomp.Item("variation").ToString + " (Comp)"
            rcomp.Cells.Add(c)
            'End If

            c = New TableCell

            'Change to using whidbey criteria
            If (scenarioId = 10 And ReportCardId = 1) Then
                c.Text = "Criteria"
            Else
                If (ReportCardId = 101) Then
                    c.Text = "Criteria (Orcas)"
                ElseIf (ReportCardId = 130 Or ReportCardId = 131 Or ReportCardId = 111) Then
                    c.Text = "Criteria (Orcas RTM)"
                Else
                    c.Text = "Criteria (Whidbey)"
                End If
            End If

            rcrit.Cells.Add(c)

            c = New TableCell
            c.Text = myRow.Item("value").ToString
            rindi.Cells.Add(c)

            'If scenarioId <> 10 Then
            c = New TableCell
            c.Text = trcomp.Item("value").ToString
            rcomp.Cells.Add(c)
            'End If

            'Change to using whidbey criteria
            c = New TableCell
            c.Text = myRow.Item("whidbey_criteria").ToString
            rcrit.Cells.Add(c)

            'Fill row and increment row pointer for comp data.
            VariationsTable.Rows.Add(rindi)

            If (scenarioId = 10 And ReportCardId = 1) Then
            Else
                VariationsTable.Rows.Add(rcomp)
            End If

            VariationsTable.Rows.Add(rcrit)
            i = i + 1
        Next
    End Sub
    '[AML] version 2.0: Puts comments with details links on the drilldown report card page.
    Private Sub ShowComments(ByVal ReportCardId As Integer, ByVal ScenarioId As Integer, ByVal Whidbey As Boolean)
        'Dataset that contains the tables that will be bound to the comment table
        Dim ds As New DataSet

        Dim whidbeyRuntypeId As Integer

        Select Case ReportCardId
            Case 1 ' ReportCard
                whidbeyRuntypeId = 26
            Case 10 ' Latency
                whidbeyRuntypeId = 26
            Case 15 ' Refset
                whidbeyRuntypeId = 26
            Case 20 ' Reporcard SMP
                whidbeyRuntypeId = 31
            Case 101 ' Orcas Reporcard Tier1
                whidbeyRuntypeId = 84
            Case 111 ' Orcas Reporcard Tier1
                whidbeyRuntypeId = 140
            Case 103 ' Orcas Reporcard ASR
                whidbeyRuntypeId = 82
            Case 130 ' Orcas SP1 Reporcard Tier1
                whidbeyRuntypeId = 145
            Case 131 ' Orcas SP1 ARS
                whidbeyRuntypeId = 153
        End Select

        'Get comments and bind to table
        Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenario_drilldown_comments")
        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId

            'Everett is type 16, Whidbey is 26
            .Parameters.Add("@runtype_id", SqlDbType.Int)
            If Whidbey Then
                .Parameters(2).Value = whidbeyRuntypeId
            Else
                .Parameters(2).Value = 16
            End If
        End With
        DBUtil.ExecDataSet(ds, myCommand, "comments")
        grdComments.DataSource = ds.Tables("comments")
        grdComments.DataBind()

    End Sub
End Class
