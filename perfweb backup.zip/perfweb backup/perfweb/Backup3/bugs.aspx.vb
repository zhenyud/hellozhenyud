Imports System.Data.SqlClient

Partial Class Bugs
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Delegate Sub BindDG(ByVal SortExp As String)
    Dim dv1, dv2, dv3, dv4, dv5, dv6 As New DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            BindPerformanceBugs(Nothing)    'Indigo Active Performance Issues
            BindResolvedPerfBugs(Nothing)    'Indigo Resolved Performance Issues
        End If
    End Sub

    
    Private Sub BindPerformanceBugs(ByVal SortExp As String)

        Dim con As String = ConfigurationSettings.AppSettings("MessageBusConnect")
        Dim sql As String = ConfigurationSettings.AppSettings("PerformanceQuery")
        Try
            dv1 = GetDataView(con, sql)
        Catch ex As SqlException
            Error1.Text = ex.ToString()
        End Try
        If Not SortExp Is Nothing Then dv1.Sort = SortExp
        PerformanceGrid.DataSource = dv1
        PerformanceGrid.DataBind()

    End Sub
    Private Sub BindResolvedPerfBugs(ByVal SortExp As String)

        Dim con As String = ConfigurationSettings.AppSettings("MessageBusConnect")
        Dim sql As String = ConfigurationSettings.AppSettings("ResolvedPerfQuery")
        Try
            dv1 = GetDataView(con, sql)
        Catch ex As SqlException
            Error1.Text = ex.ToString()
        End Try
        If Not SortExp Is Nothing Then dv1.Sort = SortExp
        ResolvedPerfGrid.DataSource = dv1
        ResolvedPerfGrid.DataBind()

    End Sub

    Private Function GetDataView(ByVal ConnectionString As String, ByVal SQLQuery As String) As DataView
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet
        Dim dr As DataRow
        Dim dv As DataView

        myConnection = New SqlConnection(ConnectionString)
        myDA = New SqlDataAdapter(SQLQuery, myConnection)

        myConnection.Open()
        myDA.Fill(ds)
        dv = New DataView(ds.Tables(0))

        myConnection.Close()
        Return dv

    End Function

    Private Function GetDataView(ByVal scenario_number As Integer) As DataView
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet
        Dim dr As DataRow
        Dim dv As DataView
        Dim sql As String

        If scenario_number = 0 Then
            sql = String.Format("SELECT BugID, Area, CONVERT(CHAR(10),OpenedDate,110) as OpenedDate, Environment, Priority, AssignedTo, Title, Custom, Issuetype, TestCase FROM Bugs WHERE (Status = 'Active') AND (TestCase IS NOT NULL) AND (Issuetype = N'Performance')")
        Else
            sql = String.Format("SELECT BugID, Area, CONVERT(CHAR(10),OpenedDate,110) as OpenedDate, Environment, Priority, AssignedTo, Title, Custom, Issuetype, TestCase FROM Bugs WHERE (Status = 'Active') AND (TestCase IS NOT NULL) AND (Issuetype = N'Performance') AND (PATINDEX('%[T,L]{0}[^0-9]%', RTRIM(TestCase) + ',') > 0)", scenario_number)
        End If


        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("conPS"))
        myDA = New SqlDataAdapter(sql, myConnection)
        myConnection.Open()
        myDA.Fill(ds)
        dv = New DataView(ds.Tables(0))
        myConnection.Close()
        Return dv

    End Function


    Private Sub PerformanceGrid_SortCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles PerformanceGrid.SortCommand

        SortDG(PerformanceGrid, AddressOf BindPerformanceBugs, e)

    End Sub
    Private Sub ResolvedPerfGrid_SortCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles ResolvedPerfGrid.SortCommand

        SortDG(ResolvedPerfGrid, AddressOf BindResolvedPerfBugs, e)

    End Sub

    Private Sub SortDG(ByVal DG As DataGrid, ByVal GridBinder As BindDG, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs)

        Dim arrSortExpr() As String
        Dim i As Integer

        If e.SortExpression = "" Then Return

        GridBinder.Invoke(e.SortExpression)

        arrSortExpr = Split(e.SortExpression, " ")
        For i = 0 To DG.Columns().Count - 1
            If (DG.Columns(i).SortExpression = e.SortExpression) Then
                If UCase(arrSortExpr(1)) = "ASC" Then
                    arrSortExpr(1) = "DESC"
                ElseIf UCase(arrSortExpr(1)) = "DESC" Then
                    arrSortExpr(1) = "ASC"
                End If
                DG.Columns(i).SortExpression = arrSortExpr(0) & " " & arrSortExpr(1)
                Exit For
            End If
        Next

    End Sub


    Private Sub ResolvedPerfGrid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResolvedPerfGrid.SelectedIndexChanged

    End Sub

    Private Sub PerformanceGrid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PerformanceGrid.SelectedIndexChanged

    End Sub
End Class
