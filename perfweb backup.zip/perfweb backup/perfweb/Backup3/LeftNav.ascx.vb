Imports System.Data.SqlClient
Imports System.Configuration

Partial Class LeftNav
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=BRADF;packet size=4096;user id=sa;data source=""indigo-sd"";persist " & _
        "security info=True;initial catalog=Perf;password=""abc!123"""

    End Sub
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents days10 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents days30 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents daysFull As System.Web.UI.WebControls.RadioButton

    Protected newRun As String
    Protected oldRun As String
    Protected WithEvents Linkbutton3 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents Textbox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Textbox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

    End Sub

#End Region

    Dim dv1 As New DataView
    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Private _linkPage As String = "reportcard.aspx"
    Private _reportcard_id As Integer = 1
    Private _ShowRunNavigator As Boolean = True
    Private _ShowNonRCLinks As Boolean = False
    Dim s As New Stopwatch

    Private Delegate Sub BindDG(ByVal SortExp As String)

    Public Property ShowRunNavigator() As Boolean
        Get
            Return _ShowRunNavigator
        End Get
        Set(ByVal Value As Boolean)
            _ShowRunNavigator = Value
        End Set
    End Property

    Public Property ShowNonRCLinks() As Boolean
        Get
            Return _ShowNonRCLinks
        End Get
        Set(ByVal Value As Boolean)
            _ShowNonRCLinks = Value
        End Set
    End Property

    Public Property LinkPage() As String
        Get
            Return _linkPage
        End Get
        Set(ByVal Value As String)
            _linkPage = Value
        End Set
    End Property

    Public Property ReportCardID() As Integer
        Get
            Return _reportcard_id
        End Get
        Set(ByVal Value As Integer)
            _reportcard_id = Value
        End Set
    End Property

    Private LinkRCRunsOnly As Boolean

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Me.ShowRunNavigator Then
            pnlRunNav.Visible = True

            If Not IsPostBack Then
                If pnlRunNav.Visible Then

                    BindDropDowns()
                    ShowRunList()
                    ' ReloadSettings()
                    ' BindBugs(Nothing)
                End If
            Else
                If pnlRunNav.Visible Then
                    'BindDropDowns()
                    ShowRunList()
                    ' ReloadSettings()
                    '                   BindBugs(Nothing)
                End If
            End If
        Else
            pnlRunNav.Visible = False

        End If

    End Sub
    Private Sub BindDropDowns()

        BindDateRangeDropDown()
        BindRuntypeDropDown()

    End Sub

    Private Sub BindDateRangeDropDown()

        If Session("SelectedDateRangeIndex") Is Nothing Then
            ddDateRange.SelectedIndex = 0
        Else
            ddDateRange.SelectedIndex = Session("SelectedDateRangeIndex")
        End If
    End Sub

    Private Sub BindRuntypeDropDown()
        Dim dsRunTypes As DataSet

        Dim sql As String
        Dim today As DateTime = DateTime.Now
        Dim selectedTimeSpan As Integer

        sql = "select distinct r.runtype_id,rt.runtype from runtypes rt inner join runs r on rt.runtype_id=r.runtype_id "

        If Session("runtypesDateRange") Is Nothing Then
            selectedTimeSpan = 10
            lastTenRuntypes.Checked = True
        Else
            selectedTimeSpan = Session("runtypesDateRange")
            If selectedTimeSpan = 0 Then
                allRuntypes.Checked = True
            ElseIf selectedTimeSpan = 30 Then
                last30Runtypes.Checked = True
            ElseIf selectedTimeSpan = 10 Then
                lastTenRuntypes.Checked = True
            End If
        End If

        If selectedTimeSpan <> 0 Then

            Dim diff1 As System.TimeSpan = New System.TimeSpan(selectedTimeSpan, 0, 0, 0)

            Dim selectedRunsDate As System.DateTime

            selectedRunsDate = today.Subtract(diff1)

            sql += " where r.start_date >= Cast('" + selectedRunsDate.ToShortDateString + "' As DateTime)"
        End If

        sql += " order by rt.runtype"

        dsRunTypes = GetDataSet(sql)
        ddRunType.DataSource = dsRunTypes.Tables(0)
        ddRunType.DataTextField = "runtype"
        ddRunType.DataValueField = "runtype_id"
        ddRunType.DataBind()

        Dim zeroItemDescription As String = String.Empty
        If selectedTimeSpan <> 0 Then
            zeroItemDescription = "Run types from " & selectedTimeSpan.ToString() & " days ago"
        Else
            zeroItemDescription = "All run types"
        End If

        ddRunType.Items.Insert(0, New WebControls.ListItem(zeroItemDescription, "0"))

        If Session("SelectedRunTypeValue") Is Nothing Then
            ddRunType.SelectedValue = 0
        Else
            Dim value As WebControls.ListItem = ddRunType.Items.FindByValue(Session("SelectedRunTypeValue"))

            If value Is Nothing Then
                ddRunType.SelectedValue = 0
                Session("SelectedRunTypeValue") = 0
            Else
                ddRunType.SelectedValue = Session("SelectedRunTypeValue")
            End If
        End If

    End Sub
    Private Sub ReloadSettings()

        Dim i As Integer = Convert.ToInt32(Session("chk"))


        If i = 0 Then Exit Sub
        If (i And 4) = 4 Then
            chkValid.Checked = True
        Else
            chkValid.Checked = False
        End If
        If (i And 8) = 8 Then
            chkNoLook.Checked = True
        Else
            chkNoLook.Checked = False
        End If
        If (i And 16) = 16 Then
            chkReportCard.Checked = True
        Else
            chkReportCard.Checked = False
        End If
        If (i And 32) = 32 Then
            chkInvalid.Checked = True
        Else
            chkInvalid.Checked = False
        End If

        If (i And 64) = 64 Then
            Me.ddDateRange.SelectedIndex = 0
        End If
        If (i And 128) = 128 Then
            Me.ddDateRange.SelectedIndex = 1
        End If
        If (i And 256) = 256 Then
            Me.ddDateRange.SelectedIndex = 2
        End If
        If (i And 512) = 512 Then
            Me.ddDateRange.SelectedIndex = 3
        End If

    End Sub

    Public Event ReportcardRunsSelected(ByVal run_id As Integer, ByVal regression_run_id As Integer)

    Private Function GetRCRuns(ByVal DaysBack As Integer, Optional ByVal IgnoreCache As Boolean = False) As DataRow()

        Dim rcRuns As DataSet
        Dim dr() As DataRow

        If IgnoreCache OrElse Cache.Item("rcruns") Is Nothing Then
            rcRuns = GetDataSet("w_sp_rc_runs2 " & Me.ReportCardID.ToString)
            Cache.Add("rcruns", rcRuns, Nothing, Date.MaxValue, New TimeSpan(0, 5, 0), Caching.CacheItemPriority.Normal, Nothing)
        Else
            rcRuns = Cache.Item("rcruns")
        End If

        If rcRuns.Tables.Count > 0 Then
            Return rcRuns.Tables(0).Select("run_date > #" & Date.Now.AddDays(-DaysBack).ToString & "#")
        Else
            Return dr
        End If

    End Function

    Private Function GetRCRunsHt(ByVal DaysBack As Integer, Optional ByVal IgnoreCache As Boolean = False) As Hashtable

        Dim rcRuns As DataSet
        Dim dr As DataRow
        Dim ht As New Hashtable

        If IgnoreCache OrElse Cache.Item("rcruns") Is Nothing Then
            rcRuns = GetDataSet("w_sp_rc_runs2 " & Me.ReportCardID.ToString)
            Cache.Add("rcruns", rcRuns, Nothing, Date.MaxValue, New TimeSpan(0, 5, 0), Caching.CacheItemPriority.Normal, Nothing)
        Else
            rcRuns = Cache.Item("rcruns")
        End If

        If rcRuns.Tables.Count > 0 Then
            For Each dr In rcRuns.Tables(0).Select("run_date > #" & Date.Now.AddDays(-DaysBack).ToString & "#")
                ht.Add(dr("run_id"), dr("run_id"))
            Next
            'dumpHt(ht)
            Return ht
        Else
            Return ht
        End If

    End Function

    Private Sub ShowRunList()
        Dim DaysBack As Integer
        Dim dsRuns As DataSet
        DaysBack = ddDateRange.SelectedValue()
        Dim sql As SqlCommand

        Dim runtypeId As Integer

        sql = New SqlCommand("sproc_w_reportcard_GetRunsInfo_070807")

        If (ddRunType.SelectedValue = 0) Then
            'All run types
            runtypeId = -1
        Else
            'only selected one
            runtypeId = ddRunType.SelectedValue
        End If

        With sql
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@num_days", SqlDbType.Int)
            .Parameters(0).Value = DaysBack

            .Parameters.Add("@runtype_id", SqlDbType.Int)
            .Parameters(1).Value = runtypeId
        End With

        dsRuns = GetDataSet(sql)
        If dsRuns.Tables.Count > 0 Then
            DataGrid1.DataSource = dsRuns.Tables(0)
            DataGrid1.DataBind()
        Else
            DataGrid1.DataSource = Nothing
            DataGrid1.DataBind()
        End If

        Dim osLegend As String = "OS: Operating System (W=Win2k3, X=WinXP, V=Vista/Longhorn)" & vbNewLine
        Dim typeLegend As String = "TP: Run Type (L=Latency,R=Refset,M=Memory,T=Throughput)" & vbNewLine
        Dim summaryLegend As String = "S: Was the run summarized?"
        Dim testsCountLegend As String = "T: Total number of Tests in this run" & vbNewLine
        Dim variationsCountLegend As String = "V: Total number of Variations in this run" & vbNewLine
        Dim failedVariationsCountLegend As String = "FV: number of Variations that failed in this run" & vbNewLine

        DataGrid1.ToolTip = testsCountLegend & variationsCountLegend & failedVariationsCountLegend & osLegend & typeLegend & summaryLegend

    End Sub
    Private Function GetAllRuns(ByVal DaysBack As Integer, Optional ByVal IgnoreCache As Boolean = False) As DataSet

        Dim AllRuns As DataSet
        Dim dr() As DataRow

        'If IgnoreCache OrElse Cache.Item("allruns") Is Nothing Then
        AllRuns = GetDataSet(String.Format("SELECT validity, run_id, run, CONVERT(CHAR(10),start_date,102) as run_date FROM runs WHERE (DATEDIFF(dd, start_date, GETDATE()) < {0})", DaysBack))
        'Cache.Add("allruns", AllRuns, Nothing, Date.MaxValue, New TimeSpan(0, 5, 0), Caching.CacheItemPriority.Normal, Nothing)
        'Else
        '    AllRuns = Cache.Item("allruns")
        'End If
        'dumpDS(AllRuns)
        Return AllRuns

    End Function

    Private Sub BindBugs(ByVal SortExp As String)

        Dim scenario As String = Request("scen")
        Dim DaysBack As Integer
        Dim sb As New System.Text.StringBuilder
        Dim dv As DataView
        Dim AllRuns As DataSet
        Dim dsOut As New DataSet

        s.Start()
        DaysBack = ddDateRange.SelectedValue()

        Dim RCRuns() As DataRow

        AllRuns = GetAllRuns(DaysBack)

        If Not AllRuns Is Nothing Then

            If chkReportCard.Checked Then
                Dim ht As Hashtable = GetRCRunsHt(DaysBack)
                Dim de As DictionaryEntry

                For Each de In ht
                    Dim dr() As DataRow = AllRuns.Tables(0).Select("run_id=" & de.Value)
                    If dr.Length > 0 Then
                        dr(0).Item("validity") = 3
                    End If
                Next
                sb.Append(" validity=3 OR")
            End If

            If chkValid.Checked Then
                sb.Append(" validity=2 OR")
            End If

            If chkNoLook.Checked Then
                sb.Append(" validity=1 OR")
            End If

            If chkInvalid.Checked Then
                sb.Append(" validity=0 OR")
            End If

            If AllRuns.Tables.Count > 0 Then

                Dim junk() As Char = "OR"
                Dim SelectedRuns() As DataRow

                If sb.Length > 0 Then
                    dv = New DataView(AllRuns.Tables(0))
                    dv.RowFilter = sb.ToString.TrimEnd(junk)
                End If

            Else
                'No runs found in one of the datasets
            End If
        Else
            'AllRuns Dataset is empty - no dataview created
        End If

        If Not dv Is Nothing Then
            dv.Sort = "run_date DESC"
            DataGrid1.DataSource = dv
            DataGrid1.DataBind()
        Else
            DataGrid1.DataSource = Nothing
            DataGrid1.DataBind()
        End If

        System.Diagnostics.Debug.WriteLine(s.ElapsedTime)


    End Sub

    Private Sub dumpDS(ByVal ds As DataSet)

        Dim dr As DataRow
        'Dim sb As DataColumn
        Dim sb As New System.Text.StringBuilder
        Dim db As System.Diagnostics.Debug
        Dim s As String

        For Each dr In ds.Tables(0).Rows
            Dim v() As Object = dr.ItemArray
            Dim t As Object
            For Each t In v
                s += t & ", "
            Next
            db.WriteLine(s)
            s = ""
        Next


    End Sub

    Private Sub dumpHt(ByVal ht As Hashtable)

        Dim de As DictionaryEntry
        Dim db As System.Diagnostics.Debug

        For Each de In ht
            db.WriteLine(de.Value)
        Next

    End Sub

    Private Function GetDataSet(ByVal sql As String) As DataSet
        Dim myConnection As SqlConnection
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet

        myConnection = New SqlConnection(perfConnection)
        myDA = New SqlDataAdapter(sql, myConnection)

        myConnection.Open()
        myDA.Fill(ds)

        myConnection.Close()
        Return ds

    End Function

    Private Function GetDataSet(ByVal sql As SqlCommand) As DataSet
        Dim myConnection As SqlConnection
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet

        myConnection = New SqlConnection(perfConnection)
        sql.Connection = myConnection
        myConnection.Open()

        myDA = New SqlDataAdapter(sql)

        myDA.Fill(ds)

        myConnection.Close()
        Return ds

    End Function

    Private Sub Datagrid1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DataGrid1.SortCommand

        SortDG(DataGrid1, AddressOf BindBugs, e)

    End Sub

    Private Sub SortDG(ByVal DG As DataGrid, ByVal GridBinder As BindDG, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs)

        Dim arrSortExpr() As String
        Dim i As Integer

        If e.SortExpression = "" Then Return

        GridBinder.Invoke(e.SortExpression)

        arrSortExpr = Split(e.SortExpression, " ")
        For i = 0 To DG.Columns().Count - 1
            If (DG.Columns(i).SortExpression = e.SortExpression) Then
                If UCase(arrSortExpr(1)) = "ASC" Then
                    arrSortExpr(1) = "DESC"
                ElseIf UCase(arrSortExpr(1)) = "DESC" Then
                    arrSortExpr(1) = "ASC"
                End If
                DG.Columns(i).SortExpression = arrSortExpr(0) & " " & arrSortExpr(1)
                Exit For
            End If
        Next

    End Sub


    Private Sub DataGrid1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then

            'DataGrid1.
            Dim run_id As Integer = CType(DataBinder.Eval(e.Item.DataItem, "run_id"), Integer)
            Dim osBuild As String = CType(DataBinder.Eval(e.Item.DataItem, "os"), String)
            Dim osName As String = osBuild.Substring(0, osBuild.IndexOf(".", 2))

            Dim testsCount As Integer = CType(DataBinder.Eval(e.Item.DataItem, "tests"), Integer)
            Dim variationsCount As Integer = CType(DataBinder.Eval(e.Item.DataItem, "variations"), Integer)
            Dim failedVariationsCount As Integer = CType(DataBinder.Eval(e.Item.DataItem, "failed_variations"), Integer)

            e.Item.Cells(3).Text = "<font color='blue'>" & testsCount.ToString() & "</font>"
            e.Item.Cells(3).ToolTip = testsCount & " Test(s)"

            e.Item.Cells(4).Text = "<font color='green'>" & variationsCount.ToString() & "</font>"
            e.Item.Cells(4).ToolTip = variationsCount & " Variation(s)"

            e.Item.Cells(5).Text = "<font color='red'>" & failedVariationsCount.ToString() & "</font>"
            e.Item.Cells(5).ToolTip = failedVariationsCount & " Failed Variation(s)"

            e.Item.Cells(6).ToolTip = CType(DataBinder.Eval(e.Item.DataItem, "os"), String)

            If osName = "5.1" Then
                osName = "X"
            ElseIf osName = "5.2" Then
                osName = "W"
            ElseIf osName = "6.0" Then
                osName = "V"
            Else
                osName = "U"
                e.Item.Cells(6).ToolTip = "Could not determine"
            End If

            e.Item.Cells(6).Text = osName

            Dim typeOfRun As String = CType(DataBinder.Eval(e.Item.DataItem, "runtype"), String)

            If typeOfRun.ToLower().IndexOf("other") >= 0 Then
                e.Item.Cells(7).Text = "O"
            ElseIf typeOfRun.ToLower().IndexOf("memory") >= 0 Then
                e.Item.Cells(7).Text = "M"
            ElseIf typeOfRun.ToLower().IndexOf("latency") >= 0 Then
                e.Item.Cells(7).Text = "L"
            ElseIf typeOfRun.ToLower().IndexOf("refset") >= 0 Then
                e.Item.Cells(7).Text = "R"
            ElseIf typeOfRun.ToLower().IndexOf("startup") >= 0 Then
                e.Item.Cells(7).Text = "S"
            Else
                e.Item.Cells(7).Text = "T"
            End If

            e.Item.Cells(7).ToolTip = typeOfRun

            e.Item.Cells(2).ToolTip = CType(DataBinder.Eval(e.Item.DataItem, "run_date"), DateTime).ToShortDateString

            If e.Item.Cells(2).Text.Length > 15 Then
                e.Item.Cells(2).Text = e.Item.Cells(2).Text.Substring(0, 14) & "..."
            End If

            e.Item.Cells(1).Text = String.Format("<a href={1}?rc={2}&rid1={0}>{0}</a>", run_id.ToString, Me.LinkPage, Me.ReportCardID.ToString)
            Dim runtype As String = "Type:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "runtype"), String) + vbNewLine
            Dim labconfig As String = "Cell:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "labconfig"), String) + vbNewLine
            Dim framework As String = "CLR:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "framework"), String) + vbNewLine
            Dim os As String = "OS:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "os"), String) + vbNewLine
            Dim wcfBuild As String = "WCF:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "build"), String) + vbNewLine
            Dim netfxBuild As String = "Netfx:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "netfxbuild"), String) + vbNewLine
            Dim wfBuild As String = "WF:" + vbTab + CType(DataBinder.Eval(e.Item.DataItem, "wfbuild"), String)
            e.Item.Cells(1).ToolTip = runtype + labconfig + os + framework + wcfBuild + netfxBuild + wfBuild
        End If
    End Sub

    Private Sub setSessionValues()
        Session.Add("SelectedDateRangeIndex", ddDateRange.SelectedIndex)
        Session.Add("SelectedRunTypeValue", ddRunType.SelectedValue)
    End Sub



    Private Sub lbMetrics_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Response.Redirect(String.Format("drilldown.aspx.aspx?rc={0}", Me.ReportCardID))
    End Sub

    Private Sub lbReportCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbReportCard.Click
        Response.Redirect(String.Format("reportcard.aspx?rc={0}", Me.ReportCardID))
    End Sub

    Private Sub lbRawData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbRawData.Click

        Dim qString As String

        If Not Request("rc") Is Nothing Then
            qString = "?rc=" & Request("rc")
        Else
            qString = "?rc=1"
        End If
        If Not Request("rid1") Is Nothing Then
            qString += "&rid1=" & Request("rid1")
        End If
        Response.Redirect("explorer.aspx" & qString)

    End Sub

    Private Sub lbPerfBugs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbPerfBugs.Click
        Response.Redirect("bugs.aspx")
    End Sub

    Private Sub lbComparisons_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbComparisons.Click
        Response.Redirect("SelectTest.aspx")
    End Sub


    Private Sub btnGoToRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoToRun.Click

        Dim run_id As Integer

        If txtRunID.Text.Trim.Length > 0 Then

            'Try
            run_id = Convert.ToInt32(txtRunID.Text)
            'Response.Redirect(Me.LinkPage & "?rid1=" & run_id.ToString)
            Server.Transfer(Me.LinkPage & "?rid1=" & run_id.ToString)
            'Catch ex As Exception
            'Response.Redirect(Me.LinkPage)
            'End Try
        Else

            Response.Redirect(Me.LinkPage)

        End If

    End Sub


    Public Function GetMostRecentRCRun() As Integer

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String
        Dim run_id As Integer

        myConnection = New SqlConnection(perfConnection)
        myCommand = New SqlCommand("SELECT TOP 1 validity, run_id, run, CONVERT(CHAR(10), start_date, 102) AS run_date FROM runs WHERE runtype_id=6 ORDER BY run_date DESC, validity DESC", myConnection)

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

        Try
            While myReader.Read()
                run_id = Convert.ToInt32(myReader("run_id"))
            End While
        Catch ex As Exception
            run_id = Nothing
        Finally
            myReader.Close()
            myConnection.Close()
        End Try

        Return run_id

    End Function

    Private Sub ddDateRange_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddDateRange.SelectedIndexChanged

        'BindDropDowns()
        'BindRuntypeDropDown()
        setSessionValues()
        ShowRunList()
        'ddRunType_SelectedIndexChanged(sender, e)

    End Sub

    Private Sub chkValid_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        'setSessionValues()

    End Sub


    Private Sub ddRunType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddRunType.SelectedIndexChanged
        setSessionValues()
        ShowRunList()
    End Sub

    Private Sub lbComparisonPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbComparisonsPage.Click
        Response.Redirect("http://xws/perf/compare.aspx")
    End Sub

    Private Sub lbPerfBlockerBugs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbPerfBlockerBugs.Click
        Response.Redirect("http://xws/team/docs/mb_m5/basics/perf/Feature%20Scorecards/PSQueries/PerfBasicBlockers.psq")
    End Sub

    Private Sub lbOrcasReportCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbOrcasReportCard.Click
        Response.Redirect(String.Format("orcasreportcard.aspx?rc={0}", Me.ReportCardID))
    End Sub

    Private Sub btnQuickCompare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuickCompare.Click

        newRun = txtNewRun.Text
        oldRun = txtOldRun.Text

        Dim sUrl As String

        Dim invalidNewRun As Boolean = (newRun = "New") Or (newRun = "") Or (newRun.Length = 0) 'Or (Int32.Parse(newRun) <= 0)
        Dim invalidOldRun As Boolean = (oldRun = "Old") Or (oldRun = "") Or (oldRun.Length = 0) 'Or (Int32.Parse(oldRun) <= 0)
        If (invalidNewRun) Then
            txtNewRun.Text = "Error!"
            txtNewRun.ForeColor = Color.Red
            Return
        End If

        If (invalidOldRun) Then
            txtOldRun.Text = "Error!"
            txtOldRun.ForeColor = Color.Red
            Return
        End If

        If (btnQuickCompare.Text = "Compare !") Then
            btnQuickCompare.Text = "Prepare Comparison"
            btnQuickCompare.BackColor = Color.LightGray
            btnQuickCompare.ForeColor = Color.Black
            sUrl = "javascript:window.status('Prepare Comparison');"

            btnQuickCompare.Attributes.Add("onclick", sUrl)
        Else
            sUrl = "javascript:window.open('http://xws/perf/comp.aspx?newRunId=" & newRun & "&oldRunId=" & oldRun & "&history=true','Comparison');"

            btnQuickCompare.Attributes.Add("onclick", sUrl)
            btnQuickCompare.BackColor = Color.Beige
            btnQuickCompare.ForeColor = Color.OrangeRed
            btnQuickCompare.Text = "Compare !"
        End If


    End Sub

    Private Sub txtNewRun_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNewRun.TextChanged
        btnQuickCompare.Text = "Prepare Comparison"
    End Sub

    Private Sub txtOldRun_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOldRun.TextChanged
        btnQuickCompare.Text = "Prepare Comparison"
    End Sub

    Private Sub lbOsloReportCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbOsloReportCard.Click
        Response.Redirect(String.Format("osloreportcard.aspx?rc={0}", Me.ReportCardID))
    End Sub

    Private Sub allRuntypes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles allRuntypes.CheckedChanged
        Session("runtypesDateRange") = 0
        allRuntypes.Checked = True
        last30Runtypes.Checked = False
        lastTenRuntypes.Checked = False

        BindRuntypeDropDown()
        ShowRunList()

        'ShowRunList()
    End Sub

    Private Sub last30Runtypes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles last30Runtypes.CheckedChanged
        Session("runtypesDateRange") = 30
        allRuntypes.Checked = False
        last30Runtypes.Checked = True
        lastTenRuntypes.Checked = False

        BindRuntypeDropDown()
        ShowRunList()
    End Sub

    Private Sub lastTenRuntypes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lastTenRuntypes.CheckedChanged
        Session("runtypesDateRange") = 10
        allRuntypes.Checked = False
        last30Runtypes.Checked = False
        lastTenRuntypes.Checked = True

        BindRuntypeDropDown()
        ShowRunList()
    End Sub

    Private Sub lbOrcasSP1ReportCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbOrcasSP1ReportCard.Click
        Response.Redirect(String.Format("orcasSP1reportcard.aspx?rc={0}", Me.ReportCardID))
    End Sub


End Class
