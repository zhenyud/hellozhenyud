Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Text
Imports System.IO

Partial Class csv
    Inherits base

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim Jobrun_id As Integer
        Dim run_id As Integer
        Dim test_id As Integer
        Dim filename As String = MakeFileName(Request("file"))
        Dim headers As String = Request.QueryString("headers")
        Dim values As String = Request.QueryString("values")

        Jobrun_id = Request2Int("jrid")
        run_id = Request2Int("rid")
        test_id = Request2Int("testid")

        'need error checking here

        Dim rc As Boolean = False
        Select Case Request("type")
            Case "jobrun"
                rc = GenerateCSV(filename, Jobrun_id)
            Case "test"
                rc = GenerateCSV(filename, run_id, test_id)
            Case "table"
                rc = GenerateCSV(filename, headers, values)
            Case Else
                rc = False
        End Select


        If rc Then
            Response.AppendHeader("content-disposition", "attachment; filename=" + Path.GetFileName(filename))
            Response.ContentType = "text/plain"
            Response.WriteFile(filename)
            Response.End()
            Response.Flush()
        Else
            lblError.Text = "Error generating csv file"
            lblDetail.Text = lblDetail.Text & "<p>filename=" & filename & "<br>jrid=" & Jobrun_id.ToString
        End If

    End Sub

    Protected Function Request2Int(ByVal key As String, Optional ByVal DefaultValue As Integer = 0) As Integer

        Try
            Dim Num As Integer = Convert.ToInt32(Request(key))
            If Num = 0 Then
                Return DefaultValue
            Else
                Return Num
            End If
        Catch ex As Exception
            Return DefaultValue
        End Try

    End Function

    Private Function GenerateCSV(ByVal FileName As String, ByVal JobRun_id As String) As Boolean

        'generate csv file here
        Dim rcount As Integer
        Dim trailer As Char = ","
        Dim sb As System.Text.StringBuilder


        Try

            Dim sw As StreamWriter = File.CreateText(FileName)

            Dim myReader As SqlDataReader = Me.sql2DataReader(String.Format("w_sp_csv {0}", JobRun_id))

            While myReader.Read

                sb = New StringBuilder
                Dim i As Integer
                If rcount = 0 Then 'Only write the column headers on the first record
                    For i = 0 To myReader.FieldCount - 1
                        sb.Append(myReader.GetName(i))
                        sb.Append(",")
                    Next
                    sw.WriteLine(sb.ToString.TrimEnd(trailer))
                    System.Diagnostics.Debug.WriteLine(sb.ToString.TrimEnd(trailer))
                End If

                sb = New StringBuilder
                For i = 0 To myReader.FieldCount - 1
                    sb.Append(myReader(i))
                    sb.Append(",")
                Next
                sw.WriteLine(sb.ToString.TrimEnd(trailer))
                System.Diagnostics.Debug.WriteLine(sb.ToString.TrimEnd(trailer))

                rcount = +1

            End While

            sw.Close()

            Return True

        Catch ex As Exception

            Return False

        End Try


    End Function

    Private Function GenerateCSV(ByVal FileName As String, ByVal Run_id As Integer, ByVal test_id As Integer) As Boolean

        'generate csv file here
        Dim rcount As Integer
        Dim trailer As Char = ","
        Dim sb As System.Text.StringBuilder


        Try

            Dim sw As StreamWriter = File.CreateText(FileName)

            Dim myReader As SqlDataReader = Me.sql2DataReader(String.Format("w_sp_csv_by_test {0}, {1}", Run_id.ToString, test_id.ToString))

            While myReader.Read

                sb = New StringBuilder
                Dim i As Integer
                If rcount = 0 Then 'Only write the column headers on the first record
                    For i = 0 To myReader.FieldCount - 1
                        sb.Append(myReader.GetName(i))
                        sb.Append(",")
                    Next
                    sw.WriteLine(sb.ToString.TrimEnd(trailer))
                    System.Diagnostics.Debug.WriteLine(sb.ToString.TrimEnd(trailer))
                End If

                sb = New StringBuilder
                For i = 0 To myReader.FieldCount - 1
                    sb.Append(myReader(i))
                    sb.Append(",")
                Next
                sw.WriteLine(sb.ToString.TrimEnd(trailer))
                System.Diagnostics.Debug.WriteLine(sb.ToString.TrimEnd(trailer))

                rcount = +1

            End While

            sw.Close()

            Return True

        Catch ex As Exception

            Return False

        End Try


    End Function


    Private Function GenerateCSV(ByVal FileName As String, ByVal headers As String, ByVal values As String) As Boolean

        'generate csv file here
        Dim trailer As Char = ","
        Dim sb As System.Text.StringBuilder

        Dim variations() As String = headers.Split(",")
        Dim vals() As String = values.Split(",")

        Try
            Dim sw As StreamWriter = File.CreateText(FileName)

            Dim k As Integer = 0

            While k < variations.Length
                sb = New StringBuilder
                sb.Append(variations(k))
                sb.Append(trailer)
                sb.Append(vals(k))
                sw.WriteLine(sb.ToString.TrimEnd(trailer))
                System.Diagnostics.Debug.WriteLine(sb.ToString.TrimEnd(trailer))
                k += 1
            End While

            sw.Close()

            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function

    Private Function MakeFileName(ByVal TestName As String) As String

        Dim PhysicalPath As String = Path.Combine(Server.MapPath("."), CsvPath)

        If TestName Is Nothing Then
            Return Nothing
        Else
            Try
                If File.Exists(PhysicalPath & TestName & ".csv") Then
                    File.Delete(PhysicalPath & TestName & ".csv")
                End If
                Return PhysicalPath & TestName & ".csv"
            Catch ex As Exception

                Dim uniqueId As Integer
                Do Until Not System.IO.File.Exists(PhysicalPath & TestName & "-" & uniqueId.ToString.PadLeft(3, "0") & ".csv")
                    uniqueId += 1
                Loop
                Return PhysicalPath & TestName & "-" & uniqueId.ToString.PadLeft(2, "0") & ".csv"

            End Try

        End If



    End Function

    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Redirect("explorer.aspx")
    End Sub
End Class
