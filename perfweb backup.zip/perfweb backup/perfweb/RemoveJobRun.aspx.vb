Imports System.Data
Imports System.Data.SqlClient

Partial Class RemoveJobRun
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim bobDimp As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\bobdimp")
    Dim rkwiec As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\rkwiec")
    Dim mauroot As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\mauroot")
    Dim wdong As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\wdong")
    Dim sagupta As Boolean = HttpContext.Current.User.Identity.Name.ToLower().Equals("redmond\sagupta")

    Dim adminUser As Boolean = bobDimp Or rkwiec Or mauroot Or sagupta Or wdong

    'Dim adminUser As Boolean = HttpContext.Current.User.IsInRole("XMLab MB Perf Pool")

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim runId As String
        Dim jobRunId As String

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand

        runId = Request.QueryString("runId")
        jobRunId = Request.QueryString("jobRunId")

        Try
            myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            myConnection.Open()
            myCommand = New SqlCommand("P_ExpungeJobRunId", myConnection)
            myCommand.CommandType = CommandType.StoredProcedure
            myCommand.Parameters.Add("@jobrun_id", jobRunId)

            If adminUser Then
                myCommand.ExecuteNonQuery()
            End If
        Catch se As SqlException

        Finally
            myConnection.Close()
            Response.Redirect("Explorer.aspx?rc=1&rid1=" & runId)
        End Try

    End Sub

End Class
