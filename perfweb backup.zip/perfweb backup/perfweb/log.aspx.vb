Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Text
Imports System.IO

Partial Class log
    Inherits base

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        'Dim Jobrun_id As Integer
        Dim fileName As String = "WttEa.log"
        Dim filePath As String

        If Not Request("file") = "" Then
            filePath = Request("file")
       
            Response.AppendHeader("content-disposition", "attachment; filename=" + Path.GetFileName(filePath & "\" & fileName))
            Response.ContentType = "text/plain"
            Response.WriteFile(filePath & "\" & fileName)
            Response.End()
            Response.Flush()
        Else
            Response.Redirect(fixPath(Request.UrlReferrer.PathAndQuery) & "&err=01")
            'lblError.Text = "Error generating csv file"
            'lblDetail.Text = lblDetail.Text & "<p>filename=" & filename & "<br>jrid=" & Jobrun_id.ToString
        End If

    End Sub

    Private Function fixPath(ByVal f As String) As String
        Dim i As Integer = f.IndexOf("&err")
        If i > 0 Then
            If f.IndexOf("?") > 0 Then
                Return f.Substring(0, i)
            Else
                Return f.Substring(0, i).Replace("&", "?")
            End If

        Else
            Return f
        End If
    End Function



    Private Function GetLog(ByVal jrGuid As Guid) As String

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String


        myConnection = New SqlConnection(conLog)
        myCommand = New SqlCommand("XwsPerf_GetLogLocationForRunGuid", myConnection)

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@guid", SqlDbType.UniqueIdentifier)
            .Parameters(0).Direction = ParameterDirection.Input
            .Parameters(0).Value = jrGuid
            .Parameters.Add("@LogLocation", SqlDbType.NVarChar, 4000)
            .Parameters(1).Direction = ParameterDirection.Output
        End With

        Try
            myConnection.Open()
            myCommand.ExecuteScalar()
            'myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

        Dim Logfile As String = myCommand.Parameters("@LogLocation").Value.ToString()

        Return IIf(Logfile.Length > 0, Logfile, Nothing)

    End Function

End Class
