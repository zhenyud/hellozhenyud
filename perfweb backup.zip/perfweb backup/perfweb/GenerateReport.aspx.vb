Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.McsMx.Web.Chart
Imports System.Collections

Partial Class GenerateReport
    Inherits System.Web.UI.Page

    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim runId As Integer
    Dim runtype As String
    Dim count As String
    Dim testId As String
    Dim runtype_id As String 'set this as global variable for rps
    Dim testName As String
    Dim selruns As String
    Dim selectedTests As String = testId
    Dim showForward As Integer = 0
    Protected WithEvents Table1 As System.Web.UI.WebControls.Table
    Protected WithEvents lblRun As System.Web.UI.WebControls.Label
    Dim clientOnlyTests As String


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        runId = Request.QueryString("runid")
        count = Request.QueryString("count")
        testId = Request.QueryString("testId")
        testName = Request.QueryString("testName")
        selectedTests = testId

        Dim showForwardField As String = Request.QueryString("showForward")

        If Not showForwardField Is Nothing And showForwardField <> String.Empty Then
            showForward = Convert.ToInt32(showForwardField)
        End If

        selruns = GetRuns()
        clientOnlyTests = GetClientOnlyTests()

        If testName <> "-1" Then
            lblHeader.Text = "Trend for the last " + count.ToString() + " runs of " + testName
        End If

        ShowRunsTable()
        ShowRunsStats()
        ShowCharts()

    End Sub

    Private Function GetRuns() As String
        Dim selruns As String = String.Empty

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr1 As SqlDataReader
        Dim dr As SqlDataReader
        Dim sql As String

        Dim s As String

        Try
            connection = New SqlConnection(perfConnection)
            connection.Open()

            sql = "select r.runtype_id,r.labconfig_id,rt.runtype from runs r"
            sql += " inner join runtypes rt on rt.runtype_id=r.runtype_id"
            sql += " where r.run_id=" & runId

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            Dim labconfig_id As String
            'change this as global variable for rps
            'Dim runtype_id As String

            dr1 = command.ExecuteReader()

            While dr1.Read()
                runtype_id = Convert.ToString(dr1("runtype_id"))
                labconfig_id = Convert.ToString(dr1("labconfig_id"))
                runtype = Convert.ToString(dr1("runtype"))
            End While

            dr1.Close()

            Dim relatedRuntypes As String

            ' related runtypes where confusing to some people, so I'm temporarily disabling them -- RK 070619
            If runtype_id = "90" Then 'V1_FT
                relatedRuntypes = "90" ',75,116" ' 75=Indigo_FeatureTeams_WAP, 116 V1_FT_Whidbey
            ElseIf runtype_id = "100" Then 'V1_Latency
                relatedRuntypes = "100" ',71" ' 75=Indigo_Latency_WAP
            ElseIf runtype_id = "91" Then 'V1_Startup
                relatedRuntypes = "91" ' ,66" ' 66=Indigo_Startup_WAP
            Else
                relatedRuntypes = runtype_id
            End If

            sql = "select distinct top " & count & " r.run_id from runs r "
            sql += "inner join jobruns j on r.run_id=j.run_id "
            sql += "where r.runtype_id in (" & relatedRuntypes & ") "
            sql += "and r.labconfig_id=" & labconfig_id

            If showForward = 1 Then
                sql += " and r.start_date >= (select start_date from runs where run_id=" & runId & ") "
            Else
                sql += " and r.start_date <= (select start_date from runs where run_id=" & runId & ") "
            End If

            'add for RPS
            If runtype_id = "182" Then
                sql = "select distinct top " & count & " r.run_id, t.createtime from (runs r "
                sql += "inner join jobruns j on r.run_id=j.run_id) "
                sql += "inner join RPS_testRun t on r.run_id=t.labRunId "
                sql += "where r.runtype_id in (" & relatedRuntypes & ") "
                sql += "and r.labconfig_id=" & labconfig_id

                If showForward = 1 Then
                    sql += " and t.createtime >= (select createtime from RPS_testRun where labRunId=" & runId & ") "
                Else
                    sql += " and t.createtime <= (select createtime from RPS_testRun where labRunId=" & runId & ") "
                End If
            End If


            If selectedTests <> "-1" Then
                sql += " and j.test_id in (" & selectedTests & ") "
            End If

            'add for RPS
            If runtype_id = "182" Then
                sql += " order by t.createtime desc"
            Else
                sql += " order by r.run_id desc"
            End If

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim nextRunId As Integer

            While dr.Read()
                nextRunId = Convert.ToInt32(dr("run_id"))
                s += nextRunId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

            selruns = s

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return s

    End Function

    Private Function GetClientOnlyTests() As String
        'GET CLIENT ONLY TESTS
        'get tests using only role_id=1

        Dim sqlRole1 As String = "SELECT newruns.test_id FROM ( SELECT DISTINCT processes.role_id, jobruns.test_id"
        sqlRole1 += " FROM processes INNER JOIN jobruns ON jobruns.jobrun_id = processes.jobrun_id"
        sqlRole1 += String.Format(" WHERE processes.role_id IN ({0},{1},{2}) AND jobruns.run_id IN ({3}) ", 1, 2, 9, selruns)

        If selectedTests <> -1 Then
            sqlRole1 += String.Format(" AND jobruns.test_id IN ({0})", selectedTests)
        End If

        sqlRole1 += " ) AS newruns GROUP BY newruns.test_id HAVING count(*) = 1"

        'txtException.Text = sqlRole1

        Dim clientOnlyTests As String = String.Empty

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sqlRole1, connection)

            dr = command.ExecuteReader()

            While dr.Read()
                clientOnlyTests += dr.Item("test_id") & ","
            End While

            If (Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0)) And clientOnlyTests.EndsWith(",") Then
                clientOnlyTests = clientOnlyTests.TrimEnd(",")
            End If

            'Session("clientOnlyTests") = clientOnlyTests
        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

        Return clientOnlyTests

    End Function

    Private Function ShowCharts()

        Dim selrunsArr() As String
        Dim selrunsCount As Integer = 0
        selrunsArr = selruns.Split(",")
        selrunsCount = selrunsArr.Length

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        Dim summary As String = String.Empty
        Dim chkSummary As Boolean = False
        summary = Request.QueryString("summary")
        If Not (summary Is Nothing OrElse summary.Length = 0) Then
            chkSummary = Boolean.Parse(summary)
        End If

        Dim memoryTest As Boolean = False
        Dim refsetTest As Boolean = False
        Dim latencyTest As Boolean = False

        If Not (runtype Is Nothing OrElse runtype.Length = 0) Then
            memoryTest = runtype.ToLower().IndexOf("memory") >= 0
            refsetTest = runtype.ToLower().IndexOf("refset") >= 0
            latencyTest = runtype.ToLower().IndexOf("latency") >= 0 Or runtype.ToLower().IndexOf("startup") >= 0
        End If

        Dim newRunnames As String = String.Empty
        Dim newRunnamesArr() As String
        Dim newRunnamesCount As Integer = 0
        newRunnames = CType(Session("newRunnames"), String)

        If Not (newRunnames Is Nothing OrElse newRunnames.Length = 0) Then
            newRunnamesArr = newRunnames.Split(",")
            newRunnamesCount = newRunnamesArr.Length
        End If

        Dim runs As New Hashtable
        Dim k As Integer = 0

        If selrunsCount = newRunnamesCount Then
            While k < selrunsArr.Length
                runs.Add(selrunsArr(k), newRunnamesArr(k))
                k += 1
            End While
        End If

        sql = "SELECT DISTINCT runs.run, runs.run_id, tests.test, jobruns.test_id, measurements.measured_value, processes.process_id, processes.role_id, variations.variation"
        sql += ", roles.role, metrics.metric"
        sql += " FROM runs INNER JOIN jobruns ON jobruns.run_id = runs.run_id"
        sql += " INNER JOIN tests ON tests.test_id = jobruns.test_id"
        sql += " INNER JOIN processes ON processes.jobrun_id = jobruns.jobrun_id"
        sql += " INNER JOIN measurements ON measurements.process_id = processes.process_id"
        sql += " INNER JOIN variations ON variations.variation_id = processes.variation_id"
        sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
        sql += " INNER JOIN roles on roles.role_id = processes.role_id WHERE "

        'add for RPS
        If runtype_id = "182" Then
            sql = "SELECT DISTINCT runs.run, runs.run_id, RPS_testRun.createtime, tests.test, jobruns.test_id, measurements.measured_value, processes.process_id, processes.role_id, variations.variation"
            sql += ", roles.role, metrics.metric"
            sql += " FROM runs INNER JOIN jobruns ON jobruns.run_id = runs.run_id"
            sql += " INNER JOIN tests ON tests.test_id = jobruns.test_id"
            sql += " INNER JOIN RPS_testRun on runs.run_id=RPS_testRun.labRunId "
            sql += " INNER JOIN processes ON processes.jobrun_id = jobruns.jobrun_id"
            sql += " INNER JOIN measurements ON measurements.process_id = processes.process_id"
            sql += " INNER JOIN variations ON variations.variation_id = processes.variation_id"
            sql += " INNER JOIN metrics on measurements.metric_id = metrics.metric_id"
            sql += " INNER JOIN roles on roles.role_id = processes.role_id WHERE "
        End If


        Dim sql3 As String = String.Empty
        If Not chkSummary Then
            sql3 = "(jobruns.validity = 4) AND "
        End If

        Dim sql1 As String 'runs with role_id only=1
        Dim sql2 As String 'runs with role_id=2 or role_id=9
        Dim clause As String
        Dim testClause As String

        If selectedTests <> -1 Then
            testClause = String.Format("(jobruns.test_id IN ({0})) AND ", selectedTests)
        Else
            testClause = ""
        End If

        If memoryTest Then
            clause = "(metrics.metric like '%Module Count%' OR metrics.metric like '%Thread Count%' OR metrics.metric like '%Working Set%')"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 1, 2)
        ElseIf refsetTest Then
            clause = "(metrics.metric like '%UniqueFileBacked%' OR metrics.metric like '%PeakDynamic%')"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 1, 9)
        ElseIf latencyTest Then
            'clause = "(metrics.metric in ('AverageLatency','95thPercentileLatency'))"
            clause = "(metrics.metric in ('AverageLatency'))"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3}, {4})) ", selruns, clause, 1, 2, 9)
        Else
            clause = "(measurements.metric_id = 56)"
            sql2 = sql3 & testClause & String.Format("(runs.run_id IN ({0})) AND {1} AND (processes.role_id IN ({2}, {3})) ", selruns, clause, 2, 9)
        End If

        'sql2 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3}, {4})) ", Session("SelectedTests"), selruns, 56, 2, 9)
        sql1 = sql3 & String.Format("(jobruns.test_id IN ({0})) AND (runs.run_id IN ({1})) AND (measurements.metric_id = {2}) AND (processes.role_id IN ({3})) ", clientOnlyTests, selruns, 56, 1)

        If Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0) Then
            sql = sql & "(" & sql1 & ") OR (" & sql2 & ")"
        Else
            sql = sql & sql2
        End If


        'add for RPS
        If runtype_id = "182" Then
            sql += " ORDER BY tests.test, processes.role_id, variations.variation, metrics.metric, RPS_testRun.createtime, processes.process_id"
        Else
            sql += " ORDER BY tests.test, processes.role_id, variations.variation, metrics.metric, runs.run_id, processes.process_id"
        End If

        connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        connection.Open()

        command = New SqlCommand(sql, connection)
        command.CommandTimeout = 120

        dr = command.ExecuteReader()

        Dim lastVariation As String
        lastVariation = String.Empty

        Dim lastTest As String
        lastTest = String.Empty

        Dim lastRole As String
        lastRole = String.Empty

        Dim lastMetric As String
        lastMetric = String.Empty

        Dim i As Integer = 0

        Dim test As String
        Dim run As String
        Dim variation As String
        Dim result As Double
        Dim run_id As String
        Dim role As String
        Dim metric As String

        Dim xValues As String = String.Empty
        Dim yValues As String = String.Empty

        Dim changeRunname As Boolean = (Not (newRunnames Is Nothing OrElse newRunnames.Length = 0)) And (selrunsCount = newRunnamesCount)

        While dr.Read()

            test = CType(dr.Item("test"), String)
            variation = CType(dr.Item("variation"), String)
            run = CType(dr.Item("run"), String)
            result = CType(dr.Item("measured_value"), Double)
            run_id = CType(dr.Item("run_id"), String)
            role = CType(dr.Item("role"), String)
            metric = CType(dr.Item("metric"), String)

            If i = 0 Then
                lastVariation = variation
                lastTest = test
                lastRole = role
                lastMetric = metric

                i += 1
            End If

            If (variation <> lastVariation Or test <> lastTest Or role <> lastRole Or metric <> lastMetric) Then

                xValues = xValues.Substring(0, xValues.Length - 1)
                yValues = yValues.Substring(0, yValues.Length - 1)
                lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")

                AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues)

                lastVariation = variation
                lastTest = test
                lastRole = role
                lastMetric = metric

                xValues = ""
                yValues = ""

            End If

            If changeRunname Then
                xValues += runs(run_id) & ","
            Else
                xValues += run & ","
            End If

            yValues += result & ","

        End While

        If (xValues <> Nothing And xValues.Length > 0) And xValues.EndsWith(",") Then
            xValues = xValues.TrimEnd(",")
        End If

        If (yValues <> Nothing And yValues.Length > 0) And yValues.EndsWith(",") Then
            yValues = yValues.TrimEnd(",")
        End If

        If (lastTest <> Nothing And lastTest.Length > 0) Then
            lastTest = lastTest.Replace("Indigo.Performance.", "I.").Replace("Ncl.Performance.", "N.").Replace("Whidbey.Performance.", "W.").Replace("FeatureTeams.", "FT.").Replace("Throghput.", "TP.")
        End If

        If xValues = "" Or yValues = "" Then
            lblHeader.Text = "No Valid Values found in the last " + count.ToString() + " runs of " + testName
        Else
            AddChartCell(lastRole, lastTest, lastVariation, lastMetric, xValues, yValues)
        End If


    End Function

    Private Function ShowRunsStats()

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        pnlRuns.Height = Unit.Pixel(100)

        tblRunsStats.CellPadding = 3
        tblRunsStats.CellSpacing = 0
        tblRunsStats.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblRunsStats.BorderStyle = BorderStyle.Solid
        tblRunsStats.GridLines = System.Web.UI.WebControls.GridLines.Both
        tblRunsStats.BorderWidth = Unit.Pixel(3)

        Dim i As Integer = 0

        Dim tests As String
        Dim run As String
        Dim variations As String
        Dim failedVariations As String
        Dim testRuns As String

        sql = "select r.run_id,r.run,r.tests,r.test_runs,r.variations,r.failed_variations"
        sql += " from runs r"
        sql += " where r.run_id in (" + selruns + ")"
        sql += " order by r.run_id"

        'add for RPS
        If runtype_id = "182" Then
            sql = "select r.run_id,t.createtime, r.run,r.tests,r.test_runs,r.variations,r.failed_variations"
            sql += " from runs r"
            sql += " inner join RPS_testRun t on r.run_id=t.labRunId "
            sql += " where r.run_id in (" + selruns + ")"
            sql += " order by t.createtime"
        End If

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            While dr.Read()

                tests += CType(dr.Item("tests"), String) & ","
                variations += CType(dr.Item("variations"), String) & ","
                run += CType(dr.Item("run"), String) & ","
                failedVariations += CType(dr.Item("failed_variations"), Double) & ","
                testRuns += CType(dr.Item("test_runs"), String) & ","

            End While

            If (tests <> Nothing And tests.Length > 0) And tests.EndsWith(",") Then
                tests = tests.TrimEnd(",")
            End If

            If (variations <> Nothing And variations.Length > 0) And variations.EndsWith(",") Then
                variations = variations.TrimEnd(",")
            End If

            If (run <> Nothing And run.Length > 0) And run.EndsWith(",") Then
                run = run.TrimEnd(",")
            End If

            If (failedVariations <> Nothing And failedVariations.Length > 0) And failedVariations.EndsWith(",") Then
                failedVariations = failedVariations.TrimEnd(",")
            End If

            If (testRuns <> Nothing And testRuns.Length > 0) And testRuns.EndsWith(",") Then
                testRuns = testRuns.TrimEnd(",")
            End If

            AddRowToStatsTable(run, tests, "Number of Tests")
            AddRowToStatsTable(run, testRuns, "Number of Test Iterations")
            AddRowToStatsTable(run, variations, "Number of Variations")
            AddRowToStatsTable(run, failedVariations, "Number of Failed Variations")

        Catch ex As Exception

        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function

    Private Function AddRowToStatsTable(ByVal run As String, ByVal metric As String, ByVal chartTitle As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow
        Dim chartLink As String

        chartLink = "<img src='ShowCharts.aspx?x=" & run & "&y=" & metric & "&Title=" & chartTitle & "&Metric=" & "Count" & "&Style=Line'>"

        AddSimpleChartCell(chartLink, row)

        tblRunsStats.Rows.Add(row)

    End Function

    Private Function ShowRunsTable()

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection
        Dim sql As String

        pnlRuns.Height = Unit.Pixel(100)

        tblRunsData.CellPadding = 3
        tblRunsData.CellSpacing = 0
        tblRunsData.BorderColor = Color.FromArgb(13421721) '#cccc99
        tblRunsData.BorderStyle = BorderStyle.Solid
        tblRunsData.GridLines = System.Web.UI.WebControls.GridLines.Both
        tblRunsData.BorderWidth = Unit.Pixel(3)

        Dim runId As String = "<b>Run ID</b>"
        Dim run As String = "<b>Run</b>"
        Dim runtype As String = "<b>Run Type</b>"
        Dim frameworkBuild As String = "<b>CLR</b>"
        Dim wcfBuild As String = "<b>WCF</b>"
        Dim netfxBuild As String = "<b>Netfx3.5</b>"
        Dim wfBuild As String = "<b>WF</b>"
        Dim osloBuild As String = "<b>Oslo</b>"
        Dim runDate As String = "<b>Date</b>"

        sql = "select distinct r.run_id,r.run,rt.runtype,b.build as WCF_build,nb.netfxbuild as Netfx35_build,"
        sql += " wb.wfbuild as WF_build,convert(varchar(10),r.start_date,101) as start_date,"
        sql += " ob.oslobuild as oslo_build, r.tests,r.test_runs,r.variations,r.failed_variations,f.framework"
        sql += " from runs r inner join builds b on r.build_id=b.build_id "
        sql += " inner join netfxbuilds nb on r.netfxbuild_id=nb.netfxbuild_id"
        sql += " inner join wfbuilds wb on r.wfbuild_id=wb.wfbuild_id"
        sql += " inner join oslobuilds ob on r.oslobuild_id=ob.oslobuild_id"
        sql += " inner join runtypes rt on r.runtype_id=rt.runtype_id"
        sql += " inner join jobruns j on j.run_id=r.run_id"
        sql += " inner loop join processes p on p.jobrun_id=j.jobrun_id"
        sql += " inner join frameworks f on f.framework_id=p.framework_id"
        sql += " where r.run_id in (" + selruns + ")"
        sql += " order by r.run_id desc "

        'add for rps

        If runtype_id = "182" Then
            sql = "select distinct r.run_id,r.run,rt.runtype,t.createtime, b.build as WCF_build,nb.netfxbuild as Netfx35_build,"
            sql += " wb.wfbuild as WF_build,convert(varchar(10),r.start_date,101) as start_date,"
            sql += " ob.oslobuild as oslo_build, r.tests,r.test_runs,r.variations,r.failed_variations,f.framework"
            sql += " from runs r inner join builds b on r.build_id=b.build_id "
            sql += " inner join RPS_testRun t on r.run_id=t.labRunId "
            sql += " inner join netfxbuilds nb on r.netfxbuild_id=nb.netfxbuild_id"
            sql += " inner join wfbuilds wb on r.wfbuild_id=wb.wfbuild_id"
            sql += " inner join oslobuilds ob on r.oslobuild_id=ob.oslobuild_id"
            sql += " inner join runtypes rt on r.runtype_id=rt.runtype_id"
            sql += " inner join jobruns j on j.run_id=r.run_id"
            sql += " inner loop join processes p on p.jobrun_id=j.jobrun_id"
            sql += " inner join frameworks f on f.framework_id=p.framework_id"
            sql += " where r.run_id in (" + selruns + ")"
            sql += " order by t.createtime desc "
        End If

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            AddRowToRunsTable(runId, run, runtype, frameworkBuild, wcfBuild, netfxBuild, wfBuild, osloBuild, runDate)

            While dr.Read()

                runId = CType(dr.Item("run_id"), String)
                runId = String.Format("<a href=explorer.aspx?rc=1&rid1={0}>{0}</a>", runId)
                run = CType(dr.Item("run"), String)
                run = run.Substring(5)
                runtype = CType(dr.Item("runtype"), String)
                frameworkBuild = CType(dr.Item("framework"), String)
                wcfBuild = CType(dr.Item("wcf_build"), String)
                netfxBuild = CType(dr.Item("netfx35_build"), String)
                wfBuild = CType(dr.Item("WF_build"), String)
                osloBuild = CType(dr.Item("oslo_build"), String)
                runDate = CType(dr.Item("start_date"), String)

                AddRowToRunsTable(runId, run, runtype, frameworkBuild, wcfBuild, netfxBuild, wfBuild, osloBuild, runDate)

            End While
        Catch ex As Exception

        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function


    Private Function AddRowToRunsTable(ByVal runId As String, ByVal run As String, ByVal runtype As String, ByVal frameworkBuild As String, ByVal wcfBuild As String, ByVal netfxBuild As String, ByVal wfBuild As String, ByVal osloBuild As String, ByVal runDate As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(runId, row)
        AddSimpleCell(run, row)
        AddSimpleCell(runtype, row)
        AddSimpleCell(frameworkBuild, row)
        AddSimpleCell(wcfBuild, row)
        AddSimpleCell(wfBuild, row)
        AddSimpleCell(netfxBuild, row)
        AddSimpleCell(osloBuild, row)
        AddSimpleCell(runDate, row)

        tblRunsData.Rows.Add(row)

    End Function


    Private Function Add2Cells(ByVal cell1 As String, ByVal cell2 As String)

        Dim row As TableRow = New System.Web.UI.WebControls.TableRow

        AddSimpleCell(cell1, row)
        AddSimpleCell(cell2, row)

        tblCharts.Rows.Add(row)

    End Function

    Private Function AddSimpleCell(ByVal item As String, ByRef row As TableRow)
        Dim cell As TableCell = New System.Web.UI.WebControls.TableCell
        cell.Text = item
        row.Cells.Add(cell)
    End Function

    Private Function AddSimpleChartCell(ByVal item As String, ByRef row As TableRow)
        Dim cell As TableCell = New System.Web.UI.WebControls.TableCell
        cell.ColumnSpan = 8
        cell.Text = item
        row.Cells.Add(cell)
    End Function

    Private Function AddValuesRow(ByVal x As String, ByVal y As String, ByVal metric As String)

        Dim tbl As Table = New Table

        tbl.CellPadding = 3
        tbl.CellSpacing = 0
        tbl.BorderColor = Color.FromArgb(13421721) '#cccc99
        tbl.BorderStyle = BorderStyle.Solid
        tbl.GridLines = System.Web.UI.WebControls.GridLines.Both
        tbl.BorderWidth = Unit.Pixel(1)

        Dim cell As TableCell
        Dim row As TableRow
        Dim diffCell As TableCell
        Dim diffRow As TableRow

        Dim xArray As ArrayList

        Dim xArr() As String
        xArr = x.Split(",")

        Dim yArr() As String
        yArr = y.Split(",")

        Dim j As Integer = 0

        While j < xArr.Length

            row = New System.Web.UI.WebControls.TableRow
            diffRow = New System.Web.UI.WebControls.TableRow

            Dim k As Integer = 0

            While (k < 10 And (j + k) < xArr.Length)
                cell = New System.Web.UI.WebControls.TableCell

                cell.Font.Size = FontUnit.XXSmall
                cell.BackColor = Color.LightSteelBlue
                cell.Text = xArr(j + k).Substring(5)
                row.Cells.Add(cell)

                k += 1
            End While

            tbl.Rows.Add(row)

            Dim curVal As Double
            Dim prevVal As Double
            Dim delta As Double
            row = New System.Web.UI.WebControls.TableRow

            k = 0

            While (k < 10 And (j + k) < xArr.Length)
                cell = New System.Web.UI.WebControls.TableCell

                cell.Font.Size = FontUnit.XXSmall
                cell.HorizontalAlign = HorizontalAlign.Center
                cell.Text = yArr(j + k)
                row.Cells.Add(cell)

                diffCell = New System.Web.UI.WebControls.TableCell

                diffCell.Font.Size = FontUnit.XXSmall
                diffCell.HorizontalAlign = HorizontalAlign.Center

                If k = 0 And j = 0 Then
                    diffCell.Text = "Delta %"
                    diffCell.BackColor = Color.LightGray
                Else
                    curVal = Double.Parse(yArr(j + k))
                    prevVal = Double.Parse(yArr(j - 1 + k))
                    If (curVal = 0 And prevVal = 0) Then
                        delta = 0
                    Else
                        delta = Math.Round(((curVal - prevVal) / prevVal) * 100, 1)
                    End If

                    If metric.ToLower() <> "throughput" Then
                        delta = -delta
                    End If

                    If delta <= -3.0 Then
                        diffCell.BackColor = Color.Red
                        diffCell.ForeColor = Color.White
                    ElseIf delta >= 3.0 Then
                        diffCell.BackColor = Color.ForestGreen
                        diffCell.ForeColor = Color.White
                    End If
                    diffCell.Text = delta.ToString()

                End If
                diffRow.Cells.Add(diffCell)

                k += 1
            End While

            tbl.Rows.Add(row)
            tbl.Rows.Add(diffRow)

            row = New System.Web.UI.WebControls.TableRow
            cell = New System.Web.UI.WebControls.TableCell
            cell.Controls.Add(tbl)
            cell.ColumnSpan = 2
            row.Cells.Add(cell)

            tblCharts.Rows.Add(row)

            j += 10

        End While

    End Function

    Private Function AddChartCell(ByVal lastRole As String, ByVal lastTest As String, ByVal lastVariation As String, ByVal lastMetric As String, ByVal x As String, ByVal y As String)

        Dim title As String
        Dim roleInfo1 As String
        Dim roleInfo2 As String
        Dim testInfo1 As String
        Dim testInfo2 As String
        Dim variationInfo1 As String
        Dim variationInfo2 As String

        Dim cell As TableCell
        Dim row As TableRow

        title = lastRole & " -- " & lastTest & " - " & lastVariation

        roleInfo1 = "<b>Role:  </b>"
        roleInfo2 = lastRole
        Add2Cells(roleInfo1, roleInfo2)

        testInfo1 = "<b>Test:  </b>"
        testInfo2 = lastTest
        Add2Cells(testInfo1, testInfo2)

        variationInfo1 = "<b>Variation:  </b>"
        variationInfo2 = lastVariation
        Add2Cells(variationInfo1, variationInfo2)

        AddValuesRow(x, y, lastMetric)

        cell = New System.Web.UI.WebControls.TableCell
        row = New System.Web.UI.WebControls.TableRow

        Session("xValues") = x
        Session("yValues") = y

        cell.ColumnSpan = 2
        cell.Text = "<img src='ShowCharts.aspx?x=" & x & "&y=" & y & "&Title=" & title & "&Metric=" & lastMetric & "&Style=Line'>"
        row.Cells.Add(cell)
        tblCharts.Rows.Add(row)
    End Function
End Class
