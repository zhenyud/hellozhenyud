Imports System.Data.SqlClient

Public Class Bugs
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid3 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid4 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid5 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid6 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Error1 As System.Web.UI.WebControls.Literal
    Protected WithEvents Error2 As System.Web.UI.WebControls.Literal
    Protected WithEvents Error3 As System.Web.UI.WebControls.Literal
    Protected WithEvents Error4 As System.Web.UI.WebControls.Literal
    Protected WithEvents Error5 As System.Web.UI.WebControls.Literal
    Protected WithEvents Error6 As System.Web.UI.WebControls.Literal

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Delegate Sub BindDG(ByVal SortExp As String)
    Dim dv1, dv2, dv3, dv4, dv5, dv6 As New DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            BindPerfLabBugs(Nothing)        'MessageBus Performance Tests Issues
            BindPerformanceBugs(Nothing)    'MessageBus Product Performance Issues
            '            BindBugs3(Nothing) 'VSWhidbey
            '            BindBugs4(Nothing)
            '            BindBugs5(Nothing)
            '            BindBugs6(Nothing)
        End If
    End Sub

    Private Sub BindPerfLabBugs(ByVal SortExp As String)

        Dim con As String = ConfigurationSettings.AppSettings("MessageBusConnect")
        Dim sql As String = ConfigurationSettings.AppSettings("PerfLabQuery")
        Try
            dv1 = GetDataView(con, sql)
        Catch ex As SqlException
            Error1.Text = ex.ToString()
        End Try

        DataGrid1.DataSource = dv1
        If Not SortExp Is Nothing Then dv1.Sort = SortExp
        DataGrid1.DataBind()

    End Sub

    Private Sub BindPerformanceBugs(ByVal SortExp As String)

        Dim con As String = ConfigurationSettings.AppSettings("MessageBusConnect")
        Dim sql As String = ConfigurationSettings.AppSettings("PerformanceQuery")
        Try
            dv1 = GetDataView(con, sql)
        Catch ex As SqlException
            Error1.Text = ex.ToString()
        End Try

        Datagrid2.DataSource = dv1
        If Not SortExp Is Nothing Then dv1.Sort = SortExp
        Datagrid2.DataBind()

    End Sub

    Private Sub BindBugs3(ByVal SortExp As String)

        Dim sql As String = ConfigurationSettings.AppSettings("VSWhidbeyQuery").Replace("*", "%")
        Dim con As String = "integrated security=SSPI;data source=DEVTOOLSPS2;persist security info=False;initial catalog=VSWhidbey1Issue"
        Try
            dv3 = GetDataView(sql, con)
        Catch ex As SqlException
            Error3.Text = ex.ToString()
        End Try

        Datagrid3.DataSource = dv3
        If Not SortExp Is Nothing Then dv3.Sort = SortExp
        Datagrid3.DataBind()

    End Sub

    Private Sub BindBugs4(ByVal SortExp As String)

        Dim sql As String = ConfigurationSettings.AppSettings("WebDataQuery").Replace("*", "%")
        Dim con As String = "integrated security=SSPI;data source=SQLPSTEST;persist security info=False;initial catalog=WebData1Issue"
        Try
            dv4 = GetDataView(sql, con)
        Catch ex As SqlException
            Error4.Text = ex.ToString()
        End Try

        Datagrid4.DataSource = dv4
        If Not SortExp Is Nothing Then dv4.Sort = SortExp
        Datagrid4.DataBind()

    End Sub

    Private Sub BindBugs5(ByVal SortExp As String)

        Dim sql As String = ConfigurationSettings.AppSettings("SQLTrackingQuery").Replace("*", "%")
        Dim con As String = "integrated security=SSPI;data source=SQLPSTEST;persist security info=False;initial catalog=SQLProjectTracking1Issue"
        Try
            dv5 = GetDataView(sql, con)
        Catch ex As SqlException
            Error5.Text = ex.ToString()
        End Try

        Datagrid5.DataSource = dv5
        If Not SortExp Is Nothing Then dv5.Sort = SortExp
        Datagrid5.DataBind()

    End Sub

    Private Sub BindBugs6(ByVal SortExp As String)

        Dim sql As String = ConfigurationSettings.AppSettings("TCPWQuery").Replace("*", "%")
        Dim con As String = "integrated security=SSPI;data source=TKBGITSQL27;persist security info=False;initial catalog=MessageBus1Issue"
        Try
            dv6 = GetDataView(sql, con)
        Catch ex As SqlException
            Error6.Text = ex.ToString()
        End Try

        Datagrid6.DataSource = dv6
        If Not SortExp Is Nothing Then dv6.Sort = SortExp
        Datagrid6.DataBind()

    End Sub

    Private Function GetDataView(ByVal ConnectionString As String, ByVal SQLQuery As String) As DataView
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet
        Dim dr As DataRow
        Dim dv As DataView

        myConnection = New SqlConnection(ConnectionString)
        myDA = New SqlDataAdapter(SQLQuery, myConnection)

        myConnection.Open()
        myDA.Fill(ds)
        dv = New DataView(ds.Tables(0))

        myConnection.Close()
        Return dv

    End Function

    Private Function GetDataView(ByVal scenario_number As Integer) As DataView
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim myDA As SqlDataAdapter
        Dim ds As New DataSet
        Dim dr As DataRow
        Dim dv As DataView
        Dim sql As String

        If scenario_number = 0 Then
            sql = String.Format("SELECT BugID, Area, CONVERT(CHAR(10),OpenedDate,110) as OpenedDate, Environment, Priority, AssignedTo, Title, Custom, Issuetype, TestCase FROM Bugs WHERE (Status = 'Active') AND (TestCase IS NOT NULL) AND (Issuetype = N'Performance')")
        Else
            sql = String.Format("SELECT BugID, Area, CONVERT(CHAR(10),OpenedDate,110) as OpenedDate, Environment, Priority, AssignedTo, Title, Custom, Issuetype, TestCase FROM Bugs WHERE (Status = 'Active') AND (TestCase IS NOT NULL) AND (Issuetype = N'Performance') AND (PATINDEX('%[T,L]{0}[^0-9]%', RTRIM(TestCase) + ',') > 0)", scenario_number)
        End If


        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("conPS"))
        myDA = New SqlDataAdapter(sql, myConnection)
        myConnection.Open()
        myDA.Fill(ds)
        dv = New DataView(ds.Tables(0))
        myConnection.Close()
        Return dv

    End Function

    Private Sub Datagrid1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DataGrid1.SortCommand

        SortDG(DataGrid1, AddressOf BindPerfLabBugs, e)

    End Sub

    Private Sub Datagrid2_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Datagrid2.SortCommand

        SortDG(Datagrid2, AddressOf BindPerformanceBugs, e)

    End Sub

    Private Sub Datagrid3_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Datagrid3.SortCommand

        SortDG(Datagrid3, AddressOf BindBugs3, e)

    End Sub

    Private Sub Datagrid4_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Datagrid4.SortCommand

        SortDG(Datagrid4, AddressOf BindBugs4, e)

    End Sub

    Private Sub Datagrid5_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Datagrid5.SortCommand

        SortDG(Datagrid5, AddressOf BindBugs5, e)

    End Sub

    Private Sub Datagrid6_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Datagrid6.SortCommand

        SortDG(Datagrid6, AddressOf BindBugs6, e)

    End Sub

    Private Sub SortDG(ByVal DG As DataGrid, ByVal GridBinder As BindDG, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs)

        Dim arrSortExpr() As String
        Dim i As Integer

        If e.SortExpression = "" Then Return

        GridBinder.Invoke(e.SortExpression)

        arrSortExpr = Split(e.SortExpression, " ")
        For i = 0 To DG.Columns().Count - 1
            If (DG.Columns(i).SortExpression = e.SortExpression) Then
                If UCase(arrSortExpr(1)) = "ASC" Then
                    arrSortExpr(1) = "DESC"
                ElseIf UCase(arrSortExpr(1)) = "DESC" Then
                    arrSortExpr(1) = "ASC"
                End If
                DG.Columns(i).SortExpression = arrSortExpr(0) & " " & arrSortExpr(1)
                Exit For
            End If
        Next

    End Sub


    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged

    End Sub
End Class
