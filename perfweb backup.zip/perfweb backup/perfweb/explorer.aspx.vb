Imports System.Data.SqlClient
Imports System.Configuration

Partial Class explorer
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Repeater1 As System.Web.UI.WebControls.Repeater
    Protected WithEvents lblStats As System.Web.UI.WebControls.Label
    Protected WithEvents lblError As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Dim run_id As Integer
    Dim rc As Integer

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cookie As New HttpCookie("PerfPage", "explorer")
        cookie.Expires = DateTime.MaxValue
        Response.Cookies.Add(cookie)

        run_id = Convert.ToInt32(Request("rid1"))
        If run_id = 0 Then
            run_id = GetMostRecentRun()
        End If
        rc = Convert.ToInt32(Request("rc"))
        'Dim ctrl As System.Web.UI.Control
        Dim runDisplay As Object = Me.FindControl("RunDetails1")
        If Not runDisplay Is Nothing Then runDisplay.GetRunInfo(run_id)
        Dim ExpCtl As Object = Me.FindControl("ExplorerControl1")
        If Not ExpCtl Is Nothing Then ExpCtl.GetData(run_id, rc)

        'Dim sUrl As String
        'sUrl = "javascript:window.open('http://xws/indiperf/CreateCharts.aspx','Comparison');"
        'lbGenerateReport.Attributes.Add("onclick", sUrl)


    End Sub


    Public Function GetMostRecentRun() As Integer

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String

        myConnection = New SqlConnection(perfConnection)
        myCommand = New SqlCommand("SELECT TOP 1 validity, run_id, run, CONVERT(CHAR(10), start_date, 102) AS run_date FROM runs ORDER BY run_date DESC, validity DESC", myConnection)

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

        Try
            While myReader.Read()
                run_id = Convert.ToInt32(myReader("run_id"))
            End While
        Catch ex As Exception
            run_id = Nothing
        Finally
            myReader.Close()
            myConnection.Close()
        End Try

        Return run_id

    End Function


    Private Function GetRunsForReport()

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr As SqlDataReader

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            Dim sql As String
            sql = "select top 10 r.run_id from runs r "
            sql += "where r.runtype_id in (select runtype_id from runs where run_id=" & run_id.ToString() & ") "
            sql += "and r.labconfig_id in (select labconfig_id from runs where run_id=" & run_id.ToString() & ") "
            sql += "order by r.run_id desc"

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim s As String
            Dim nextRunId As Integer

            While dr.Read()
                nextRunId = Convert.ToInt32(dr("run_id"))
                s += nextRunId.ToString() + ","
            End While

            If (s <> Nothing And s.Length > 0) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

            Session("selruns") = s

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
            run_id = Nothing
        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function


    Private Function GetClientOnlyTestsForReport()

        'get tests using only role_id=1

        Dim selruns As String

        Dim sqlRole1 As String = "SELECT newruns.test_id FROM ( SELECT DISTINCT processes.role_id, jobruns.test_id"
        sqlRole1 += " FROM processes INNER JOIN jobruns ON jobruns.jobrun_id = processes.jobrun_id"
        sqlRole1 += String.Format(" WHERE processes.role_id IN ({0},{1},{2}) AND jobruns.run_id IN ({3}) AND jobruns.test_id IN ({4})", 1, 2, 9, Session("selruns"), Session("SelectedTests"))
        sqlRole1 += " ) AS newruns GROUP BY newruns.test_id HAVING count(*) = 1"

        'txtException.Text = sqlRole1

        Dim clientOnlyTests As String = String.Empty

        Dim dr As SqlDataReader
        Dim command As SqlCommand
        Dim connection As SqlConnection

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            command = New SqlCommand(sqlRole1, connection)

            dr = command.ExecuteReader()

            While dr.Read()
                clientOnlyTests += dr.Item("test_id") & ","
            End While

            If (Not (clientOnlyTests Is Nothing OrElse clientOnlyTests.Length = 0)) And clientOnlyTests.EndsWith(",") Then
                clientOnlyTests = clientOnlyTests.TrimEnd(",")
            End If

            Session("clientOnlyTests") = clientOnlyTests
        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function

    Private Function GetTestsForReport()

        Dim connection As SqlConnection
        Dim command As SqlCommand
        Dim dr As SqlDataReader

        Try
            connection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
            connection.Open()

            Dim sql As String
            sql = "select distinct test_id from jobruns where run_id=" & run_id.ToString()

            command = New SqlCommand(sql, connection)
            command.CommandTimeout = 120

            dr = command.ExecuteReader()

            Dim s As String

            While dr.Read()
                s += dr.Item("test_id") & ","
            End While

            If (Not (s Is Nothing OrElse s.Length = 0)) And s.EndsWith(",") Then
                s = s.TrimEnd(",")
            End If

            Session("SelectedTests") = s

        Catch ex As Exception
            'txtSummaryOutput.Text = "CAUGHT EXCEPTION: " & ex.Message
        Finally
            dr.Close()
            connection.Close()
        End Try

    End Function

    Private Sub lbGenerateReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbGenerateReport.Click
        Dim summary As Boolean = False
        Dim advanced As Boolean = False
        Dim rcMemory As Boolean = False
        Dim indigoLatency As Boolean = False
        Dim rcRefset As Boolean = False

        Response.Redirect("GenerateReport.aspx?&runid=" & run_id.ToString() & "&testid=-1&testname=-1&count=10")

    End Sub
    Private Sub lbGenerateReport20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbGenerateReport20.Click
        Dim summary As Boolean = False
        Dim advanced As Boolean = False
        Dim rcMemory As Boolean = False
        Dim indigoLatency As Boolean = False
        Dim rcRefset As Boolean = False

        summary = False
        advanced = False
        rcMemory = False
        rcRefset = False
        indigoLatency = False

        Response.Redirect("GenerateReport.aspx?&runid=" & run_id.ToString() & "&testid=-1&testname=-1&count=20")

    End Sub
    Private Sub lbGenerateReport30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbGenerateReport30.Click
        Dim summary As Boolean = False
        Dim advanced As Boolean = False
        Dim rcMemory As Boolean = False
        Dim indigoLatency As Boolean = False
        Dim rcRefset As Boolean = False

        summary = False
        advanced = False
        rcMemory = False
        rcRefset = False
        indigoLatency = False

        Response.Redirect("GenerateReport.aspx?&runid=" & run_id.ToString() & "&testid=-1&testname=-1&count=30")

    End Sub

    Private Sub lbAnalyzeRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbAnalyzeRun.Click
        Dim summary As Boolean = False
        Dim advanced As Boolean = False
        Dim rcMemory As Boolean = False
        Dim indigoLatency As Boolean = False
        Dim rcRefset As Boolean = False

        Response.Redirect("AnalyzeRun.aspx?&runid=" & run_id.ToString() & "&testid=-1&testname=-1&count=30")

    End Sub
End Class

