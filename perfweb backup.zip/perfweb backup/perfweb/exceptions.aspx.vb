Imports System.Data.SqlClient
Imports System.Configuration

Partial Class exceptions
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public run_id As Integer
    Public rcID As Integer

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then
            rcID = Request2Int("rc", 1)
            BindData(Request2Int("jrid"))
        End If

    End Sub

    Protected Function Request2Int(ByVal key As String, Optional ByVal DefaultValue As Integer = 0) As Integer

        Try
            Dim Num As Integer = Convert.ToInt32(Request(key))
            If Num = 0 Then
                Return DefaultValue
            Else
                Return Num
            End If
        Catch ex As Exception
            Return DefaultValue
        End Try

    End Function


    Private Sub BindData(ByVal jrid As Integer)

        Dim runDisplay As runDetails = CType(Me.FindControl("RunDetails1"), runDetails)

        Try
            run_id = Convert.ToInt32(Request("rid"))
            runDisplay.GetRunInfo(run_id)
        Catch ex As Exception
            run_id = 0
        End Try

        With Repeater1
            .DataSource = GetDataSource(jrid)
            .DataBind()
        End With

    End Sub

    Public Function GetDataSource(ByVal jobrun_id As Integer) As SqlDataReader

        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        Dim sql As String = String.Format("SELECT note, username, [date], jobrun_id FROM jobrun_notes WHERE (jobrun_id = {0}) ORDER BY [date]", jobrun_id)


        myConnection = New SqlConnection(ConfigurationSettings.AppSettings("PerfConnect"))
        myCommand = New SqlCommand(sql, myConnection)

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

        If Not myReader.HasRows Then
            lblBack.Text = String.Format("<br>No exception notes are available for this job run. <a href='explorer.aspx?rid1={0}'>Return to Data Explorer</a>", run_id)
        End If

        Return myReader

        'Dim sb As New System.Text.StringBuilder
        'sb.Append("<i>")
        'While myReader.Read
        '    sb.Append(String.Format("<img src='images/info2.gif' border='0' alt='{0}'>", myReader(0)))
        '    sb.Append(CType(myReader(0), String).Substring(0, 100))
        '    sb.Append("...<br>")
        'End While

        'sb.Append("</i>")

        'Return sb.ToString

    End Function

End Class
