Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Data
Public Class base
    Inherits System.Web.UI.Page

    Friend perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Protected conLog As String = ConfigurationSettings.AppSettings("conLog")
    Protected csvPath As String = ConfigurationSettings.AppSettings("csvPath")


    Public Function sql2DataReader(ByVal sql As String) As SqlDataReader

        Dim run_id As Integer
        Dim myConnection As SqlConnection
        Dim myCommand As SqlCommand
        Dim myReader As SqlDataReader
        'Dim sql As String

        myConnection = New SqlConnection(perfConnection)
        myCommand = New SqlCommand(sql, myConnection)

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
            Return myReader
        Catch ex As Exception
            myConnection.Close()
            Exit Function
        End Try

    End Function



    Public Class PerfChart

        Private _chartControl As Dundas.Charting.WebControl.Chart
        Private _chartTitle As String
        Private _xTitle As String
        Private _yTitle As String
        Private _xField As String = "variation"
        Private _yField As String = "measured_value"
        Private _size As String
        Private _SecondaryTitle As String
        Private _charttype As String = "Column"
        Private _AxisXMargin As Boolean = False

        Public Property SecondaryTitle() As String
            Get
                Return _SecondaryTitle
            End Get
            Set(ByVal Value As String)
                _SecondaryTitle = Value
            End Set
        End Property

        Public Property size() As String
            Get
                Return _size
            End Get
            Set(ByVal Value As String)
                _size = Value
            End Set
        End Property

        Public Property xFieldName() As String
            Get
                Return _xField
            End Get
            Set(ByVal Value As String)
                _xField = Value
            End Set
        End Property

        Public Property yFieldName() As String
            Get
                Return _yField
            End Get
            Set(ByVal Value As String)
                _yField = Value
            End Set
        End Property

        Public Property AxisXMargin() As Boolean
            Get
                Return _AxisXMargin
            End Get
            Set(ByVal Value As Boolean)
                _AxisXMargin = Value
            End Set
        End Property



        Sub New(ByVal ChartControl As Dundas.Charting.WebControl.Chart, ByVal ChartTitle As String, ByVal xTitle As String, ByVal yTitle As String)
            _chartControl = ChartControl
            _chartTitle = ChartTitle
            _xTitle = xTitle
            _yTitle = yTitle
            _chartControl.Series.Clear()
        End Sub

        Public Function AddSeries(ByVal dr As SqlDataReader, ByVal seriesName As String, ByVal markerStyle As Dundas.Charting.WebControl.MarkerStyle, ByVal LineColor As Color, Optional ByVal chartType As String = "Column")

            _chartControl.Series.Add(seriesName)
            _chartControl.Series(seriesName).ChartType = chartType
            _chartControl.Series(seriesName).Points.DataBindXY(dr, xFieldName, dr, yFieldName)

            _chartControl.Series(seriesName).XValueIndexed = True
            _chartControl.Series(seriesName).MarkerStep = 1
            _chartControl.Series(seriesName).MarkerStyle = markerStyle
            _chartControl.Series(seriesName).MarkerSize = 7
            _chartControl.Series(seriesName).Color = LineColor
            _chartControl.Series(seriesName)("LabelStyle") = "TopRight"



        End Function
        Public Function AddSeriesWithDuplicates(ByVal dr As SqlDataReader, ByVal seriesName As String, ByVal markerStyle As Dundas.Charting.WebControl.MarkerStyle, ByVal LineColor As Color, Optional ByVal chartType As String = "Column")
            'eliminate duplicate data points based on x-axis name
            Dim xlabels As Hashtable = New Hashtable
            Dim x As ArrayList = New ArrayList
            Dim y As ArrayList = New ArrayList
            While (dr.Read())
                If Not xlabels.ContainsKey(dr(xFieldName)) Then
                    xlabels.Add(dr(xFieldName), Nothing)
                    x.Add(dr(xFieldName))
                    y.Add(dr(yFieldName))
                End If
            End While

            _chartControl.Series.Add(seriesName)
            _chartControl.Series(seriesName).ChartType = chartType
            _chartControl.Series(seriesName).Points.DataBindXY(x, y)

            _chartControl.Series(seriesName).XValueIndexed = True
            _chartControl.Series(seriesName).MarkerStep = 1
            _chartControl.Series(seriesName).MarkerStyle = markerStyle
            _chartControl.Series(seriesName).MarkerSize = 7
            _chartControl.Series(seriesName).Color = LineColor
            _chartControl.Series(seriesName)("LabelStyle") = "TopRight"
        End Function
        Public Function AddSeriesDataPointValueLabels(ByVal seriesName As String, ByVal rows As DataRowCollection, ByVal LabelColor As Color, Optional ByVal ShowAsPercentage As Boolean = True)

            Dim point As Dundas.Charting.WebControl.DataPoint
            Dim ht As New Hashtable
            Dim h As Integer
            Dim key As String
            Dim row As DataRow

            For Each row In rows
                'ignore the label if it was already added
                key = row(_xField)
                If Not ht.ContainsKey(key) Then
                    If ShowAsPercentage Then
                        ht.Add(row(_xField), String.Format("{0}% {1}", Math.Round(row(_yField) * 100, 2), ""))
                    Else
                        ht.Add(row(_xField), String.Format("{0}", Math.Round(row(_yField), 2), ""))
                    End If

                End If
            Next

            For Each point In _chartControl.Series(seriesName).Points()
                Dim newLabel As String = CType(ht(point.AxisLabel), String)
                If Not newLabel Is Nothing Then
                    point.Label = newLabel
                    point.FontColor = LabelColor
                    point.Font = New Font("Arial", 7, FontStyle.Regular, GraphicsUnit.Point)
                End If
            Next

        End Function
        Public Function AddSeries(ByVal rows As DataRowCollection, ByVal xField As String, ByVal yField As String, ByVal seriesName As String, ByVal markerStyle As Dundas.Charting.WebControl.MarkerStyle, ByVal LineColor As Color, Optional ByVal chartType As String = "Column")
            _chartControl.Series.Add(seriesName)
            Dim s As Dundas.Charting.WebControl.Series = _chartControl.Series(seriesName)
            With s
                s.ChartType = chartType
                s.Points.DataBindY(rows, yField)
                s.Points.DataBindXY(rows, xField, rows, yField)

                s.XValueIndexed = True
                s.MarkerStep = 1
                s.MarkerStyle = markerStyle
                s.MarkerSize = 7
                s.Color = LineColor
                _chartControl.Series(seriesName)("LabelStyle") = "Right"

                'labels disabled
                s.ShowLabelAsValue = False
                s.YValuesPerPoint = 1
            End With
            Return s
        End Function
        Public Function AddSeries(ByVal rows As DataView, ByVal xField As String, ByVal yField As String, ByVal seriesName As String, ByVal markerStyle As Dundas.Charting.WebControl.MarkerStyle, ByVal LineColor As Color, Optional ByVal chartType As String = "Column")
            _chartControl.Series.Add(seriesName)
            Dim s As Dundas.Charting.WebControl.Series = _chartControl.Series(seriesName)
            With s
                s.ChartType = chartType
                s.Points.DataBindY(rows, yField)
                s.Points.DataBindXY(rows, xField, rows, yField)

                s.XValueIndexed = True
                s.MarkerStep = 1
                s.MarkerStyle = markerStyle
                s.MarkerSize = 7
                s.Color = LineColor
                _chartControl.Series(seriesName)("LabelStyle") = "Top"

                'labels disabled
                s.ShowLabelAsValue = False
                s.YValuesPerPoint = 1
            End With
            Return s
        End Function

        Public Function AddSeries(ByVal dr As SqlDataReader, ByVal dr2 As SqlDataReader, ByVal seriesName As String, ByVal markerStyle As Dundas.Charting.WebControl.MarkerStyle, ByVal LineColor As Color, Optional ByVal chartType As String = "Column")


            _chartControl.Series.Add(seriesName)
            _chartControl.Series(seriesName).ChartType = chartType
            _chartControl.Series(seriesName).Points.DataBindY(dr2, yFieldName)
            _chartControl.Series(seriesName).Points.DataBindXY(dr, xFieldName, dr, yFieldName)
            '_chartControl.Series(seriesName).Points.DataBindXY(dr, xFieldName, dr, n



            _chartControl.Series(seriesName).XValueIndexed = True
            _chartControl.Series(seriesName).MarkerStep = 1
            _chartControl.Series(seriesName).MarkerStyle = markerStyle
            _chartControl.Series(seriesName).MarkerSize = 7
            _chartControl.Series(seriesName).Color = LineColor
            _chartControl.Series(seriesName)("LabelStyle") = "Right"


            _chartControl.Series(seriesName).ShowLabelAsValue = True
            _chartControl.Series(seriesName).YValuesPerPoint = 1


        End Function



        Public Function ShowChart()

            Dim sz() As String = {"90", "100", "75", "50"}

            If Not Me.size Is Nothing Then
                sz = Nothing
                sz = size.Split(",")
            End If

            _chartControl.Titles.Add(_chartTitle)
            _chartControl.Titles(0).Font = New Font("Arial", 10, FontStyle.Regular, GraphicsUnit.Point)
            _chartControl.Titles(0).DockOffset = -2

            If Not Me.SecondaryTitle Is Nothing Then

                _chartControl.Titles.Add(Me.SecondaryTitle)

                _chartControl.Titles(1).Font = New Font("Arial", 8, FontStyle.Regular, GraphicsUnit.Point)
                _chartControl.Titles(1).DockOffset = -6

            End If

            _chartControl.ChartAreas("Default").AxisY.Title = _xTitle
            _chartControl.ChartAreas("Default").AxisX.Title = _yTitle

            '_chartControl.ChartAreas("Default").AxisX.Margin = Me.AxisXMargin
            _chartControl.ChartAreas("Default").AxisX.Interval = 1
            _chartControl.ChartAreas("Default").AxisX.LabelStyle.FontAngle = 30
            _chartControl.ChartAreas("Default").AxisX.LabelStyle.Font = New Font("Arial", 6, FontStyle.Regular, GraphicsUnit.Point)
            _chartControl.ChartAreas("Default").AxisY.LabelStyle.Font = New Font("Arial", 6, FontStyle.Regular, GraphicsUnit.Point)
            _chartControl.ChartAreas("Default").AxisX.LabelsAutoFit = False

            _chartControl.Legends("Default").LegendStyle = Dundas.Charting.WebControl.LegendStyle.Column
            '            _chartControl.Legends("Default").Docking = Dundas.Charting.WebControl.LegendDocking.Bottom
            _chartControl.Legends("Default").Alignment = StringAlignment.Near
            _chartControl.Legends("Default").BorderStyle = Dundas.Charting.WebControl.ChartDashStyle.Solid
            _chartControl.Legends("Default").BorderWidth = 1
            _chartControl.Legends("Default").BorderColor = Color.LightGray
            _chartControl.Legends("Default").BorderStyle = Dundas.Charting.WebControl.ChartDashStyle.Dash
            _chartControl.Legends("Default").Font = New Font("Arial", 6, FontStyle.Regular, GraphicsUnit.Point)

            _chartControl.ChartAreas("Default").Position.Auto = False
            _chartControl.ChartAreas("Default").Position.X = 3
            _chartControl.ChartAreas("Default").Position.Y = 3
            _chartControl.ChartAreas("Default").Position.Width = sz(0)
            _chartControl.ChartAreas("Default").Position.Height = sz(1)

            ' Set the plotting area position. Coordinates of a plotting 
            ' area are relative to a chart area position.
            _chartControl.ChartAreas("Default").InnerPlotPosition.Auto = False
            _chartControl.ChartAreas("Default").InnerPlotPosition.X = 5
            _chartControl.ChartAreas("Default").InnerPlotPosition.Y = 5
            _chartControl.ChartAreas("Default").InnerPlotPosition.Width = sz(2)
            _chartControl.ChartAreas("Default").InnerPlotPosition.Height = sz(3)


            '_chartControl.BorderSkin.SkinStyle = Dundas.Charting.WebControl.BorderSkinStyle.FrameThin


        End Function

    End Class

End Class
