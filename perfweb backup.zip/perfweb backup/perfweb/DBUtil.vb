Imports System.Data.SqlClient
Imports System.Data
' [AML] DBUtil encapsulates standard operations against the Performance database.
' [AML] Only dependence on performance database is via the PerfConnect configuration entry. 
Public Class DBUtil
    Shared perfConnection As String = ConfigurationSettings.AppSettings("PerfConnect")
    Public Shared Sub ExecNonQuery(ByVal Sql As String)
        Dim cn As SqlConnection
        Dim cmd As SqlCommand

        cn = New SqlConnection(perfConnection)
        cmd = New SqlCommand(Sql, cn)

        Try
            cn.Open()
            cmd.ExecuteNonQuery()
        Finally
            cn.Close()
        End Try
    End Sub
    Public Shared Sub ExecNonQuery(ByVal cmd As SqlCommand)
        Dim cn As SqlConnection
        cn = New SqlConnection(perfConnection)
        cmd.Connection = cn

        Try
            cn.Open()
            cmd.ExecuteNonQuery()
        Finally
            cn.Close()
        End Try
    End Sub
    Public Shared Sub ExecDataSet(ByRef ds As DataSet, ByVal Sql As String, ByVal Table As String)
        Dim cn As SqlConnection
        Dim da As SqlDataAdapter
        cn = New SqlConnection(perfConnection)
        Try
            cn.Open()
            da = New SqlDataAdapter(Sql, cn)
            da.Fill(ds, Table)
        Finally
            cn.Close()
        End Try
    End Sub
    Public Shared Sub ExecDataSet(ByRef ds As DataSet, ByVal cmd As SqlCommand, ByVal Table As String)
        Dim cn As SqlConnection
        Dim da As SqlDataAdapter
        cn = New SqlConnection(perfConnection)
        cmd.Connection = cn
        Try
            cn.Open()
            da = New SqlDataAdapter(cmd)
            da.Fill(ds, Table)
        Finally
            cn.Close()
        End Try
    End Sub
End Class
