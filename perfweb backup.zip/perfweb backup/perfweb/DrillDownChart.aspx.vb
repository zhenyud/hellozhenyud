Imports System.Data.SqlClient
Imports System.Collections.Specialized

Partial Class DrillDownChart
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Protected WithEvents LeftNav2 As LeftNav

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        LeftNav2.ShowRunNavigator = False

        '[AML] Get report card, scenario, and comparison ids from cookie
        Dim scenario_id As Integer = Session.Item("scenario_id")
        Dim reportcard_id As Integer = Session.Item("reportcard_id")
        Dim whidbey As Boolean = Session.Item("whidbey")
        Dim comparison_id As Integer = Convert.ToInt32(Request.QueryString("cid"))

        ShowVariationsChart(reportcard_id, scenario_id, comparison_id, whidbey)
    End Sub
    Private Sub ShowVariationsChart(ByVal ReportCardId As Integer, ByVal ScenarioId As Integer, ByVal ComparisonId As Integer, ByVal Whidbey As Boolean)

        'Get tables that will be bound to the chart
        Dim rc As New DataSet

        Dim indigoRuntypeId As Integer
        Dim whidbeyRuntypeId As Integer

        Select Case ReportCardId
            Case 1 ' ReportCard
                indigoRuntypeId = 6
                whidbeyRuntypeId = 26
            Case 10 ' Latency/Startup
                indigoRuntypeId = 6
                whidbeyRuntypeId = 26
            Case 15 ' Refset
                indigoRuntypeId = 6
                whidbeyRuntypeId = 26
            Case 20 ' ReportCard SMP
                indigoRuntypeId = 28
                whidbeyRuntypeId = 31
            Case 101 ' Orcas ReportCard
                indigoRuntypeId = 80
                whidbeyRuntypeId = 84
            Case 111 ' Oslo ReportCard
                indigoRuntypeId = 137
                whidbeyRuntypeId = 140
            Case 103 ' Orcas ReportCard ASR
                indigoRuntypeId = 104
                whidbeyRuntypeId = 82
            Case 130 ' Orcas SP1 ReportCard
                indigoRuntypeId = 145
                whidbeyRuntypeId = 149
            Case 131 ' Orcas SP1 ARS
                indigoRuntypeId = 150
                whidbeyRuntypeId = 153
        End Select

        'Get Indigo data
        Dim myCommand As SqlCommand = New SqlCommand("sproc_w_reportcard_scenario_variations_by_comparison_id")

        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId

            'Indigo is type 6
            .Parameters.Add("@runtype_id", SqlDbType.Int)
            .Parameters(2).Value = indigoRuntypeId

            .Parameters.Add("@comparison_id", SqlDbType.Int)
            .Parameters(3).Value = ComparisonId
        End With
        DBUtil.ExecDataSet(rc, myCommand, "IndigoData")

        'If ScenarioId <> 10 Then
        'Get comparative data
        myCommand = New SqlCommand("sproc_w_reportcard_scenario_variations_by_comparison_id")
        With myCommand
            .CommandType = CommandType.StoredProcedure
            .Parameters.Add("@reportcard_id", SqlDbType.Int)
            .Parameters(0).Value = ReportCardId

            .Parameters.Add("@scenario_id", SqlDbType.Int)
            .Parameters(1).Value = ScenarioId

            'Everett is type 16, Whidbey is 26
            .Parameters.Add("@runtype_id", SqlDbType.Int)
            If Whidbey Then
                .Parameters(2).Value = whidbeyRuntypeId
                If (ReportCardId = 101 Or ReportCardId = 103) Then
                    lblStatus.Text = "Orcas"
                Else
                    lblStatus.Text = "Whidbey"
                End If
            Else
                .Parameters(2).Value = 16
                lblStatus.Text = "Everett"
            End If

            .Parameters.Add("@comparison_id", SqlDbType.Int)
            .Parameters(3).Value = ComparisonId
        End With
        DBUtil.ExecDataSet(rc, myCommand, "ComparativeData")
        'End If


        'Populate chart and format
        Dim varChart As base.PerfChart

        If (ReportCardId = 10) Then
            varChart = New base.PerfChart(VariationsChart, "Latency/Startup Comparison", "Sec", "Test Variation")
        ElseIf (ReportCardId = 15) Then
            varChart = New base.PerfChart(VariationsChart, "Refset Comparison", "MB", "Test Variation")
        Else
            varChart = New base.PerfChart(VariationsChart, "Throughput Comparison", "Operations/Sec", "Test Variation")
        End If

        If (ReportCardId = 15) Then
            varChart.AddSeries(rc.Tables("IndigoData").Rows, "metric", _
               "value", rc.Tables("IndigoData").Rows(0).Item("test") & rc.Tables("IndigoData").Rows(0).Item("variation"), _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")

            varChart.AddSeries(rc.Tables("ComparativeData").Rows, "metric", _
               "value", rc.Tables("ComparativeData").Rows(0).Item("test") & rc.Tables("ComparativeData").Rows(0).Item("variation"), _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "Column")
            'Show whidbey criteria on both whidbey and everett drilldowns
            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
                "whidbey_criteria", "Whidbey Criteria", Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
        Else
            'Dim seriesName As String
            'Dim comparativeSeriesName As String

            'If (whidbeyRuntypeId = 84 Or whidbeyRuntypeId = 82) Then
            '    seriesName = rc.Tables("ComparativeData").Rows(0).Item("test") & "_comp"
            '    'comparativeSeriesName = rc.Tables("ComparativeData").Rows(0).Item("test") & "_comp"
            'Else
            '    seriesName = rc.Tables("IndigoData").Rows(0).Item("test")
            '    'comparativeSeriesName = rc.Tables("ComparativeData").Rows(0).Item("test")
            'End If
            varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
               "value", rc.Tables("IndigoData").Rows(0).Item("test"), _
               Dundas.Charting.WebControl.MarkerStyle.None, Color.Blue, "Column")

            If (ScenarioId = 10 And ReportCardId = 1) Then
                varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
        "whidbey_criteria", "Criteria", Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")

            Else
                varChart.AddSeries(rc.Tables("ComparativeData").Rows, "variation", _
                   "value", rc.Tables("ComparativeData").Rows(0).Item("test") & "_comp", _
                   Dundas.Charting.WebControl.MarkerStyle.None, Color.Green, "Column")
                'Show whidbey criteria on both whidbey and everett drilldowns
                If (ReportCardId = 101 Or ReportCardId = 103 Or ReportCardId = 111 Or ReportCardId = 130 Or ReportCardId = 131) Then
                    varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
    "whidbey_criteria", "Orcas Criteria", Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
                Else
                    varChart.AddSeries(rc.Tables("IndigoData").Rows, "variation", _
                        "whidbey_criteria", "Whidbey Criteria", Dundas.Charting.WebControl.MarkerStyle.None, Color.Red, "Column")
                End If
            End If
        End If

        varChart.ShowChart()
        VariationsChart.Legends("Default").LegendStyle = Dundas.Charting.WebControl.LegendStyle.Table
        VariationsChart.Legends("Default").Docking = Dundas.Charting.WebControl.LegendDocking.Bottom

        'Show table of variations too
        ShowVariationsTable(ReportCardId, rc, ScenarioId)

    End Sub
    Private Sub ShowVariationsTable(ByVal ReportCardId As Integer, ByVal rc As DataSet, ByVal scenarioId As Integer)

        'Fill Table: Columns are variation, test name, value
        Dim rindi As New TableRow
        Dim c As New TableCell
        c.Text = "Variation"
        rindi.Cells.Add(c)
        c = New TableCell
        c.Text = "Test Name"
        rindi.Cells.Add(c)
        c = New TableCell
        c.Text = "Operations/Sec"
        rindi.Cells.Add(c)

        rindi.Font.Bold = True
        rindi.ForeColor = Color.FromArgb(Val("&HCC6600"))
        rindi.BackColor = Color.Beige

        VariationsTable.Rows.Add(rindi)

        'row pointer for comparative data
        Dim i As Integer = 0

        For Each myRow As DataRow In rc.Tables("IndigoData").Rows
            rindi = New TableRow
            Dim rcomp = New TableRow
            Dim rcrit = New TableRow

            Dim variationOrdinalIndigo As String
            Dim testNameIndigo As String
            Dim testNameComp As String

            If (ReportCardId = 15) Then
                variationOrdinalIndigo = myRow.Item("metric").ToString
                testNameIndigo = myRow.Item("variation").ToString
                testNameComp = rc.Tables("ComparativeData").Rows(i).Item("variation").ToString
            Else
                variationOrdinalIndigo = myRow.Item("variation").ToString
                testNameIndigo = myRow.Item("test").ToString
                testNameComp = rc.Tables("ComparativeData").Rows(i).Item("test").ToString
            End If

            c = New TableCell
            c.Text = variationOrdinalIndigo
            rindi.Cells.Add(c)
            c = New TableCell
            c.Text = ""
            rcomp.Cells.Add(c)
            c = New TableCell
            c.Text = ""
            rcrit.Cells.Add(c)

            c = New TableCell
            c.Text = testNameIndigo
            rindi.Cells.Add(c)

            If (scenarioId = 10 And ReportCardId = 1) Then
                'change to using Whidbey for criteria
                c = New TableCell
                c.Text = "Criteria"
                rcrit.Cells.Add(c)
            Else
                c = New TableCell
                c.Text = testNameComp
                rcomp.Cells.Add(c)

                'change to using Whidbey for criteria
                c = New TableCell
                c.Text = "Criteria (Whidbey)"
                rcrit.Cells.Add(c)
            End If

            c = New TableCell
            c.Text = myRow.Item("value").ToString
            rindi.Cells.Add(c)

            'If scenarioId <> 10 Then
            c = New TableCell
            c.Text = rc.Tables("ComparativeData").Rows(i).Item("value").ToString
            rcomp.Cells.Add(c)
            'End If

            'change to using Whidbey for criteria
            c = New TableCell
            c.Text = myRow.Item("whidbey_criteria").ToString
            rcrit.Cells.Add(c)

            'Fill row and increment row pointer for comp data.
            VariationsTable.Rows.Add(rindi)

            'If scenarioId <> 10 Then
            VariationsTable.Rows.Add(rcomp)
            'End If

            VariationsTable.Rows.Add(rcrit)
            i = i + 1
        Next
    End Sub

    Private Sub RemoveExtraDataPoints(ByVal ds As DataSet, ByVal key As String)
        'Removes data points that do not appear in all series
        'assumes that rows are sorted by key
        Dim t1 As DataTable
        Dim t2 As DataTable
        Dim r1 As DataRow
        Dim r2 As DataRow

        Dim keyVal As String
        Dim found As Boolean
        Dim removed As Boolean
        If (ds.Tables.Count > 0) Then
            For Each t1 In ds.Tables
                Dim rows1(t1.Rows.Count - 1) As DataRow
                t1.Rows.CopyTo(rows1, 0)
                For Each r1 In rows1
                    keyVal = r1(key)
                    found = False
                    For Each t2 In ds.Tables
                        If Not (t2.TableName = t1.TableName) Then
                            For Each r2 In t2.Rows
                                If (r2(key) = keyVal) Then
                                    'found current variation in this table
                                    found = True
                                    Exit For
                                ElseIf r2(key) > keyVal Then
                                    'since rows are sorted by key, we can stop when we've passed the key we're looking for
                                    'current variation does not exist in this table, remove it from reference table
                                    t1.Rows.Remove(r1)
                                    removed = True
                                    Exit For
                                End If
                            Next
                            If Not found AndAlso Not removed Then
                                t1.Rows.Remove(r1)
                                removed = True
                            End If
                        End If
                        If (removed) Then
                            'no reason to keep looking for this row in other tables
                            Exit For
                        End If
                    Next
                Next
            Next
        End If
    End Sub
End Class
