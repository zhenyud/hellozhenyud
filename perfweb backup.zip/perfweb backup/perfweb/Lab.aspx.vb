Imports System.Data.SqlClient

Partial Class Lab
    Inherits System.Web.UI.Page


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Dim dr As SqlDataReader
        'Dim command As SqlCommand
        'Dim connection As SqlConnection

        'Dim connectionString As New String("data source=xwsperf-wtt2;database=WTTJobs;user id=Performance;password =Performance")

        'Dim cells As String = "('PerformanceCell02','PerformanceCell03','PerformanceCell04','PerformanceCell05','PerformanceCell06','PerformanceCell07','PerformanceCell08','PerformanceCell09','PerformanceCell10','PerformanceCell11','PerformanceCell12','PerformanceCell13','PerformanceCell14','PerformanceCell15','PerformanceCell16','PerformanceCell17')"

        'Dim sql As String = "select mp.name as pool, m.name as machine, ms.name as status from resource m "
        'sql += "inner join resourcestatus ms on ms.id= m.resourcestatusid "
        'sql += "inner join resourcepool mp on mp.id=m.resourcepoolid "
        'sql += "where mp.name in " & cells
        'sql += "order by mp.name, m.name"

        'connection = New SqlConnection(connectionString)
        'connection.Open()

        'command = New SqlCommand(sql, connection)

        'dr = command.ExecuteReader()

        'DisplayData(dr)

    End Sub

    'Private Sub DisplayData(ByRef dr As SqlDataReader)

    '    Dim pool As String
    '    Dim previousPool As String = ""
    '    Dim machine As String
    '    Dim state As String

    '    Dim hpool As System.Web.UI.WebControls.TableCell
    '    Dim hmachine As System.Web.UI.WebControls.TableCell
    '    Dim hstate As System.Web.UI.WebControls.TableCell

    '    Dim hrow As System.Web.UI.WebControls.TableRow

    '    While dr.Read()

    '        pool = CType(dr.Item("pool"), String)
    '        machine = CType(dr.Item("machine"), String)
    '        state = CType(dr.Item("status"), String)

    '        hpool = New System.Web.UI.WebControls.TableCell

    '        If pool = previousPool Then
    '            pool = ""
    '        End If

    '        hpool.Text = pool
    '        hpool.Font.Bold = True

    '        hmachine = New System.Web.UI.WebControls.TableCell
    '        hmachine.Text = machine

    '        hstate = New System.Web.UI.WebControls.TableCell
    '        hstate.Text = state

    '        Select Case state
    '            Case "Ready"
    '                hstate.BackColor = Color.LightGreen
    '            Case "Running"
    '                hstate.BackColor = Color.LightBlue
    '            Case "Debug"
    '                hstate.BackColor = Color.Pink
    '            Case "Manual"
    '                hstate.BackColor = Color.PaleVioletRed
    '        End Select

    '        hrow = New System.Web.UI.WebControls.TableRow

    '        hrow.Cells.Add(hpool)
    '        hrow.Cells.Add(hmachine)
    '        hrow.Cells.Add(hstate)

    '        tblCellStatus.Rows.Add(hrow)

    '        previousPool = CType(dr.Item("pool"), String)

    '    End While
    'End Sub

End Class
