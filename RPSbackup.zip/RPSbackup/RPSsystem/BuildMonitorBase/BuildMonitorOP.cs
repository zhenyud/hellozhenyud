﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RPSsystem.Utility;

namespace RPSsystem.BuildMonitorBase
{
    public abstract class BuildMonitorOP
    {
        protected RPSconfig rpsConfig = null;
        protected LogUtil logUtil = null;


        public BuildMonitorOP()
        {
            rpsConfig = new RPSconfig();
            logUtil = new LogUtil(rpsConfig.BuildMonitor_logPath);
        }

        public RPSconfig RpsConfig
        {
            get { return rpsConfig; }
        }

        public LogUtil LogUtil
        {
            get { return logUtil; }
        }

        public abstract string getCurrentBuild();

        public abstract DirectoryInfo getNextBuild(string currentBuild, string rootDir);

        public abstract void cacheBuild(DirectoryInfo build, string architect, bool ifZip);

        public abstract bool checkBuildNewer(DirectoryInfo currentBuildDir, DirectoryInfo buildDir);

        public abstract bool checkBuildFinish(DirectoryInfo buildDir);

        public abstract bool checkProductTestChange(DirectoryInfo buildDir, string type);

        public abstract void insertTestJobs(DirectoryInfo build);


        public virtual void refreshConfig()
        {
            rpsConfig.refresh();
        }

        public virtual DirectoryInfo getNextBuild(string currentBuild)
        {
            return getNextBuild(currentBuild, rpsConfig.SNAP_ROOT);
        }

        public virtual void cacheBuild(DirectoryInfo build)
        {
            cacheBuild(build, rpsConfig.Architect, rpsConfig.IfZip);
        }

    }
}
