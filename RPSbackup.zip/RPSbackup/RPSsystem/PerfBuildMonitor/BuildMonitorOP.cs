﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RPSsystem.Utility;

namespace RPSsystem.PerfBuildMonitor
{
    public abstract class BuildMonitorOP
    {
        protected RPSconfig rpsConfig = null; // the configuration
        protected LogUtil logUtil = null; // log functionality


        public BuildMonitorOP()
        {
            rpsConfig = new RPSconfig();
            logUtil = new LogUtil(rpsConfig.BuildMonitor_logPath);
        }

        public RPSconfig RpsConfig
        {
            get { return rpsConfig; }
        }

        public LogUtil LogUtil
        {
            get { return logUtil; }
        }

        /// <summary>
        /// get the last build number that has been cached
        /// </summary>
        /// <returns></returns>
        public abstract string getCurrentBuild();

        /// <summary>
        /// get the next valid build (by filtering out all the ones we don't want)
        /// </summary>
        /// <param name="currentBuild">the build that just finished</param>
        /// <param name="rootDir">the root dir from where we get build, for example, from SNAP</param>
        /// <returns>returns the next build</returns>
        public abstract DirectoryInfo getNextBuild(string currentBuild, string rootDir);

        /// <summary>
        /// cache the build
        /// </summary>
        /// <param name="build">the build to cache</param>
        /// <param name="architect">x86 or x64</param>
        /// <param name="ifZip">need unzip the build or not</param>
        public abstract void cacheBuild(DirectoryInfo build, string architect, bool ifZip);

        /// <summary>
        /// filter the build according to our rules
        /// </summary>
        /// <param name="directoryInfo">the build dir that needs to filter</param>
        /// <param name="currentBuildDir">the last build dir that has been cached</param>
        /// <returns>true if this build should not be filtered out, false otherwise</returns>
        public abstract bool filterBuild(DirectoryInfo directoryInfo, DirectoryInfo currentBuildDir);

        /// <summary>
        /// check if buildDir newer than currentBuildDir
        /// </summary>
        /// <param name="currentBuildDir"></param>
        /// <param name="buildDir"></param>
        /// <returns></returns>
        public abstract bool checkBuildNewer(DirectoryInfo currentBuildDir, DirectoryInfo buildDir);

        /// <summary>
        /// check if this build finished successfully, and return the build root dir for cache
        /// </summary>
        /// <param name="buildDir">the build directory</param>
        /// <returns></returns>
        public abstract bool checkBuildFinish(DirectoryInfo buildDir);

        /// <summary>
        /// check if there is product or test change in the build
        /// </summary>
        /// <param name="buildDir"></param>
        /// <param name="type">produt or test</param>
        /// <returns></returns>
        public abstract bool checkProductTestChange(DirectoryInfo buildDir, string type);

        /// <summary>
        /// insert a test job into for the build database after it is cached
        /// </summary>
        /// <param name="build"></param>
        public abstract void insertTestJobs(DirectoryInfo build);

        /// <summary>
        /// get the newest config from the database
        /// </summary>
        public virtual void refreshConfig()
        {
            rpsConfig.refresh();
        }

        /// <summary>
        /// wrapper method for getNextBuild
        /// </summary>
        /// <param name="currentBuild"></param>
        /// <returns></returns>
        public virtual DirectoryInfo getNextBuild(string currentBuild)
        {
            return getNextBuild(currentBuild, rpsConfig.SNAP_ROOT);
        }

        /// <summary>
        /// wrapper method for cacheBuild.
        /// </summary>
        /// <param name="build"></param>
        public virtual void cacheBuild(DirectoryInfo build)
        {
            cacheBuild(build, rpsConfig.Architect, rpsConfig.IfZip);
        }

        /// <summary>
        /// log functinality, it's using the log method in logutil, write log info into log files
        /// </summary>
        /// <param name="sLogMsg"></param>
        public virtual void Log(string sLogMsg)
        {
            logUtil.Log(sLogMsg);
        }

        /// <summary>
        /// write error information into both .log .err files, and send email 
        /// </summary>
        /// <param name="sErrMsg"></param>
        public virtual void Error(string sErrMsg, string runtype)
        {
            logUtil.Error(sErrMsg, runtype);
        }

    }
}
