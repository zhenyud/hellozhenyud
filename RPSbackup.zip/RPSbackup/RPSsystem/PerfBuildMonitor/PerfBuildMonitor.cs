﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;


namespace RPSsystem.PerfBuildMonitor
{
    public class PerfBuildMonitor
    {

        static void Main(string[] args)
        {
            PerfBuildMonitor buildMonitor = new PerfBuildMonitor();
            buildMonitor.RunBuildMonitor();
        }


        /// <summary>
        /// run the build monitor
        /// </summary>
        public void RunBuildMonitor()
        {
            PerfBuildMonitorOP perfMonitor = new PerfBuildMonitorOP();

            try
            {
                while (true)
                {
                    // refresh the config in the begining of every loop
                    perfMonitor.refreshConfig();

                    //get the current build number from the database
                    string currentBuild = perfMonitor.getCurrentBuild();

                    //get next build
                    DirectoryInfo nextBuild = null;
                    try
                    {
                        nextBuild = perfMonitor.getNextBuild(currentBuild);
                    }
                    catch (IOException ioe)
                    {
                        perfMonitor.Log(ioe.Message);
                        perfMonitor.Log("IO error happenes, sleep a while and re-ry");
                        Thread.Sleep(perfMonitor.RpsConfig.BuildMonitorSleep * perfMonitor.RpsConfig.MinToMiniSecond);
                        continue;
                    }
                    if (nextBuild != null)
                    {
                        Console.WriteLine("The next build for " + currentBuild + "is:  " + nextBuild.Name);
                        perfMonitor.Log("The next build for " + currentBuild + "is:  " + nextBuild.Name);

                        //cached the build
                        perfMonitor.cacheBuild(nextBuild);

                        //insert a test job for this build after it's cached
                        perfMonitor.insertTestJobs(nextBuild);

                        //current build will be set to database in after insert test jobs

                    }
                    else
                    {
                        Console.WriteLine("There is no newer build than: " + currentBuild + "  sleep " + perfMonitor.RpsConfig.BuildMonitorSleep + " minutes and re-try!");
                        perfMonitor.Log("There is no newer build than: " + currentBuild + "  sleep " + perfMonitor.RpsConfig.BuildMonitorSleep + " minutes and re-try!");
                        Thread.Sleep(perfMonitor.RpsConfig.BuildMonitorSleep * perfMonitor.RpsConfig.MinToMiniSecond);

                    }
                }
            }
            catch (ThreadAbortException e2)
            {
                perfMonitor.Log("\nbuild monitor is stopped\n");
            }
            catch (Exception e)
            {
                //log error and send warning email
                perfMonitor.Error("Error happens in BuildMonitor\n" + e.StackTrace, "RPS");
                throw;
            }
            

        }
    }
}
