﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

using RPSsystem.Utility;
using RPSsystem.Utility.FileHandling;
using RPSsystem.Utility.TestRunType;

namespace RPSsystem.PerfBuildMonitor
{
    /// <summary>
    /// the actual class for build monitor operations
    /// </summary>
    public class PerfBuildMonitorOP : BuildMonitorOP
    {
        /// <summary>
        /// get the current build number from database, the current build number is the build that just got cached
        /// </summary>
        /// <returns></returns>
        public override string getCurrentBuild()
        {
            return DBoperation.getCurrentBuild();
        }


        /// <summary>
        /// get the next valid build (by filtering out all the ones we don't want)
        /// </summary>
        /// <param name="currentBuild">the build that just finished</param>
        /// <param name="rootDir">the root dir from where we get build, for example, from SNAP</param>
        /// <returns>returns the next build</returns>
        public override DirectoryInfo getNextBuild(string currentBuild, string rootDir)
        {
            // get all the sub-directoris, i.e, all the builds
            DirectoryInfo[] directoryInfos = new DirectoryInfo(rootDir).GetDirectories();

            // get current build, i.e. the last build that got cached
            DirectoryInfo[] currentDirInfos = new DirectoryInfo(rootDir).GetDirectories(currentBuild);
            if (currentDirInfos.Count() == 0)
            {
                Error("The CURRENT build : " + currentBuild + " doesn't exist!", "RPS"); 
                throw new Exception("The build: " + currentBuild + " doesn't exist!");
            }
            DirectoryInfo currentBuildDir = currentDirInfos[0];

            // filter builds
            List<DirectoryInfo> buildNumbers = new List<DirectoryInfo>();
            foreach (DirectoryInfo directoryInfo in directoryInfos)
            {
                if (filterBuild(directoryInfo, currentBuildDir))
                {
                    buildNumbers.Add(directoryInfo);
                }
            }

            //sort the builds by last modified time and return the next build
            if (buildNumbers.Count != 0)
            {
                buildNumbers.Sort(delegate(DirectoryInfo x, DirectoryInfo y)
                {
                    return x.LastWriteTime.CompareTo(y.LastWriteTime);
                });

                // find the build according to how many builds we want to skip
                if (buildNumbers.Count > rpsConfig.Filter_skipBuild)
                {
                    // return the most recent build if specified
                    if (rpsConfig.Filter_cacheUseLastBuild)
                    {
                        return buildNumbers.Last();
                    }

                    // return the build according to the skip build specification
                    return buildNumbers[rpsConfig.Filter_skipBuild];
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// filter the build according to our rules
        /// </summary>
        /// <param name="directoryInfo">the build dir that needs to filter</param>
        /// <param name="currentBuildDir">the last build dir that has been cached</param>
        /// <returns>true if this build should not be filtered out, false otherwise</returns>
        public override bool filterBuild(DirectoryInfo directoryInfo, DirectoryInfo currentBuildDir)
        {
            bool ifValidBuild = true;
            bool productChangeChecked = false;

            // 1. filter out the older builds than current
            if (ifValidBuild && rpsConfig.Filter_old)
            {
                ifValidBuild = checkBuildNewer(currentBuildDir, directoryInfo);
            }

            // 2. filter out builds in the skip list, disable for now, since cancel run will do it
            /*
            if (ifValidBuild && rpsConfig.Filter_skipList)
            {
                ifValidBuild = checkBuildSkipList(directoryInfo);
            }
             * */

            // 3. filter out unfinished/unsuccessful builds
            if (ifValidBuild && rpsConfig.Filter_unfinish)
            {
                ifValidBuild = checkBuildFinish(directoryInfo);
            }


            // 4. need to check if CLR version is changed, if changed, return true directly without more checks
            if (ifValidBuild && checkCLRversionChange())
            {
                return true;
            }

            // 5. filter out non product/test changes, first filter product change if 
            //    product change is true, skip test change filter, if false, test if test change
            if (ifValidBuild && rpsConfig.Filter_verifyProductChange)
            {
                ifValidBuild = checkProductTestChange(directoryInfo, "product");
                productChangeChecked = true;
            }
            if (rpsConfig.Filter_verifyTestChange)
            {
                if ((ifValidBuild == true && !productChangeChecked) ||
                    (ifValidBuild == false && productChangeChecked))
                {
                    ifValidBuild = checkProductTestChange(directoryInfo, "test");
                }
            }

            return ifValidBuild;
        }

        /// <summary>
        /// cache the build
        /// </summary>
        /// <param name="build">the build to cache</param>
        /// <param name="architect">x86 or x64</param>
        /// <param name="ifZip">need unzip the build or not</param>
        public override void cacheBuild(DirectoryInfo build, string architect, bool ifZip)
        {
            try
            {
                Console.WriteLine("Begin cache build: " + build.Name);
                Log("Begin cache build: " + build.Name);

                CacheManager.cacheBuild(build, architect, ifZip, getJobDir(build), rpsConfig.CACHE_TARGET_ROOT, rpsConfig.PRODUCT_DIR + "\\" + rpsConfig.Flavor, rpsConfig.TEST_DIR, rpsConfig.TEST_SUB_DIR);
            }
            catch (Exception e)
            {
                Error("Error happens when caching the build: \n" + e.StackTrace, "RPS");
                Console.WriteLine("Error happens when caching the build: \n" + e.StackTrace);
                throw;
            }

            Console.WriteLine("Finish cache build: " + build.Name);
            Log("Finish cache build: " + build.Name);
        }



        /// <summary>
        /// check if buildDir newer than currentBuildDir
        /// </summary>
        /// <param name="currentBuildDir"></param>
        /// <param name="buildDir"></param>
        /// <returns></returns>
        public override bool checkBuildNewer(DirectoryInfo currentBuildDir, DirectoryInfo buildDir)
        {
            return buildDir.LastWriteTime > currentBuildDir.LastWriteTime;
        }


        /// <summary>
        /// check if this build finished successfully, and return the build root dir for cache
        /// </summary>
        /// <param name="buildDir">the build directory</param>
        /// <returns></returns>
        public override bool checkBuildFinish(DirectoryInfo buildDir)
        {
            // 1. check if job exist, there may be multiple job exist, we pick the latest one
            DirectoryInfo job = getJobDir(buildDir);
            if (job == null)
            {
                return false;
            }

            // 2. check if the send_summary_mail file exist
            if (!FileDirHandling.checkFileExist(job, rpsConfig.BUILD_SUCCESS_FILE))
            {
                return false;
            }


            // 3. check if the drop dir still exist
            if (!FileDirHandling.checkDirExist(job, rpsConfig.DROP_DIR))
            {
                return false;
            }

            // 4. check the specific flavor exist
            if (!FileDirHandling.checkDirExist(job.FullName + "\\" + rpsConfig.PRODUCT_DIR + "\\" + rpsConfig.Flavor))
            {
                return false;
            }

            return true;
        }



        /// <summary>
        /// check if there is product or test change in the build
        /// </summary>
        /// <param name="buildDir"></param>
        /// <param name="type">produt or test</param>
        /// <returns>return true if there is change</returns>
        public override bool checkProductTestChange(DirectoryInfo buildDir, string type)
        {
            // first check if job dir exist
            DirectoryInfo job = getJobDir(buildDir);
            if (job == null)
            {
                return false;
            }

            FileInfo[] files = job.GetFiles(rpsConfig.BUILD_CHANGE_FILE);
            if (files.Count() < 1)
            {
                return false;
            }

            // get the check in change list file
            FileInfo buildChangeFile = files.First();
            using (FileStream fstream = new FileStream(buildChangeFile.FullName, FileMode.Open, FileAccess.Read))
            using (StreamReader streamReader = new StreamReader(fstream))
            {
                string s = streamReader.ReadToEnd();

                // detect if there is product change
                if (type.Equals("product"))
                {
                    for (int i = 0; i < rpsConfig.Product_change_dirs.Count; i++)
                    {
                        if (s.Contains(rpsConfig.Product_change_dirs[i]))
                        {
                            streamReader.Close();
                            fstream.Close();
                            return true;
                        }
                    }
                }


                // detect if there is test change
                if (type.Equals("test"))
                {
                    for (int i = 0; i < rpsConfig.Test_change_dirs.Count; i++)
                    {
                        if (s.Contains(rpsConfig.Test_change_dirs[i]))
                        {
                            streamReader.Close();
                            fstream.Close();
                            return true;
                        }
                    }
                }

                streamReader.Close();
                fstream.Close();
            }

            return false;
        }


        /// <summary>
        /// insert a test job into database after a build is cached
        /// </summary>
        /// <param name="build"></param>
        public override void insertTestJobs(DirectoryInfo build)
        {
            Console.WriteLine();
            Console.WriteLine("Insert test run for " + build.Name + " .....");
            Log("Insert test run for " + build.Name + " .....");
            Thread.Sleep(1000);

            //get changelist id
            string changeList = getChangeList(build);

            TestRun testRun = new TestRun(0, "cdf40_rps", build.Name, rpsConfig.NormalPri, 0, 0, "pending", DateTime.Now, changeList);
            DBoperation.insertTestRun(testRun);

            Console.WriteLine("Insert test run for " + build.Name + " succeed!");

            // set the current build in database after inserting test jobs
            SqlConnection connection = DBoperation.connectTodatabase();
            DBoperation.setCurrentBuild(build.Name);

            connection.Close();
        }



        /// <summary>
        /// get the change list number for the checkin, if multiple checkin, separate by comma
        /// </summary>
        /// <param name="build"></param>
        /// <returns></returns>
        public string getChangeList(DirectoryInfo build)
        {
            string changeList = string.Empty;
            DirectoryInfo job = getJobDir(build);
            FileInfo[] files = job.GetFiles(rpsConfig.BUILD_CHANGE_FILE);
            FileInfo buildChangeFile = files.First();
            using (FileStream fstream = new FileStream(buildChangeFile.FullName, FileMode.Open, FileAccess.Read))
            using (StreamReader streamReader = new StreamReader(fstream))
            {
                string s = streamReader.ReadToEnd();

                // detect the changeset number
                MatchCollection m = Regex.Matches(s, rpsConfig.ChangeSetRegx);
                if (m != null & m.Count > 0)
                {
                    foreach (Match m1 in m)
                    {
                        changeList += m1.Groups[1].Value.ToString() + ",";
                    }
                    if (changeList != null && !changeList.Equals(string.Empty) && changeList.Length > 0)
                    {
                        changeList = changeList.Trim(',');
                    }
                }

                streamReader.Close();
                fstream.Close();
            }


            return changeList;
        }



        /// <summary>
        /// return the job directory for a build, there may be multiple job exist, we pick the latest one, return null if none is found
        /// </summary>
        /// <param name="buildDir"></param>
        /// <returns></returns>
        public DirectoryInfo getJobDir(DirectoryInfo buildDir)
        {
            DirectoryInfo[] jobs = buildDir.GetDirectories(rpsConfig.JOB_PATTERN);
            DirectoryInfo job = null;
            if (jobs.Count() != 0)
            {
                //find the latest one
                Array.Sort(jobs, delegate(DirectoryInfo x, DirectoryInfo y)
                {
                    return y.LastWriteTime.CompareTo(x.LastWriteTime);
                });
                job = jobs[0];
                return job;
            }

            return null;
        }

        /// <summary>
        /// check if the CLR version changed, if changed, set the new CLR version in database, and return true
        /// </summary>
        /// <returns></returns>
        public bool checkCLRversionChange()
        {
            CheckCLR myCheckCLR = new CheckCLR();
            string currentVersion = myCheckCLR.getCurrentCLR();
            if (myCheckCLR.comparePreCurr("CLRversion", currentVersion) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
            
        }
    }
}
