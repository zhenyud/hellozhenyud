﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using RPSsystem.Utility;
using RPSsystem.Utility.TestRunType;

namespace RPSsystem.PerfTestScheduler
{
    public abstract class TestSchedulerOP
    {
        //protected RPSconfig rpsConfig = null; // the configuration
        //protected LogUtil logUtil = null; // log functionality

        protected DateTime startTime = DateTime.Now; // stores the start time for every test run, will be reset when a test is scheduled, can't be used to detect if a test run is hang


        public TestSchedulerOP()
        {
            //rpsConfig = new RPSconfig();
            //logUtil = new LogUtil(rpsConfig.TestScheduler_logPath);
        }

        /*
        public RPSconfig RpsConfig
        {
            get { return rpsConfig; }
        }
        

        public LogUtil LogUtil
        {
            get { return logUtil; }
        }
         * */


        /// <summary>
        /// get the next job run from the database, according to our priority rules
        /// </summary>
        /// <returns>the next test run</returns>
        public abstract TestRun getNextRun();

        /// <summary>
        /// check if there is still test running, and if a test running too long, send warning email
        /// </summary>
        /// <param name="connection"></param>
        /// <returns>true if there is test running</returns>
        public abstract bool checkRunning(SqlConnection connection);

        /// <summary>
        /// get the next pending run according to our priority and skipping rules
        /// </summary>
        /// <param name="connection"></param>
        /// <returns>the next pending run after filtered out by rules</returns>
        public abstract TestRun getNextPendingRun(SqlConnection connection);

        /// <summary>
        /// copy the tplan for the build to the specific machine, usually the machine that run the test
        /// </summary>
        /// <param name="testRun"></param>
        public abstract void copyTest(TestRun testRun);

        /// <summary>
        /// schedule the test run, and set approriate database fields after scheduling
        /// </summary>
        /// <param name="testRun"></param>
        public abstract void scheduleTest(TestRun testRun);

        /// <summary>
        /// get the newest config from the database
        /// </summary>
        public abstract void refreshConfig();
        /*
        {
            rpsConfig.refresh();
        }
         * */

        /// <summary>
        /// log functinality, it's using the log method in logutil, write log info into log files
        /// </summary>
        /// <param name="sLogMsg"></param>
        public abstract void Log(string sLogMsg);
        /*
        {
            logUtil.Log(sLogMsg);
        }
         * */

        /// <summary>
        /// write error information into both .log .err files, and send email 
        /// </summary>
        /// <param name="sErrMsg"></param>
        public abstract void Error(string sErrMsg);
        /*
        {
            logUtil.Error(sErrMsg);
        }
         * */
    }
}
