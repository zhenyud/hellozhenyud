﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


using RPSsystem.Utility;
using RPSsystem.Utility.TestRunType;


namespace RPSsystem.PerfTestScheduler
{
    public class PerfTestScheduler
    {
        static void Main(string[] args)
        {
            PerfTestScheduler testScheduler = new PerfTestScheduler();
            testScheduler.runTestScheduler();
        }


        public void runTestScheduler()
        {
            TestSchedulerOP perfScheduler = new PerfTestSchedulerOP();

            try
            {
                while (true)
                {
                    // refresh the config in the begining of every loop
                    perfScheduler.refreshConfig();

                    //get the next run to schedule test
                    TestRun nextRun = perfScheduler.getNextRun();

                    //copy the tplan from the build to indigo-perf-cc
                    perfScheduler.copyTest(nextRun);

                    //schedule the test
                    perfScheduler.scheduleTest(nextRun);
                }
            }
            catch (ThreadAbortException e2)
            {
                perfScheduler.Log("\ntest scheduler is stopped\n");
            }
            catch (Exception e)
            {
                perfScheduler.Error("Error happens in Test Scheduler!\n" + e.StackTrace);
                throw;
            }
        }
    }
}
