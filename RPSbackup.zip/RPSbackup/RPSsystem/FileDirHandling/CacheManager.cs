﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;
using System.Runtime.CompilerServices;

namespace RPSsystem
{
    public static class CacheManager
    {

        private const string SemaphoreCacheCopy = "CacheManager.Cache.copy";
        private const string SemaphoreCacheDone = "CacheManager.Cache.done";
        private const int CACHE_TRIES = 2; //the max number of cache tries for one build
        //private const string PRODUCT_DIR = "drop\\bld\\checked";
        //private const string TEST_DIR = "drop\\src\\ddsuites\\src\\cdf\\Perf40\\Current\\Test";
        //private const string TEST_SUB_DIR = "Test";



        /* deprecate function
        /// <summary>
        /// copy the build to the file server, this is the thread safe version using mutex
        /// </summary>
        /// <param name="buildNumber"></param>
        public static void cacheBuild(DirectoryInfo build, DirectoryInfo job, string cacheTargetRoot)
        {
            string targetDir = cacheTargetRoot + "\\" + build.Name;
            int maxCacheTries = CACHE_TRIES;
            string copySemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", targetDir, SemaphoreCacheCopy);
            string doneSemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", targetDir, SemaphoreCacheDone);
            string mutexName = copySemaphore.Replace('\\', '_').ToUpperInvariant();
            Mutex mutex = null;

            // make sure doneSemaphore does not exists before we continue on
            while (!File.Exists(doneSemaphore))
            {
                // mark try block as CER
                RuntimeHelpers.PrepareConstrainedRegions();
                try
                {
                    // if the caching lock owner, cache build
                    if (CacheLock(mutexName, ref mutex))
                    {
                        // create target dir if not exist
                        if (!Directory.Exists(targetDir))
                        {
                            Directory.CreateDirectory(targetDir);
                        }

                        while (!File.Exists(doneSemaphore))
                        {
                            try
                            {
                                // create copy semaphore on target drop
                                if (!File.Exists(copySemaphore))
                                {
                                    using (FileStream fstream = new FileStream(copySemaphore, FileMode.CreateNew))
                                    using (StreamWriter streamWriter = new StreamWriter(fstream))
                                    {
                                        //streamWriter.Write("CREATOR={0}", build.Name);
                                        streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                    }
                                }

                                // do the cache
                                Console.WriteLine("Starting cache.");
                                
                                // copy product
                                FileDirHandling.Copy(job.FullName + "\\" + PRODUCT_DIR, targetDir);

                                // copy test
                                FileDirHandling.Copy(job.FullName + "\\" + TEST_DIR, targetDir + "\\" + TEST_SUB_DIR);

                                Console.WriteLine("Cache finished.");

                                // create done semaphore on target drop
                                using (FileStream fstream = new FileStream(doneSemaphore, FileMode.CreateNew))
                                using (StreamWriter streamWriter = new StreamWriter(fstream))
                                {
                                    //streamWriter.Write("CREATOR={0}", build.Name); // can put create owner here
                                    streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                }

                                break;
                            }
                            catch (IOException ioException)
                            {
                                // handle exceptions during copy process
                                Console.WriteLine(ioException.ToString());

                                // if copy is not finished
                                if (File.Exists(copySemaphore) && !File.Exists(doneSemaphore))
                                {
                                    // try cache again
                                    if (maxCacheTries > 0)
                                    {
                                        Console.WriteLine("Done semaphore doesn't exist. Deleting Copy semaphore and retrying cache.");
                                        File.Delete(copySemaphore);
                                        maxCacheTries--;
                                        continue;
                                    }
                                }

                                throw;
                            }
                        }
                    }
                }
                finally
                {
                    // make sure we release the mutex
                    if (mutex != null)
                    {
                        mutex.ReleaseMutex();
                        mutex.Close();
                        mutex = null;
                        Console.WriteLine("Released mutex '{0}'.", mutexName);
                    }
                }
            }
        }

        */


        /// <summary>
        /// cache build
        /// </summary>
        /// <param name="build">the build dir</param>
        /// <param name="job">the valid job directory under the build dir</param>
        /// <param name="productSrc_subDir">the product subdir</param>
        /// <param name="testSrc_subDir">the test subdir</param>
        /// <param name="testTarget_subDir">the test subdir in the cache target</param>
        /// <param name="cacheTargetRoot">the root dir for the target</param>
        public static void cacheBuild(DirectoryInfo build, DirectoryInfo job, string cacheTargetRoot, string productSrc_subDir, string testSrc_subDir, string testTarget_subDir)
        {
            string targetDir = cacheTargetRoot + "\\" + build.Name;
            int maxCacheTries = CACHE_TRIES;
            string copySemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", targetDir, SemaphoreCacheCopy);
            string doneSemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", targetDir, SemaphoreCacheDone);
            string mutexName = copySemaphore.Replace('\\', '_').ToUpperInvariant();
            Mutex mutex = null;

            // make sure doneSemaphore does not exists before we continue on
            while (!File.Exists(doneSemaphore))
            {
                // mark try block as CER
                RuntimeHelpers.PrepareConstrainedRegions();
                try
                {
                    // if the caching lock owner, cache build
                    if (CacheLock(mutexName, ref mutex))
                    {
                        // create target dir if not exist
                        if (!Directory.Exists(targetDir))
                        {
                            Directory.CreateDirectory(targetDir);
                        }

                        while (!File.Exists(doneSemaphore))
                        {
                            try
                            {
                                // create copy semaphore on target drop
                                if (!File.Exists(copySemaphore))
                                {
                                    using (FileStream fstream = new FileStream(copySemaphore, FileMode.CreateNew))
                                    using (StreamWriter streamWriter = new StreamWriter(fstream))
                                    {
                                        //streamWriter.Write("CREATOR={0}", build.Name);
                                        streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                    }
                                }

                                // do the cache
                                Console.WriteLine("Starting cache.");

                                // copy product
                                FileDirHandling.Copy(job.FullName + "\\" + productSrc_subDir, targetDir);

                                // copy test  disable for now
                                //FileDirHandling.Copy(job.FullName + "\\" + testSrc_subDir, targetDir + "\\" + testTarget_subDir);

                                Console.WriteLine("Cache finished.");

                                // create done semaphore on target drop
                                using (FileStream fstream = new FileStream(doneSemaphore, FileMode.CreateNew))
                                using (StreamWriter streamWriter = new StreamWriter(fstream))
                                {
                                    //streamWriter.Write("CREATOR={0}", build.Name); // can put create owner here
                                    streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                }

                                break;
                            }
                            catch (IOException ioException)
                            {
                                // handle exceptions during copy process
                                Console.WriteLine(ioException.ToString());

                                // if copy is not finished
                                if (File.Exists(copySemaphore) && !File.Exists(doneSemaphore))
                                {
                                    // try cache again
                                    if (maxCacheTries > 0)
                                    {
                                        Console.WriteLine("Done semaphore doesn't exist. Deleting Copy semaphore and retrying cache.");
                                        File.Delete(copySemaphore);
                                        maxCacheTries--;
                                        continue;
                                    }
                                }

                                throw;
                            }
                        }
                    }
                }
                finally
                {
                    // make sure we release the mutex
                    if (mutex != null)
                    {
                        mutex.ReleaseMutex();
                        mutex.Close();
                        mutex = null;
                        Console.WriteLine("Released mutex '{0}'.", mutexName);
                    }
                }
            }
        }



        /* deprecate function
        public static void copyTest(string buildNumber, string testRoot, string testTargetRoot)
        {
            string sourceDir = testRoot + "\\" + buildNumber + "\\" + TEST_SUB_DIR;
            int maxCacheTries = CACHE_TRIES;
            string copySemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", testTargetRoot, SemaphoreCacheCopy + "." + buildNumber);
            string doneSemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", testTargetRoot, SemaphoreCacheDone + "." + buildNumber);
            string mutexName = copySemaphore.Replace('\\', '_').ToUpperInvariant();
            Mutex mutex = null;

            // make sure doneSemaphore does not exists before we continue on
            while (!File.Exists(doneSemaphore))
            {
                // mark try block as CER
                RuntimeHelpers.PrepareConstrainedRegions();
                try
                {
                    // if the caching lock owner, cache build
                    if (CacheLock(mutexName, ref mutex))
                    {
                        // create target dir if not exist
                        if (!Directory.Exists(testTargetRoot))
                        {
                            Directory.CreateDirectory(testTargetRoot);
                        }

                        while (!File.Exists(doneSemaphore))
                        {
                            try
                            {
                                // create copy semaphore on target drop
                                if (!File.Exists(copySemaphore))
                                {
                                    using (FileStream fstream = new FileStream(copySemaphore, FileMode.CreateNew))
                                    using (StreamWriter streamWriter = new StreamWriter(fstream))
                                    {
                                        //streamWriter.Write("CREATOR={0}", buildNumber);
                                        streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                    }
                                }

                                // do the copy
                                Console.WriteLine("Starting copy.");
                                FileDirHandling.Copy(sourceDir, testTargetRoot);

                                Console.WriteLine("Copy finished.");

                                // create done semaphore on target drop
                                using (FileStream fstream = new FileStream(doneSemaphore, FileMode.CreateNew))
                                using (StreamWriter streamWriter = new StreamWriter(fstream))
                                {
                                    //streamWriter.Write("CREATOR={0}", buildNumber);
                                    streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                }

                                break;
                            }
                            catch (IOException ioException)
                            {
                                // handle exceptions during copy process
                                Console.WriteLine(ioException.ToString());

                                // if copy is not finished
                                if (File.Exists(copySemaphore) && !File.Exists(doneSemaphore))
                                {
                                    // try cache again
                                    if (maxCacheTries > 0)
                                    {
                                        Console.WriteLine("Done semaphore doesn't exist. Deleting Copy semaphore and retrying cache.");
                                        File.Delete(copySemaphore);
                                        maxCacheTries--;
                                        continue;
                                    }
                                }

                                throw;
                            }
                        }
                    }
                }
                finally
                {
                    // make sure we release the mutex
                    if (mutex != null)
                    {
                        mutex.ReleaseMutex();
                        mutex.Close();
                        mutex = null;
                        Console.WriteLine("Released mutex '{0}'.", mutexName);
                    }
                }
            }
        }

        */


        /// <summary>
        /// copy the tplans from the cached build
        /// </summary>
        /// <param name="buildNumber"></param>
        /// <param name="testRoot"></param>
        /// <param name="testTargetRoot"></param>
        /// <param name="testSrc_subDir"></param>
        public static void copyTest(string buildNumber, string testRoot, string testTargetRoot, string testSrc_subDir)
        {
            string sourceDir = testRoot + "\\" + buildNumber + "\\" + testSrc_subDir;
            int maxCacheTries = CACHE_TRIES;
            string copySemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", testTargetRoot, SemaphoreCacheCopy + "." + buildNumber);
            string doneSemaphore = String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", testTargetRoot, SemaphoreCacheDone + "." + buildNumber);
            string mutexName = copySemaphore.Replace('\\', '_').ToUpperInvariant();
            Mutex mutex = null;

            // make sure doneSemaphore does not exists before we continue on
            while (!File.Exists(doneSemaphore))
            {
                // mark try block as CER
                RuntimeHelpers.PrepareConstrainedRegions();
                try
                {
                    // if the caching lock owner, cache build
                    if (CacheLock(mutexName, ref mutex))
                    {
                        // create target dir if not exist
                        if (!Directory.Exists(testTargetRoot))
                        {
                            Directory.CreateDirectory(testTargetRoot);
                        }

                        while (!File.Exists(doneSemaphore))
                        {
                            try
                            {
                                // create copy semaphore on target drop
                                if (!File.Exists(copySemaphore))
                                {
                                    using (FileStream fstream = new FileStream(copySemaphore, FileMode.CreateNew))
                                    using (StreamWriter streamWriter = new StreamWriter(fstream))
                                    {
                                        //streamWriter.Write("CREATOR={0}", buildNumber);
                                        streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                    }
                                }

                                // do the copy
                                Console.WriteLine("Starting copy.");
                                FileDirHandling.Copy(sourceDir, testTargetRoot);

                                Console.WriteLine("Copy finished.");

                                // create done semaphore on target drop
                                using (FileStream fstream = new FileStream(doneSemaphore, FileMode.CreateNew))
                                using (StreamWriter streamWriter = new StreamWriter(fstream))
                                {
                                    //streamWriter.Write("CREATOR={0}", buildNumber);
                                    streamWriter.Write("CREATE_TIME={0}", DateTime.Now.ToString());
                                }

                                break;
                            }
                            catch (IOException ioException)
                            {
                                // handle exceptions during copy process
                                Console.WriteLine(ioException.ToString());

                                // if copy is not finished
                                if (File.Exists(copySemaphore) && !File.Exists(doneSemaphore))
                                {
                                    // try cache again
                                    if (maxCacheTries > 0)
                                    {
                                        Console.WriteLine("Done semaphore doesn't exist. Deleting Copy semaphore and retrying cache.");
                                        File.Delete(copySemaphore);
                                        maxCacheTries--;
                                        continue;
                                    }
                                }

                                throw;
                            }
                        }
                    }
                }
                finally
                {
                    // make sure we release the mutex
                    if (mutex != null)
                    {
                        mutex.ReleaseMutex();
                        mutex.Close();
                        mutex = null;
                        Console.WriteLine("Released mutex '{0}'.", mutexName);
                    }
                }
            }
        }




        /// <summary>
        /// Grabs a Mutex and waits for signal if not the Mutex owner
        /// </summary>
        /// <param name="mutexName">Name of the Mutex to create</param>
        /// <param name="mutex">Mutex to assign</param>
        /// <returns>True if the Mutex owner, otherwise false</returns>
        private static bool CacheLock(string mutexName, ref Mutex mutex)
        {
            bool mutexOwner;
            mutex = new Mutex(true, mutexName, out mutexOwner);

            // wait for mutex to be released if not the mutex owner
            if (!mutexOwner)
            {
                mutex.WaitOne();
                mutex.ReleaseMutex();
                mutex.Close();
                mutex = null;
                return false;
            }

            return true;
        }

    }
}
