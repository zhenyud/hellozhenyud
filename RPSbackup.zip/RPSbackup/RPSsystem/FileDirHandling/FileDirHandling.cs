﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace RPSsystem
{
    public class FileDirHandling
    {
        [Flags]
        public enum FileCopyOptions
        {
            None = 0x00,
            FullSubdirectories = 0x01,
            EmptySubdirectories = 0x02,
            Subdirectories = 0x03,
            Overwrite = 0x04,
            Purge = 0x08,
            Mirror = 0x0F,
            CanRestart = 0x10,
        }


        /// <summary>
        /// check if a file pattern exist in specific directory
        /// </summary>
        /// <param name="dir"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static bool checkFileExist(DirectoryInfo dir, string pattern)
        {
            FileInfo[] files = dir.GetFiles(pattern);
            if (files.Count() == 0)
            {
                return false;
            }

            return true;
        }


        /// <summary>
        /// check if a sub-dir exist in a specific dir
        /// </summary>
        /// <param name="dir"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static bool checkDirExist(DirectoryInfo dir, string pattern)
        {
            DirectoryInfo[] subDirs = dir.GetDirectories(pattern);
            if (subDirs.Count() == 0)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// copy the while directory as mirror
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        /// <param name="file"></param>
        public static void Copy(string source, string target)
        {
            Copy(source, target, "*", FileCopyOptions.Mirror);
        }



        /// <summary>
        /// copy dir 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        /// <param name="file">the pattern of the files to copy over</param>
        /// <param name="copyOptions"></param>
        public static void Copy(string source, string target, string file, FileCopyOptions copyOptions)
        {
            // sanity check
            if (source == null)
            {
                throw new ArgumentNullException(source);
            }

            if (target == null)
            {
                throw new ArgumentNullException(target);
            }

            source = source.TrimEnd('\\');
            target = target.TrimEnd('\\');

            DirectoryInfo sourceDirectory = new DirectoryInfo(source);
            DirectoryInfo targetDirectory = new DirectoryInfo(target);

            CopyInternal(sourceDirectory, targetDirectory, file, copyOptions);
        }


        /// <summary>
        /// copy directory, use this method to do recursively copy
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="targetDirectory"></param>
        /// <param name="copyOptions"></param>
        private static void CopyInternal(
                DirectoryInfo sourceDirectory,
                DirectoryInfo targetDirectory,
                string file,
                FileCopyOptions copyOptions
                )
        {
            FileInfo[] fileInfos = null;

            //check if source dir exist
            if (!sourceDirectory.Exists)
            {
                throw new DirectoryNotFoundException(
                    String.Format(CultureInfo.InvariantCulture, "Directory '{0}' does not exist.", sourceDirectory.FullName)
                    );
            }

            // create target dir if not exist
            if (!targetDirectory.Exists)
            {
                Directory.CreateDirectory(targetDirectory.FullName);
            }


            //copy all the sub-directories
            if ((copyOptions & FileCopyOptions.Subdirectories) > 0)
            {
                foreach (DirectoryInfo directoryInfo in sourceDirectory.GetDirectories())
                {
                    CopyInternal(
                        directoryInfo,
                        new DirectoryInfo(String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", targetDirectory.FullName, directoryInfo.Name)),
                        file,
                        copyOptions
                        );
                }
            }

            if ((copyOptions & FileCopyOptions.Purge) > 0)
            {
                // TODO: implement cleanup on target path
            }

            
            // copy all the files in this directory, and copy this dir also in case of this dir is empty
            fileInfos = sourceDirectory.GetFiles(file);

            if (fileInfos.Length > 0 || (copyOptions & FileCopyOptions.EmptySubdirectories) > 0)
            {
                bool overwrite = (copyOptions & FileCopyOptions.Overwrite) > 0;

                targetDirectory.Refresh();

                // create dir in target
                if (!targetDirectory.Exists)
                {
                    targetDirectory.Create();
                }

                //copy each file, overwrite if specified, skip if identical
                foreach (FileInfo sourceFile in sourceDirectory.GetFiles(file))
                {
                    FileInfo targetFile = new FileInfo(String.Format(CultureInfo.InvariantCulture, "{0}\\{1}", targetDirectory.FullName, sourceFile.Name));
                    if (Identical(sourceFile, targetFile))
                    {
                        continue;
                    }
                    sourceFile.CopyTo(
                        targetFile.FullName,
                        overwrite
                        );
                }
            }
        }



        public static void deleteDir(string dirPath)
        {
            if (Directory.Exists(dirPath))
            {
                DirectoryInfo di = new DirectoryInfo(dirPath);
                deleteDir(di);
            }
        }


        /// <summary>
        /// delete the dir recursively
        /// </summary>
        /// <param name="dirPath"></param>
        public static void deleteDir(DirectoryInfo di)
        {
            foreach (DirectoryInfo dif in di.GetDirectories())
            {
                deleteDir(dif);
            }
 
            foreach (FileInfo fi in di.GetFiles())
            {
                // do this to make sure readonly files got deleted
                fi.Attributes = FileAttributes.Normal;
            }
 
            di.Delete(true);
        }



        /// <summary>
        /// check if 2 files are identical, by time and size
        /// </summary>
        /// <param name="sourceFile"></param>
        /// <param name="targetFile"></param>
        /// <returns></returns>
        public static bool Identical(FileInfo sourceFile, FileInfo targetFile)
        {
            if (sourceFile == null)
            {
                throw new ArgumentNullException("sourceFile");
            }

            if (targetFile == null)
            {
                throw new ArgumentNullException("targetFile");
            }

            if (targetFile.Exists && sourceFile.LastWriteTimeUtc == targetFile.LastWriteTimeUtc && sourceFile.Length == targetFile.Length)
            {
                return true;
            }

            return false;
        }
    
    
    
    
    
    
    }
}
