﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace PrivateRunScheduler
{
    public class PrivateConfig
    {
        //runconfig and labconfig
        private string runConfig = "cell1";
        private string labConfig = "C1-L-S1-X-C3T1";

        //Log file path
        private string privateRun_logPath = "D:\\PrivateRun\\TestSchedulerLog\\";
        private string privateRunWeb_logPath = "D:\\PrivateRun\\WebLog\\";

        // the max time for a test run, default is 240 minutes, it longer than that time, xwspla will be notified
        private int maxRuntime = 60;

        // the password for email account
        private string emailPassword = null;

        private int testSchedulerSleep = 30; // test scheduler will sleep for 30 mins if no new test or a current test is running


        // hardcoded those 2 priorities, since change them in database will easily cause messup
        public const int normalPri = 3;
        public const int rerunPri = 2;

        // hardcoded for 1 minute is how many miniseconds
        private int minToMiniSecond = 60000;


        public PrivateConfig()
        {
            setConfigs();
        }

        /// <summary>
        /// regresh the config from database
        /// </summary>
        public void refresh()
        {
            setConfigs();
        }


        private void setConfigs()
        {
            
        }





        public int NormalPri
        {
            get { return normalPri; }
        }

        public int RerunPri
        {
            get { return rerunPri; }
        }

        public string RunConfig
        {
            get { return runConfig; }
        }

        public string LabConfig
        {
            get { return labConfig; }
        }


        public string PrivateRun_logPath
        {
            get { return privateRun_logPath; }
        }
        

        public string PrivateRunWeb_logPath
        {
            get { return privateRunWeb_logPath; }
        }


        public int MaxRuntime
        {
            get { return maxRuntime; }
        }

        public string EmailPassword
        {
            get { return emailPassword; }
        }

        public int TestSchedulerSleep
        {
            get { return testSchedulerSleep; }
        }

        public int MinToMiniSecond
        {
            get { return minToMiniSecond; }
        }


    }
}
