﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

using RPSsystem.PerfTestScheduler;
using RPSsystem.Utility;
using RPSsystem.Utility.FileHandling;
using RPSsystem.Utility.TestRunType;

namespace PrivateRunScheduler
{
    public class PrivateRunTestScheduler : TestSchedulerOP
    {
        private LogUtil logUtil = null; // log functionality
        private PrivateConfig privateConfig = null; // the configuration

        public PrivateRunTestScheduler() 
        {
            privateConfig = new PrivateConfig();
            logUtil = new LogUtil(privateConfig.PrivateRun_logPath);
        }

        public override void refreshConfig()
        {
            privateConfig.refresh();
        }

        public override void Log(string sLogMsg)
        {
            logUtil.Log(sLogMsg);
        }

        public override void Error(string sErrMsg)
        {
            logUtil.Error(sErrMsg, "Private");
        }

        public override TestRun getNextRun() 
        { 
            bool ifRunning = true;
            bool pendingRunExist = false;
            PrivateTestRun pendingTestrun = null;

            //continue if there is still job running or there is no pending run, keep searching
            while (ifRunning || !pendingRunExist)
            {
                //get the connection to database
                SqlConnection connection = DBoperation.connectTodatabase();

                //if there is still test running, don't get next run
                if (checkRunning(connection))
                {
                    ifRunning = true;
                    Console.WriteLine("Try to schedule next test run, but there is still test running, sleep " + privateConfig.TestSchedulerSleep + " minutes and re-try!");
                    logUtil.Log("Try to schedule next test run, but there is still test running, sleep " + privateConfig.TestSchedulerSleep + " minutes and re-try!");
                    Thread.Sleep(privateConfig.TestSchedulerSleep * privateConfig.MinToMiniSecond);
                }
                else //if there is no test running
                {
                    ifRunning = false;

                    //get the next pending run
                    pendingTestrun = (PrivateTestRun) getNextPendingRun(connection);
                    if (pendingTestrun != null)
                    {
                        pendingRunExist = true;
                    }
                    else  //if there is no pending run
                    {
                        pendingRunExist = false;
                        Console.WriteLine("Try to schedule next test run, but there is no pending run, sleep " + privateConfig.TestSchedulerSleep + " minutes and re-try!");
                        logUtil.Log("Try to schedule next test run, but there is no pending run, sleep " + privateConfig.TestSchedulerSleep + " minutes and re-try!");
                        Thread.Sleep(privateConfig.TestSchedulerSleep * privateConfig.MinToMiniSecond);
                    }
                }

                //close the database connection
                connection.Close();
            }
            // the loop is exited when there is no test running and we found a pending run

            Console.WriteLine("got next pending run build: ");
            logUtil.Log("got next pending run build: ");
            Thread.Sleep(3000);

            return pendingTestrun;
        }


        public override bool checkRunning(SqlConnection connection) 
        {
            String query = "SELECT testrunid FROM Private_testRun where runningstatus = \'running\'";

            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                if (queryResults.Tables[0].Rows.Count == 0)
                {
                    return false;  // no test is running
                }
                else
                {
                    // check if this test running too long
                    TimeSpan ts = DateTime.Now.Subtract(startTime); // the starttime is set when a test is scheduled
                    int mins = ts.Hours * 60 + ts.Minutes;
                    if (mins > privateConfig.MaxRuntime)
                    {
                        EmailHandler.sendTestRunHangEmail(privateConfig.EmailPassword, "Private");

                        //reset the starttime to avoid duplicate emails are sent
                        startTime = DateTime.Now;
                    }

                    return true;
                }
            }
        }


        public override TestRun getNextPendingRun(SqlConnection connection) 
        {
            string query = "SELECT testrunid, testruntype, devAlias, productBinar_before, productBinary_after, testBinary_before, testBinary_after, priority, ifimage, isrerun, runningstatus, createtime " +
                            "FROM Private_testRun " +
                            "WHERE runningstatus = \'pending\' " +
                            "ORDER BY priority, createtime";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    

                        // get the next run
                    PrivateTestRun myTestRun = new PrivateTestRun(Int32.Parse(queryResults.Tables[0].Rows[0]["testrunid"].ToString()), queryResults.Tables[0].Rows[0]["testrunname"].ToString(), 
                                                queryResults.Tables[0].Rows[0]["testruntype"].ToString(), queryResults.Tables[0].Rows[0]["devAlias"].ToString(),
                                                queryResults.Tables[0].Rows[0]["productBinar_before"].ToString(), queryResults.Tables[0].Rows[0]["productBinary_after"].ToString(),
                                                queryResults.Tables[0].Rows[0]["testBinary_before"].ToString(), queryResults.Tables[0].Rows[0]["testBinary_after"].ToString(),
                                                Int32.Parse(queryResults.Tables[0].Rows[0]["priority"].ToString()), Int32.Parse(queryResults.Tables[0].Rows[0]["ifimage"].ToString()),
                                                Int32.Parse(queryResults.Tables[0].Rows[0]["isrerun"].ToString()), queryResults.Tables[0].Rows[0]["runningstatus"].ToString(),
                                                (DateTime)queryResults.Tables[0].Rows[0]["createtime"]);
                    return myTestRun;
                }
                else
                {
                    return null;
                }
            }
        }


        public override void copyTest(TestRun testRun) { }


        public override void scheduleTest(TestRun testRun) 
        {
            PrivateTestRun myTestrun = (PrivateTestRun)testRun;

            Console.WriteLine();
            Console.WriteLine("Scheduling test run: " + myTestrun.TestRunId + " for: " + myTestrun.DevAlias + "    .......");
            logUtil.Log("Scheduling test run: " + myTestrun.TestRunId + " for: " + myTestrun.DevAlias + "    .......");

            //1.copy product binary and test binary to temp folder in xwsperf-wtt2
            FileDirHandling.Copy(myTestrun.ProductBinar_before, "\\\\xwsperf-wtt2\\labshare\\Packages\\PushBin\\bits\\" + myTestrun.TestrunName);

            //2. schecule push binary job for before, !!!!!!how about test binaries
            string scheduleCommand = "D:\\scripts\\push_PrivateRun.cmd " + myTestrun.TestrunName;
            ExecuteCommandSync(scheduleCommand);
            //!!!!!need to create the push_PrivateRun.cmd, and the corresponding WTT job that push binary and set the perfrun name as done

            //3. schedule run test for before, !!!!!!!!!for now, assume the tplan location is specified
            scheduleCommand = "D:\\scripts\\schedule_PrivateRun.cmd " + myTestrun.TestrunName;
            //in d: , create temp dir, copy tplans there, and run from there. PrivateTestRun should have tplans as memeber, 
            ExecuteCommandSync(scheduleCommand);

            //4. schedule push binary job for after


            //5. schedule run test for after


            //6. scheduler pop binary for after











            //set the start time for the test, it will be used to check if the test running too long
            startTime = DateTime.Now;

            //string scheduleCommand = null;
            /*
            //schedule the test run by a scripts, which use performance lab runner
            ExecuteCommandSync(scheduleCommand);

            // set the running status to be running in database, and set startTime
            DBoperation.setTestStatus(connection, testRun.TestRunId, TestRun.RunStatus.running);

            // set the labcell for the test run in database
            DBoperation.setLabcell(connection, testRun.TestRunId, rpsConfig.RunConfig);


            Thread.Sleep(4000);

            Console.WriteLine("Scheduling finished");
            logUtil.Log("Scheduling finished");
             * */
        }




        /// <summary>
        /// Executes a shell command synchronously.!!!!!!!!!!!!!!!!!need to merge with the perftest scheduler
        /// </summary>
        /// <param name="command">string command</param>
        /// <returns>string, as output of the command.</returns>
        public void ExecuteCommandSync(object command)
        {
            try
            {
                // create the ProcessStartInfo using "cmd" as the program to be run,
                // and "/c " as the parameters.
                // Incidentally, /c tells cmd that we want it to execute the command that follows,
                // and then exit.
                System.Diagnostics.ProcessStartInfo procStartInfo =
                    new System.Diagnostics.ProcessStartInfo("cmd", "/c " + command);

                //System.Diagnostics.ProcessStartInfo procStartInfo =
                //new System.Diagnostics.ProcessStartInfo(command, arguments);


                // The following commands are needed to redirect the standard output.
                // This means that it will be redirected to the Process.StandardOutput StreamReader.
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                procStartInfo.CreateNoWindow = true;
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
                Console.WriteLine(result);
                logUtil.Log(result);
            }
            catch (Exception objException)
            {
                // Log the exception
                Error(objException.StackTrace);
                throw objException;
            }
        }

    }
}
