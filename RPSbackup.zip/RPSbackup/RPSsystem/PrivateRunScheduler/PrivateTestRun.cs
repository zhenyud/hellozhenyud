﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RPSsystem.Utility;
using RPSsystem.Utility.TestRunType;

namespace PrivateRunScheduler
{
    public class PrivateTestRun : TestRun
    {
        private int testRunId;
        private string testrunName;
        private string testrunType;
        private string devAlias;
        private string productBinar_before;
        private string productBinary_after;
        private string testBinary_before;
        private string testBinary_after;
        private int priority;
        private int ifimage;
        private int isReRun;
        private string runningStatus;
        private DateTime createTime;

        public PrivateTestRun(
            int testRunId,
            string testrunName,
            string testrunType,
            string devAlias,
            string productBinar_before,
            string productBinary_after,
            string testBinary_before,
            string testBinary_after,
            int priority,
            int ifimage,
            int isReRun,
            string runningStatus,
            DateTime createTime)
        {
            this.testRunId = testRunId;
            this.testrunName = testrunName;
            this.testrunType = testrunType;
            this.devAlias = devAlias;
            this.productBinar_before = productBinar_before;
            this.productBinary_after = productBinary_after;
            this.testBinary_before = testBinary_before;
            this.testBinary_after = testBinary_after;
            this.priority = priority;
            this.ifimage = ifimage;
            this.isReRun = isReRun;
            this.runningStatus = runningStatus;
            this.createTime = createTime;
        }

        public new int TestRunId
        {
            get { return testRunId; }
            set { testRunId = value; }
        }

        public string TestrunName
        {
            get { return testrunName; }
            set { testrunName = value; }
        }

        public new string TestrunType
        {
            get { return testrunType; }
            set { testrunType = value; }
        }

        public string DevAlias
        {
            get { return devAlias; }
            set { devAlias = value; }
        }

        public string ProductBinar_before
        {
            get { return productBinar_before; }
            set { productBinar_before = value; }
        }

        public string ProductBinary_after
        {
            get { return productBinary_after; }
            set { productBinary_after = value; }
        }

        public string TestBinary_before
        {
            get { return testBinary_before; }
            set { testBinary_before = value; }
        }

        public string TestBinary_after
        {
            get { return testBinary_after; }
            set { testBinary_after = value; }
        }

        public new int Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public new int Ifimage
        {
            get { return ifimage; }
            set { ifimage = value; }
        }

        public new int IsReRun
        {
            get { return isReRun; }
            set { isReRun = value; }
        }

        public new string RunningStatus
        {
            get { return runningStatus; }
            set { runningStatus = value; }
        }

        public new DateTime CreateTime
        {
            get { return createTime; }
            set { createTime = value; }
        }

    }
}
