﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RPSsystem
{
    public class BuildElement
    {
        private DirectoryInfo buildInfo = null;
        private string productDir = null; // the directory for product
        private string testDir = null;  // the directory for test

        public BuildElement(DirectoryInfo buildInfo)
        {
            this.buildInfo = buildInfo;
        }


        public DirectoryInfo BuildInfo
        {
            get { return buildInfo; }
            set { BuildInfo = value; }
        }


        public string ProductDir
        {
            get { return productDir; }
            set { productDir = value; }
        }



        public string TestDir
        {
            get { return testDir; }
            set { testDir = value; }
        }
    }
}
