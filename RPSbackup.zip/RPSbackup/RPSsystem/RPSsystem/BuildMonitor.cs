﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;

using RPSsystem.Utility;
using RPSsystem.Utility.FileHandling;

namespace RPSsystem
{
    public class BuildMonitor
    {
        /*
        private const string SNAP_ROOT = "\\\\csddfs\\snap\\SnapLogs\\CDF_Dev10";
        private const string JOB_PATTERN = "Job.*";
        private const string BUILD_SUCCESS_FILE = "Send_Summary_Mail*";
        private const string DROP_DIR = "drop";
        private const string BUILD_CHANGE_FILE = "Send_Checkin_Mail*";

        private const string CACHE_TARGET_ROOT = "\\\\cdffile01\\e$\\Drops\\RPS";

        private const string PRODUCT_DIR = "drop\\bld\\checked";
        private const string TEST_DIR = "drop\\src\\ddsuites\\src\\cdf\\Perf40\\Current\\Test";
        private const string TEST_SUB_DIR = "Test";

         * */
        
          
        private RPSconfig rpsConfig = null;
        private LogUtil logUtil = null;


        public BuildMonitor()
        {
            rpsConfig = new RPSconfig();
            logUtil = new LogUtil(rpsConfig.BuildMonitor_logPath);
        }

        public RPSconfig RpsConfig
        {
            get { return rpsConfig; }
        }

        public LogUtil LogUtil
        {
            get { return logUtil; }
        }


        static void Main(string[] args)
        {

            BuildMonitor myMonitor = new BuildMonitor();

                /*
                Console.WriteLine("Please enter the current build number: ");
                string currentBuild = Console.ReadLine();
                 */
            try{
                //get the current build number from the database

                string currentBuild = myMonitor.getCurrentBuild();

                while (true)
                {
                    // refresh the config in the begining of every loop
                    myMonitor.refreshConfig();

                    DirectoryInfo nextBuild = myMonitor.getNextBuild(currentBuild, myMonitor.RpsConfig.SNAP_ROOT);
                    if (nextBuild != null)
                    {
                        Console.WriteLine("The next build for " + currentBuild + "is:  " + nextBuild.Name);
                        myMonitor.LogUtil.Log("The next build for " + currentBuild + "is:  " + nextBuild.Name);

                        myMonitor.cacheBuild(nextBuild, myMonitor.RpsConfig.Architect, myMonitor.RpsConfig.IfZip);

                        myMonitor.insertTestJobs(nextBuild);

                        currentBuild = nextBuild.Name;

                    }
                    else
                    {
                        Console.WriteLine("There is no newer build than: " + currentBuild + "  sleep " + myMonitor.RpsConfig.TestSchedulerSleep + " minutes and re-try!");
                        myMonitor.LogUtil.Log("There is no newer build than: " + currentBuild + "  sleep " + myMonitor.RpsConfig.TestSchedulerSleep + " minutes and re-try!");
                        Thread.Sleep(myMonitor.RpsConfig.BuildMonitorSleep * myMonitor.RpsConfig.MinToMiniSecond);

                    }
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Thread.Sleep(6000);

                }
            }
            catch (Exception e)
            {
                myMonitor.LogUtil.Error("Error happens in BuildMonitor\n" + e.StackTrace);
                throw;
            }
        }


        public void refreshConfig()
        {
            rpsConfig.refresh();
        }

        public string getCurrentBuild()
        {
            return DBoperation.getCurrentBuild(); 
        }


        public DirectoryInfo getNextBuild(string currentBuild)
        {
            return getNextBuild(currentBuild, rpsConfig.SNAP_ROOT);
        }


        public void cacheBuild(DirectoryInfo build)
        {
            cacheBuild(build, rpsConfig.Architect, rpsConfig.IfZip);
        }



        public void getFilterRules()
        {
        }

        

        /// <summary>
        /// get the next valid build (by filtering out all the ones we don't want)
        /// </summary>
        /// <param name="currentBuild">the build that just finished</param>
        /// <param name="rootDir">the root dir from where we get build, for example, from SNAP</param>
        /// <returns>returns the next build</returns>
        public DirectoryInfo getNextBuild(string currentBuild, string rootDir)
        {
            // get all the sub-directoris
            DirectoryInfo[] directoryInfos = new DirectoryInfo(rootDir).GetDirectories();

            // get current build
            DirectoryInfo[] currentDirInfos = new DirectoryInfo(rootDir).GetDirectories(currentBuild);
            if (currentDirInfos.Count() == 0)
            {
                throw new Exception("The build: " + currentBuild + " doesn't exist!");
            }
            DirectoryInfo currentBuildDir = currentDirInfos[0];

            // filter builds
            List<DirectoryInfo> buildNumbers = new List<DirectoryInfo>();
            foreach (DirectoryInfo directoryInfo in directoryInfos)
            {
                bool ifValidBuild = true;

                // 1. filter out the older builds than current
                if (ifValidBuild && rpsConfig.Filter_old)
                {
                    ifValidBuild = checkBuildNewer(currentBuildDir, directoryInfo);
                }

                // 2. filter out builds in the skip list, disable for now, since cancel run will do it
                /*
                if (ifValidBuild && rpsConfig.Filter_skipList)
                {
                    ifValidBuild = checkBuildSkipList(directoryInfo);
                }
                 * */

                // 3. filter out unfinished/unsuccessful builds
                if (ifValidBuild && rpsConfig.Filter_unfinish){
                    ifValidBuild = checkBuildFinish(directoryInfo);
                }

                // 4. filter out non product/test changes, first filter product change if 
                //    product change is true, skip test change filter, if false, test if test change
                if (ifValidBuild && rpsConfig.Filter_verifyProductChange)
                {
                    ifValidBuild = checkProductTestChange(directoryInfo, "product");
                }
                if (rpsConfig.Filter_verifyTestChange){
                    if ((ifValidBuild == true && !rpsConfig.Filter_verifyProductChange) ||
                        (ifValidBuild == false && rpsConfig.Filter_verifyProductChange))
                    {
                        ifValidBuild = checkProductTestChange(directoryInfo, "test");
                    }
                }
              
                if (ifValidBuild)
                {
                    buildNumbers.Add(directoryInfo);
                }
            }

            //sort the builds by last modified time and return the next build
            if (buildNumbers.Count != 0)
            {
                buildNumbers.Sort(delegate(DirectoryInfo x, DirectoryInfo y)
                {
                    return x.LastWriteTime.CompareTo(y.LastWriteTime);
                });

                // find the build according to how many builds we want to skip
                if (buildNumbers.Count > rpsConfig.Filter_skipBuild)
                {
                    // return the most recent build if specified
                    if (rpsConfig.Filter_cacheUseLastBuild)
                    {
                        return buildNumbers.Last();
                    }

                    // return the build according to the skip build specification
                    return buildNumbers[rpsConfig.Filter_skipBuild];
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }



        public void cacheBuild(DirectoryInfo build, string architect, bool ifZip)
        {
            CacheManager.cacheBuild(build, architect, ifZip, getJobDir(build), rpsConfig.CACHE_TARGET_ROOT, rpsConfig.PRODUCT_DIR + "\\" + rpsConfig.Flavor, rpsConfig.TEST_DIR, rpsConfig.TEST_SUB_DIR);
        }

 
        public void insertTestJobs(DirectoryInfo build)
        {
            Console.WriteLine();
            Console.WriteLine("Insert test run for " + build.Name + " .....");
            Thread.Sleep(3000);



            SqlConnection connection = DBoperation.connectTodatabase();
            String query = "insert into RPS_testRun(buildnumber, priority, isrerun, runningstatus, createtime) values (\'" + build.Name + "\'," + rpsConfig.NormalPri + ", 0, \'pending\', @currTime)";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@currTime";
            param.Value = DateTime.Now;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
           

            Console.WriteLine("Insert test run for " + build.Name + " succeed!");

            // set the current build in database after inserting test jobs
            DBoperation.setCurrentBuild(build.Name);
        }


        /// <summary>
        /// check if buildDir newer than currentBuildDir
        /// </summary>
        /// <param name="currentBuildDir"></param>
        /// <param name="buildDir"></param>
        /// <returns></returns>
        private bool checkBuildNewer(DirectoryInfo currentBuildDir, DirectoryInfo buildDir)
        {
            return buildDir.LastWriteTime > currentBuildDir.LastWriteTime;
        }


        /*
        private bool checkBuildSkipList(DirectoryInfo buildDir)
        {
            bool shouldSkip = rpsConfig.SkipBuildList.Contains(buildDir.Name);
            return !shouldSkip;
        }
         * */


        /// <summary>
        /// check if this build finished successfully, and return the build root dir for cache
        /// </summary>
        /// <param name="buildDir">the build directory</param>
        /// <returns></returns>
        private bool checkBuildFinish(DirectoryInfo buildDir)
        {
            // 1. check if job exist, there may be multiple job exist, we pick the latest one
            DirectoryInfo job = getJobDir(buildDir);
            if (job == null)
            {
                return false;
            }
            
            // 2. check if the send_summary_mail file exist
            if (!FileDirHandling.checkFileExist(job, rpsConfig.BUILD_SUCCESS_FILE))
            {
                return false;
            }


            // 3. check if the drop dir still exist
            if (!FileDirHandling.checkDirExist(job,rpsConfig.DROP_DIR))
            {
                return false;
            }

            // 4. check the specific flavor exist


            return true;
        }

        /// <summary>
        /// return the job directory for a build, there may be multiple job exist, we pick the latest one, return null if none is found
        /// </summary>
        /// <param name="buildDir"></param>
        /// <returns></returns>
        private DirectoryInfo getJobDir(DirectoryInfo buildDir)
        {
            DirectoryInfo[] jobs = buildDir.GetDirectories(rpsConfig.JOB_PATTERN);
            DirectoryInfo job = null;
            if (jobs.Count() != 0)
            {
                Array.Sort(jobs, delegate(DirectoryInfo x, DirectoryInfo y)
                {
                    return y.LastWriteTime.CompareTo(x.LastWriteTime);
                });
                job = jobs[0];
                return job;
            }

            return null;
        }


        /// <summary>
        /// check if there is product change in this build, toBeDone!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        /// </summary>
        /// <param name="buildDir"></param>
        /// <returns></returns>
        private bool checkProductTestChange(DirectoryInfo buildDir, string type)
        {
            // first check if job dir exist
            DirectoryInfo job = getJobDir(buildDir);
            if (job == null)
            {
                return false;
            }

            FileInfo[] files = job.GetFiles(rpsConfig.BUILD_CHANGE_FILE);
            if (files.Count() < 1)
            {
                return false;
            }

            // get the check in change list file
            FileInfo buildChangeFile = files.First();
            using (FileStream fstream = new FileStream(buildChangeFile.FullName, FileMode.Open, FileAccess.Read))
            using (StreamReader streamReader = new StreamReader(fstream))
            {
                string s = streamReader.ReadToEnd();

                // detect if there is product change
                if (type.Equals("product"))
                {
                    for (int i = 0; i < rpsConfig.Product_change_dirs.Count; i++)
                    {
                        if (s.Contains(rpsConfig.Product_change_dirs[i]))
                        {
                            streamReader.Close();
                            fstream.Close();
                            return true;
                        }
                    }
                }


                // detect if there is test change
                if (type.Equals("test"))
                {
                    for (int i = 0; i < rpsConfig.Test_change_dirs.Count; i++)
                    {
                        if (s.Contains(rpsConfig.Test_change_dirs[i]))
                        {
                            streamReader.Close();
                            fstream.Close();
                            return true;
                        }
                    }
                }

                streamReader.Close();
                fstream.Close();
            }

            return false;
        }
    }
}
