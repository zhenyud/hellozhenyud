﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using RPSsystem.Utility;

namespace RPSsystem
{
    public class RPSconfig
    {
        private string snap_root = "\\\\csddfs\\snap\\SnapLogs\\CDF_Dev10";
        private string job_pattern = "Job.*";
        private string build_success_file = "Send_Summary_Mail*";
        private string drop_dir = "drop";
        private string build_change_file = "Send_Checkin_Mail*";

        private string cache_target_root = "\\\\cdffile01\\e$\\Drops\\RPS";

        private string product_dir = "drop\\bld\\checked";
        private string test_dir = "drop\\src\\ddsuites\\src\\cdf\\Perf40\\Current\\Test";
        private string test_sub_dir = "Test";

        private string test_target_root = "D:\\RPS\\CDF40\\test";
        //private string cached_test_root = "\\\\cdffile01\\e$\\Drops\\RPS";
        private string cached_test_root = "\\\\cdffile01\\e$\\Drops\\RPS";

        private string architect = "x86";
        private bool ifZip = true; // if we need to unzip files after cache

        // product change dir
        private List<string> product_change_dirs = new List<string>(); // use list in case there are multiple dirs
        private List<string> test_change_dirs = new List<string>();

        //the filter rules for build monitor
        private bool filter_old = true; // default is true
        //private bool filter_skipList = true; // disable since cancel run will do it
        private bool filter_unfinish = true;  // default is true
        //private bool filter_nonProductTestChange = true;  // default is true
        private bool filter_verifyProductChange = true; // default is true
        private bool filter_verifyTestChange = false; // default is false
        private bool filter_useLastBuild = false;  // default is false
        private int filter_skipBuild = 0; // default is 0

        //the skip rules for test scheduler
        private int skipTest_rule = 0; // default is 0, means don't skip, 1 means skip 1, 2 means skip 2
        private int alwaysUseLastBuild = 1; // default is 1, specify use always pick the latest build to schedul teset

        //the build skip list, disable, the cancel test funtion will do this
        //private List<string> skipBuildList = new List<string>();

        //runconfig and labconfig
        private string runConfig = "cell2";
        private string labConfig = "C2-L-S1-C3T2";

        //Log file path
        private string buildMonitor_logPath = "C:\\buildMonitorLog\\";
        private string testScheduler_logPath = "D:\\testSchedulerLog\\";
        private string rpsWeb_logPath = "D:\\RPSwebLog\\";

        // hardcoded those 2 priorities, since change them in database will easily cause messup
        public const int normalPri = 3;
        public const int rerunPri = 2;

       


        public RPSconfig()
        {
            //product_change_dirs.Add("/ndp/cdf/src/NetFx40");
            //test_change_dirs.Add("/ddsuites/src/cdf/Perf40");

            setConfigs();
        }


        public void refresh()
        {
            setConfigs();
        }


        private void setConfigs()
        {
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT * FROM config";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    snap_root = queryResults.Tables[0].Rows[0]["snap_root"].ToString();
                    job_pattern = queryResults.Tables[0].Rows[0]["job_pattern"].ToString();
                    build_success_file = queryResults.Tables[0].Rows[0]["build_success_file"].ToString();
                    drop_dir = queryResults.Tables[0].Rows[0]["drop_dir"].ToString();
                    build_change_file = queryResults.Tables[0].Rows[0]["build_change_file"].ToString();
                    cache_target_root = queryResults.Tables[0].Rows[0]["cache_target_root"].ToString();
                    product_dir = queryResults.Tables[0].Rows[0]["product_dir"].ToString();
                    test_dir = queryResults.Tables[0].Rows[0]["test_dir"].ToString();
                    test_sub_dir = queryResults.Tables[0].Rows[0]["test_sub_dir"].ToString();
                    test_target_root = queryResults.Tables[0].Rows[0]["test_target_root"].ToString();
                    cached_test_root = cache_target_root;
                    runConfig = queryResults.Tables[0].Rows[0]["runConfig"].ToString();
                    labConfig = queryResults.Tables[0].Rows[0]["labConfig"].ToString();
                    filter_old = (Int32) queryResults.Tables[0].Rows[0]["filter_old"] == 1 ? true : false;
                    //filter_skipList = bool.Parse(queryResults.Tables[0].Rows[0]["filter_skipList"].ToString());
                    filter_unfinish = (Int32)queryResults.Tables[0].Rows[0]["filter_unfinish"] == 1 ? true : false;
                    filter_verifyProductChange = (Int32)queryResults.Tables[0].Rows[0]["filter_verifyProductChange"] == 1 ? true : false;
                    filter_verifyTestChange = (Int32)queryResults.Tables[0].Rows[0]["filter_verifyTestChange"] == 1 ? true : false;
                    filter_useLastBuild = (Int32)queryResults.Tables[0].Rows[0]["filter_useLastBuild"] == 1 ? true : false;
                    filter_skipBuild = Int32.Parse(queryResults.Tables[0].Rows[0]["filter_skipBuild"].ToString());
                    skipTest_rule = Int32.Parse(queryResults.Tables[0].Rows[0]["skipTest_rule"].ToString());
                    buildMonitor_logPath = queryResults.Tables[0].Rows[0]["buildMonitorLogPath"].ToString();
                    testScheduler_logPath = queryResults.Tables[0].Rows[0]["testSchedulerLogPath"].ToString();
                    rpsWeb_logPath = queryResults.Tables[0].Rows[0]["RPSwebsiteLogPath"].ToString();
                    architect = queryResults.Tables[0].Rows[0]["architect"].ToString();
                    ifZip = (Int32)queryResults.Tables[0].Rows[0]["ifZip"] == 1 ? true : false;
             }
            }


            // set for product change path and test change path
            product_change_dirs = new List<string>();
            test_change_dirs = new List<string>(); 

            query = "SELECT * FROM changepaths";
            mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    for (int i = 0; i < resultCount; i++)
                    {
                        if (queryResults.Tables[0].Rows[i]["type"].ToString().Equals("product"))
                        {
                            product_change_dirs.Add(queryResults.Tables[0].Rows[i]["path"].ToString());
                        }
                        if (queryResults.Tables[0].Rows[i]["type"].ToString().Equals("test"))
                        {
                            test_change_dirs.Add(queryResults.Tables[0].Rows[i]["path"].ToString());
                        }
                    }
                }
            }
        }



        public string SNAP_ROOT
        {
            get { return snap_root; }
        }

        public string JOB_PATTERN
        {
            get { return job_pattern; }
        }

        public string BUILD_SUCCESS_FILE
        {
            get { return build_success_file; }
        }

        public string DROP_DIR
        {
            get { return drop_dir; }
        }

        public string BUILD_CHANGE_FILE
        {
            get { return build_change_file; }
        }

        public string CACHE_TARGET_ROOT
        {
            get { return cache_target_root; }
        }

        public string PRODUCT_DIR
        {
            get { return product_dir; }
        }

        public string TEST_DIR
        {
            get { return test_dir; }
        }

        public string TEST_SUB_DIR
        {
            get { return test_sub_dir; }
        }

        public string TEST_TARGET_ROOT
        {
            get { return test_target_root; }
        }

        public string CACHED_TEST_ROOT
        {
            get { return cached_test_root; }
        }

        public List<string> Product_change_dirs
        {
            get { return product_change_dirs; }
        }

        public List<string> Test_change_dirs
        {
            get { return test_change_dirs; }
        }

        public bool Filter_old
        {
            get { return filter_old; }
        }

        public bool Filter_unfinish
        {
            get { return filter_unfinish; }
        }

        public bool Filter_verifyProductChange
        {
            get { return filter_verifyProductChange; }
        }

        public bool Filter_verifyTestChange
        {
            get { return filter_verifyTestChange; }
        }

        public bool Filter_useLastBuild
        {
            get { return filter_useLastBuild; }
        }

        public int Filter_skipBuild
        {
            get { return filter_skipBuild; }
        }

        public int SkipTest_rule
        {
            get { return skipTest_rule; }
        }

        public int AlwaysUseLastBuild
        {
            get { return alwaysUseLastBuild; }
        }

        public int NormalPri
        {
            get { return normalPri; }
        }

        public int RerunPri
        {
            get { return rerunPri; }
        }


        /*
        public List<string> SkipBuildList
        {
            get { return skipBuildList; }
        }
         

        public bool Filter_skipList
        {
            get { return filter_skipList; }
        }
         * */

        public string RunConfig
        {
            get { return runConfig; }
        }
        

        public string LabConfig
        {
            get { return labConfig; }
        }


        public string BuildMonitor_logPath
        {
            get { return buildMonitor_logPath; }
        }

        public string TestScheduler_logPath
        {
            get { return testScheduler_logPath; }
        }

        public string RpsWeb_logPath
        {
            get { return rpsWeb_logPath; }
        }

        public string Architect
        {
            get { return architect; }
        }


        public bool IfZip
        {
            get { return ifZip; }
        }

    }
}
