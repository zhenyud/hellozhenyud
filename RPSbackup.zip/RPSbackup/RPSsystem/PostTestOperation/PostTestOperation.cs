﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Net;

using RPSsystem.Utility;

namespace RPSsystem
{
    class PostTestOperation
    {
        private const string WEB_LINK = "http://xws-perf-cc/RPSweb/RPSpostTestOperation.aspx";

        static void Main(string[] args)
        {
            PostTestOperation myOperation = new PostTestOperation();
            if (args.Count() != 1)
            {
                Console.WriteLine("you must specify one argument: testrunId");
                Environment.Exit(0);
            }

            string testId = args[0];
            myOperation.setTestDoneByWeb(testId);
            myOperation.callRegressionAnalyzer();
        }



        /// <summary>
        /// set the test run status as done
        /// </summary>
        /// <param name="testRunId"></param>
        public void setTestDone(string testRunId)
        {
            SqlConnection connection = DBoperation.connectTodatabase();
            /*
            string connectionString = "data source=xmlab-perfsql;database=RPSperf;user id=rpsperfuser;password=Rps-perf-user";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();*/

            String query = "update RPS_testRun set runningstatus = \'done\', endtime = @currTime where testrunid = @runId";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);

            SqlParameter param1 = new SqlParameter();
            param1.ParameterName = "@currTime";
            param1.Value = DateTime.Now;
            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@runId";
            param2.Value = testRunId;

            mySqlCommand.Parameters.Add(param1);
            mySqlCommand.Parameters.Add(param2);
            mySqlCommand.ExecuteNonQuery();
        }


        /// <summary>
        /// connect to website, the website will perform the task
        /// </summary>
        /// <param name="testRunId"></param>
        public void setTestDoneByWeb(string testRunId)
        {
            //create web client
            WebRequest.DefaultWebProxy = null;
            WebClient web = new WebClient();
            web.Proxy = null;
            Console.WriteLine("Set proxy to nothing.");

            //connect to web site 
            string uriString = WEB_LINK + "?" + "&testrunid=" + testRunId;
            byte[] responseArray = web.DownloadData(uriString);

            string response = Encoding.ASCII.GetString(responseArray);
            string marker = "SUCCESS";
            int startIdx = response.IndexOf(marker);
            if (startIdx == -1)
            {
                throw new ApplicationException("Set test status through website failed!");
            }
            else
            {
                Console.WriteLine("set test status to be done");
            }
        }


        public void callRegressionAnalyzer()
        {
            Console.WriteLine("call the failure & regression analyzer ....");
            
        }
    }
}
