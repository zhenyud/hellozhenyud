﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace RPSsystem.Utility
{
    /// <summary>
    /// utility class for send emails
    /// </summary>
    public class EmailHandler
    {
        public static void sendErrorMail(string emailPassword, string msg, string runtype)
        {
            MailMessage theMailMessage = new MailMessage("indgaunt@microsoft.com", "xwspla@microsoft.com");
            theMailMessage.Body = msg;

            theMailMessage.Subject = "Error Happens in " + runtype + " run, please investigate!";

            SmtpClient theClient = new SmtpClient("smtphost.redmond.corp.microsoft.com");
            theClient.UseDefaultCredentials = false;
            System.Net.NetworkCredential theCredential = new System.Net.NetworkCredential("indgaunt@microsoft.com", emailPassword);
            theClient.Credentials = theCredential;
            theClient.Send(theMailMessage);
        }


        public static void sendTestRunHangEmail(string emailPassword, string runtype)
        {
            MailMessage theMailMessage = new MailMessage("indgaunt@microsoft.com", "xwspla@microsoft.com");
            theMailMessage.Body = "The " + runtype + " run hang there for a long time, please investigate!";
            theMailMessage.Subject = runtype + "-test run hang";

            SmtpClient theClient = new SmtpClient("smtphost.redmond.corp.microsoft.com");
            theClient.UseDefaultCredentials = false;
            System.Net.NetworkCredential theCredential = new System.Net.NetworkCredential("indgaunt@microsoft.com", emailPassword);
            theClient.Credentials = theCredential;
            theClient.Send(theMailMessage);
        }


        public static void sentTooManyPendingEmail(string emailPassword, int pendingRuns, string runtype)
        {
            MailMessage theMailMessage = new MailMessage("indgaunt@microsoft.com", "xwspla@microsoft.com");
            theMailMessage.Body = "The " + runtype + " has " + pendingRuns + " test runs pending, consider to cancel some of them!\n\n";
            string rpsSite = @"http://xws-perf-cc/RPSwebNew/";
            theMailMessage.Body += rpsSite;
            theMailMessage.Subject = runtype + "-too much pending runs";

            SmtpClient theClient = new SmtpClient("smtphost.redmond.corp.microsoft.com");
            theClient.UseDefaultCredentials = false;
            System.Net.NetworkCredential theCredential = new System.Net.NetworkCredential("indgaunt@microsoft.com", emailPassword);
            theClient.Credentials = theCredential;
            theClient.Send(theMailMessage);
        }
    }
}
