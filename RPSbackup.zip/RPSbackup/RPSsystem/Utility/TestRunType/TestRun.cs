﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RPSsystem.Utility.TestRunType
{
    public class TestRun
    {
        private int testRunId;
        private string testrunType;
        private string buildNumber;
        private int priority;
        private int ifimage;
        private int isReRun;
        private string runningStatus;
        private DateTime createTime;
        private string changeList;


        [Flags]
        public enum RunStatus
        {
            pending = 0x01,
            running = 0x02,
            cancelled = 0x03,
            done = 0x04,
            unknown = 0x05,
        }


        public TestRun(
            int testRunId,
            string testrunType,
            string buildNumber,
            int priority,
            int ifimage,
            int isReRun,
            string runningStatus,
            DateTime createTime, 
            string changeList)
        {
            this.testRunId = testRunId;
            this.testrunType = testrunType;
            this.buildNumber = buildNumber;
            this.priority = priority;
            this.ifimage = ifimage;
            this.isReRun = isReRun;
            this.runningStatus = runningStatus;
            this.createTime = createTime;
            this.changeList = changeList;
        }

        public TestRun() { }

        public int TestRunId
        {
            get { return testRunId; }
            set { testRunId = value; }
        }

        public string TestrunType
        {
            get { return testrunType; }
            set { testrunType = value; }
        }

        public string BuildNumber
        {
            get { return buildNumber; }
            set { buildNumber = value; }
        }

        public int Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public int Ifimage
        {
            get { return ifimage; }
            set { ifimage = value; }
        }

        public int IsReRun
        {
            get { return isReRun; }
            set { isReRun = value; }
        }

        public RunStatus RunningStatus
        {
            get 
            {
                RunStatus status = RunStatus.unknown;
                switch (runningStatus)
                {
                    case "pending":
                        status = RunStatus.pending;
                        break;
                    case "running":
                        status = RunStatus.running;
                        break;
                    case "done":
                        status = RunStatus.done;
                        break;
                    case "cancelled":
                        status = RunStatus.cancelled;
                        break;
                    default:
                        status = RunStatus.unknown;
                        break;
                }
                return status; 
            }
        }

        public DateTime CreateTime
        {
            get { return createTime; }
            set { createTime = value; }
        }


        public string ChangeList
        {
            get { return changeList; }
            set { changeList = value; }
        }

    }
}
