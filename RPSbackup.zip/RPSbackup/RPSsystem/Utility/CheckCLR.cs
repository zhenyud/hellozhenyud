﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace RPSsystem.Utility
{
    /// <summary>
    /// utility class for check the CLR version change
    /// </summary>
    public class CheckCLR
    {
        private RPSconfig rpsConfig = null;
        private LogUtil logUtil = null;

        public CheckCLR()
        {
            rpsConfig = new RPSconfig();
            logUtil = new LogUtil(rpsConfig.TestScheduler_logPath);
        }


        /// <summary>
        /// get current version from \\csddfs\public\RemoteStore\dev10\lkg.cmd 
        /// </summary>
        /// <returns>the current CLR version</returns>
        public string getCurrentCLR()
        {
            string currentVersion = string.Empty;
            using (FileStream fstream = new FileStream(rpsConfig.ClrVersionFile, FileMode.Open, FileAccess.Read))
            using (StreamReader streamReader = new StreamReader(fstream))
            {
                string s = streamReader.ReadToEnd();

                // detect the version number
                Match m = Regex.Match(s, rpsConfig.ClrVersionRegx);
                if (m != null)
                {
                    currentVersion = m.Groups[1].Value.ToString().Trim();
                }
                else
                {
                    logUtil.Error("Can't find current CLR version in RemoteStore!", "RPS");
                }

                streamReader.Close();
                fstream.Close();
            }
            return currentVersion;
        }



        /// <summary>
        /// compare previous and current version, and set the version in database
        /// </summary>
        /// <param name="type">CLRversion: the previous CLR version when build is cached, RunCLR: the version when last test is run</param>
        /// <param name="current">current CLR version</param>
        /// <returns></returns>
        public int comparePreCurr(string type, string current)
        {
            string previousVersion = string.Empty;
            int checkChanged = 0;

            //get previous version from database
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT " + type + " FROM RPS_currentvalue";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    previousVersion = queryResults.Tables[0].Rows[0][type].ToString().Trim();
                }
                else
                {
                    logUtil.Error("Can't find previous " + type + " version in database!", "RPS");
                }
            }
            
            //comapre previous and current
            if (!current.Equals(previousVersion))
            {
                checkChanged = 1;

                //set the new version number in database, and return true
                query = "update RPS_currentvalue set " + type + " = \'" + current + "\'";
                mySqlCommand = new SqlCommand(query, connection);
                mySqlCommand.ExecuteNonQuery();
            }

            connection.Close();
            return checkChanged;

        }
    }
}
