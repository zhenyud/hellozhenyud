﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RPSsystem.Utility
{
    /// <summary>
    /// utility class for log
    /// </summary>
    public class LogUtil
    {
        private string sLogFormat; //format of the log
		private string sLogTime; //time of the log
        private string sLogPath; // where to store the log files

		public LogUtil()
		{
		}

        public LogUtil(string path)
        {
            sLogPath = path;
            if (!Directory.Exists(sLogPath))
            {
                Directory.CreateDirectory(sLogPath);
            }
        }


        /// <summary>
        /// write error msg into both .log file and .err file, and send warning email
        /// </summary>
        /// <param name="sPathName"></param>
        /// <param name="sErrMsg"></param>
		public void Error(string sPathName, string sErrMsg, string runtype)
		{
            setUpLogTime(sPathName);

            //write into log file
			StreamWriter sw = new StreamWriter(sPathName+sLogTime+".log",true); // if file exist, new msg will be appended, if not, new file will be created
			sw.WriteLine(sLogFormat + " ERROR: " + sErrMsg);
			sw.Flush();
			sw.Close();

            //also write into err file
            StreamWriter swErr = new StreamWriter(sPathName + sLogTime + ".err", true); // if file exist, new msg will be appended, if not, new file will be created
            swErr.WriteLine(sLogFormat + " ERROR: " + sErrMsg);
            swErr.Flush();
            swErr.Close();

            //send warning email
            RPSconfig config = new RPSconfig();
            EmailHandler.sendErrorMail(config.EmailPassword, sErrMsg, runtype);

		}


        /// <summary>
        /// write into log files
        /// </summary>
        /// <param name="sPathName"></param>
        /// <param name="sLogMsg"></param>
        public void Log(string sPathName, string sLogMsg)
        {
            setUpLogTime(sPathName);

            StreamWriter sw = new StreamWriter(sPathName+sLogTime+".log", true); // if file exist, new msg will be appended, if not, new file will be created
            sw.WriteLine(sLogFormat + sLogMsg);
            sw.Flush();
            sw.Close();
        }


        /// <summary>
        /// wrapper method
        /// </summary>
        /// <param name="sErrMsg"></param>
        public void Error(string sErrMsg,string runtype)
        {
            Error(sLogPath, sErrMsg, runtype);
        }


        /// <summary>
        /// wrapper method
        /// </summary>
        /// <param name="sLogMsg"></param>
        public void Log(string sLogMsg)
        {
            Log(sLogPath, sLogMsg);
        }



        /// <summary>
        /// set up the time when writing log
        /// </summary>
        /// <param name="path"></param>
        private void setUpLogTime(string path)
        {
            //sLogFormat used to create log files format :
            // dd/mm/yyyy hh:mm:ss AM/PM ==> Log Message
            sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";

            //this variable used to create log filename format "
            //for example filename : ErrorLogYYYYMMDD
            //string sYear = DateTime.Now.Year.ToString();
            //string sMonth = DateTime.Now.Month.ToString();           
            //string sDay = DateTime.Now.Day.ToString();

            string sYear = String.Format("{0:yyyy}", DateTime.Now);
            string sMonth = String.Format("{0:MM}", DateTime.Now);
            string sDay = String.Format("{0:dd}", DateTime.Now);
            sLogTime = sYear + sMonth + sDay;
        }
    }
}
