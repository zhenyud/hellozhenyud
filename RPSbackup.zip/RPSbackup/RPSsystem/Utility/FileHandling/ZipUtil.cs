﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ICSharpCode.SharpZipLib.Zip;


namespace RPSsystem.Utility.FileHandling
{
    /// <summary>
    /// it's the utility class to zip and unzip files
    /// </summary>
    public class ZipUtil
    {
        /// <summary>
        /// unzip to target directory, maintain the sub-directory structures
        /// </summary>
        /// <param name="zipFile"></param>
        /// <param name="targetDirectory"></param>
        public static void unzip(string zipFile, string targetDirectory)
        {
            FastZip fz = new FastZip();
            fz.ExtractZip(zipFile, targetDirectory, "");
        }


        /// <summary>
        /// unzip the zip files listed in zipListFile, every line is [zipFile]|[targetDir], this is specific for Dev10 SNAP
        /// </summary>
        /// <param name="zipListFile"></param>
        /// <param name="directory">the directory contains the source file</param>
        public static void unzipZipList(string zipListFile, string directory)
        {
            StreamReader SR;
            string line;
            SR=File.OpenText(directory + "\\" + zipListFile);

            //read in each line, every line lists a zip file and it's target dir
            line=SR.ReadLine();
            while(line!=null)
            {
                string[] oneLine = line.Split('|');
                if (oneLine[1].StartsWith("*")) //just unzip to the directory
                {
                    unzip(directory + "\\" + oneLine[0], directory);
                }
                else // unzip to the specified directory
                {
                    unzip(directory + "\\" + oneLine[0], directory + "\\" + oneLine[1]);
                }
                line = SR.ReadLine();
            }
            SR.Close();
        }
       
    }
}
