﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;

using RPSsystem.Utility.TestRunType;


namespace RPSsystem.Utility
{
    /// <summary>
    /// utility class for database related operations
    /// </summary>
    public class DBoperation
    {

        
        /// <summary>
        /// open the database connection
        /// </summary>
        /// <param name="dbHost"></param>
        /// <param name="dbName"></param>
        /// <param name="dbUser"></param>
        /// <param name="dbPassword"></param>
        /// <returns></returns>
        public static SqlConnection connectTodatabase(string dbHost, string dbName, string dbUser, string dbPassword)
        {
            string SAConnectStr = String.Format(
                   "UID={0};PWD={1};SERVER={2};Database={3}",
                   dbUser,
                   dbPassword,
                   dbHost,
                   dbName
                   );
            SqlConnection connection = new SqlConnection(SAConnectStr);
            connection.Open();
            return connection;
        }



        /// <summary>
        /// open the database connection to xmlab-perfsql
        /// </summary>
        /// <returns></returns>
        public static SqlConnection connectTodatabase()
        {
            //return connectTodatabase("xmlab-perfsql", "RPSperf", "rpsperfuser", "Rps-perf-user");
            return connectTodatabase("xmlab-perfsql", "PerfV3", "Performance", "Performance");

        }



        /// <summary>
        /// set the test run status for a test run
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="testRunId"></param>
        /// <param name="status">the test run status you want to set to</param>
        public static void setTestStatus(SqlConnection connection, int testRunId, TestRun.RunStatus status)
        {
            String query = null;

            //set the status
            switch (status)
            {
                case TestRun.RunStatus.running:
                    query = "update RPS_testRun set runningstatus = \'running\', starttime = @currTime where testrunid = @runId";
                    break;
                case TestRun.RunStatus.cancelled:
                    query = "update RPS_testRun set runningstatus = \'cancelled\' where testrunid = @runId";
                    break;
                case TestRun.RunStatus.done:
                    query = "update RPS_testRun set runningstatus = \'done\', endtime = @currTime where testrunid = @runId";
                    break;
                case TestRun.RunStatus.pending:
                    query = "update RPS_testRun set runningstatus = \'pending\' where testrunid = @runId";
                    break;
            }

            SqlCommand mySqlCommand = new SqlCommand(query, connection);

            SqlParameter param1 = new SqlParameter();
            param1.ParameterName = "@currTime";
            param1.Value = DateTime.Now;
            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@runId";
            param2.Value = testRunId;

            mySqlCommand.Parameters.Add(param1);
            mySqlCommand.Parameters.Add(param2);
            mySqlCommand.ExecuteNonQuery();

        }


        /// <summary>
        /// increase or decrease a test run's priority
        /// </summary>
        /// <param name="testRunId"></param>
        /// <param name="priority">the durrent priority</param>
        /// <param name="type">"increase" or "decrease"</param>
        public static void changeTestPriority(int testRunId, int priority, string type)
        {
            int modifiedPri = priority;

            if (type.Equals("increase"))
            {
                modifiedPri--;  // notice that smaller number has higher priority
            }

            if (type.Equals("decrease"))
            {
                modifiedPri++;
            } 

            //connect to database
            SqlConnection connection = connectTodatabase();
            String query = "update RPS_testRun set priority = " + modifiedPri + " where testrunid = @runId";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@runId";
            param.Value = testRunId;

            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();

            connection.Close();

        }


        /// <summary>
        /// get the current build value stored in database
        /// </summary>
        /// <returns></returns>
        public static string getCurrentBuild()
        {
            SqlConnection connection = connectTodatabase();
            string buildNumber = null;
            string query = "SELECT buildnumber " +
                            "FROM RPS_currentvalue ";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount == 1)
                {
                    buildNumber = queryResults.Tables[0].Rows[0]["buildnumber"].ToString();
                }
            }

            connection.Close();

            return buildNumber;
        }



        /// <summary>
        /// set the current build number in database
        /// </summary>
        /// <param name="buildNumber"></param>
        public static void setCurrentBuild(string buildNumber)
        {
            SqlConnection connection = connectTodatabase();
            String query = "update RPS_currentvalue set buildnumber = @currentBuild where buildnumber is not NULL";

            SqlCommand mySqlCommand = new SqlCommand(query, connection);

            SqlParameter param = new SqlParameter();
            param.ParameterName = "@currentBuild";
            param.Value = buildNumber;
           
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();

            connection.Close();

        }


        /// <summary>
        /// get the value of consecutive runs from database
        /// </summary>
        /// <param name="connection"></param>
        /// <returns></returns>
        public static int getConsecutiveRuns(SqlConnection connection)
        {
            int runs = 0;
            string query = "SELECT consecutiveRuns " +
                            "FROM RPS_currentvalue ";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount == 1)
                {
                    runs = Int32.Parse(queryResults.Tables[0].Rows[0]["consecutiveRuns"].ToString());
                }
            }

            return runs;
        }



        /// <summary>
        /// set the value of consecutive runs in database
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="runs"></param>
        public static void setConsecutiveRuns(SqlConnection connection, int runs)
        {

            connection = connectTodatabase();
            String query = "update RPS_currentvalue set consecutiveRuns = " + runs;

            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
        }



        /// <summary>
        /// get the value of how many pending runs in database
        /// </summary>
        /// <param name="connection"></param>
        /// <returns></returns>
        public static int getNumberOfPendingRuns(SqlConnection connection)
        {
            int pendingRuns = 0;
            string query = "SELECT testrunid " +
                            "FROM RPS_testRun " +
                            "WHERE runningstatus = \'pending\'";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                pendingRuns = resultCount;
            }

            return pendingRuns;
        }


        /// <summary>
        /// set if a test run get imaging or not
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="testRunId"></param>
        /// <param name="ifImage"></param>
        public static void setIfImage(SqlConnection connection, int testRunId, int ifImage)
        {
            String query = "update RPS_testRun set ifimage= " + ifImage + " where testrunid = " + testRunId;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
        }


        /// <summary>
        /// set the labcell field for a test run
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="testRunId"></param>
        /// <param name="labcell"></param>
        public static void setLabcell(SqlConnection connection, int testRunId, string labcell)
        {
            String query = "update RPS_testRun set labcell= \'" + labcell + "\' where testrunid = " + testRunId;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
        }



        /// <summary>
        /// insert a pending test run into the database
        /// </summary>
        /// <param name="testRun"></param>
        public static void insertTestRun(TestRun testRun)
        {
            SqlConnection connection = DBoperation.connectTodatabase();

            String query = "insert into RPS_testRun(testruntype, buildnumber, priority, isrerun, runningstatus, createtime, changeList) values (\'" + testRun.TestrunType + "\', \'" + testRun.BuildNumber + "\', " + testRun.Priority + ", " + testRun.IsReRun + ", \'pending\', @createTime, \'" + testRun.ChangeList + "\')";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@createTime";
            param.Value = testRun.CreateTime;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
        }


        /// <summary>
        /// re-run the cancelled test run, reset the field of the cancelled test run
        /// </summary>
        /// <param name="testRun"></param>
        public static void reRunCancelled(TestRun testRun)
        {
            SqlConnection connection = DBoperation.connectTodatabase();

            String query = "update RPS_testRun set priority=" + testRun.Priority + ", isrerun=" + testRun.IsReRun + ", runningstatus=\'pending\' where testrunid=" + testRun.TestRunId;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
        }



        /// <summary>
        /// get the test run from database by testrunid
        /// </summary>
        /// <param name="testRunId"></param>
        /// <returns></returns>
        public static TestRun getTestRunById(string testRunId)
        {
            SqlConnection connection = DBoperation.connectTodatabase();

            //first get the selected test run information from database
            string query = "SELECT testrunid, testruntype, buildnumber, priority, ifimage, isrerun, runningstatus, createtime, changeList " +
                            "FROM RPS_testRun " +
                            "WHERE testrunid = \'" + testRunId + "\'";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);

            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                if (queryResults.Tables[0].Rows.Count != 0)
                {
                    //get the selected test run
                    TestRun myTestRun = new TestRun(Int32.Parse(queryResults.Tables[0].Rows[0]["testrunid"].ToString()), queryResults.Tables[0].Rows[0]["testruntype"].ToString(), queryResults.Tables[0].Rows[0]["buildnumber"].ToString(),
                                                    Int32.Parse(queryResults.Tables[0].Rows[0]["priority"].ToString()), Int32.Parse(queryResults.Tables[0].Rows[0]["ifimage"].ToString()),
                                                    Int32.Parse(queryResults.Tables[0].Rows[0]["isrerun"].ToString()),
                                                    queryResults.Tables[0].Rows[0]["runningstatus"].ToString(), (DateTime)queryResults.Tables[0].Rows[0]["createtime"],
                                                    queryResults.Tables[0].Rows[0]["changeList"].ToString());
                    return myTestRun;
                }
            }
            connection.Close();

            return null;
        }


        /// <summary>
        /// get the date for the previous test run
        /// </summary>
        /// <param name="connection"></param>
        /// <returns></returns>
        public static DateTime getPreviousDate(SqlConnection connection)
        {
            DateTime previousDate = DateTime.Now;
            string query = "SELECT currentdate " +
                            "FROM RPS_currentvalue ";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount == 1)
                {
                    previousDate = DateTime.Parse(queryResults.Tables[0].Rows[0]["currentdate"].ToString());
                }
            }

            return previousDate;
        }



        /// <summary>
        /// get the run number for the previous run
        /// </summary>
        /// <param name="connection"></param>
        /// <returns></returns>
        public static int getPreviousRunNumber(SqlConnection connection)
        {
            int previousRunNumber = 0;
            string query = "SELECT currentRunNumber " +
                            "FROM RPS_currentvalue ";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount == 1)
                {
                    previousRunNumber = Int32.Parse(queryResults.Tables[0].Rows[0]["currentRunNumber"].ToString());
                }
            }

            return previousRunNumber;
        }

        /// <summary>
        /// set the current date and current run number in database
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="currentDate"></param>
        /// <param name="runNumber"></param>
        public static void setDateRunNumber(SqlConnection connection, DateTime currentDate, int runNumber)
        {
            String query = "update RPS_currentvalue set currentdate = @currentDate, currentRunNumber = " + runNumber;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@currentDate";
            param.Value = currentDate;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
        }


        /// <summary>
        /// update the CLR version for a test run
        /// </summary>
        /// <param name="testRunId"></param>
        /// <param name="CLR"></param>
        /// <param name="changed"></param>
        public static void updateCLRForTest(int testRunId, string CLR, int changed)
        {
            SqlConnection connection = DBoperation.connectTodatabase();

            String query = "update RPS_testRun set CLR= \'" + CLR + "\', CLRchange = " + changed + " where testrunid = " + testRunId;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();

            connection.Close();

        }
    }
}
