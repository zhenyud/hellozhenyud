﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;

using RPSsystem.Utility;
using RPSsystem.Utility.FileHandling;

namespace RPSsystem
{
    class TestScheduler
    {
        /*
        private const string CACHE_TARGET_ROOT = "\\\\cdffile01\\e$\\Drops\\RPS";
        private const string TEST_TARGET_ROOT = "D:\\RPS\\CDF40";
        private const string CACHED_TEST_ROOT = "\\\\cdffile01\\e$\\Drops\\RPS";
         * */

        private RPSconfig rpsConfig = null;
        private LogUtil logUtil = null;

        private DateTime startTime = DateTime.Now; // stores the start time for every test run, will be reset when a test is scheduled

        static void Main(string[] args)
        {
            TestScheduler myScheduler = new TestScheduler();

            try
            {
                while (true)
                {
                    // refresh the config in the begining of every loop
                    myScheduler.RpsConfig.refresh();

                    TestRun nextRun = myScheduler.getNextRun();
                    myScheduler.copyTest(nextRun);
                    myScheduler.scheduleTest(nextRun);
                }
            }
            catch (Exception e)
            {
                myScheduler.LogUtil.Error("Error happens in Test Scheduler!\n" + e.StackTrace);
                throw;
            }


        }


        public TestScheduler()
        {
            rpsConfig = new RPSconfig();
            logUtil = new LogUtil(rpsConfig.TestScheduler_logPath);
        }

        public RPSconfig RpsConfig
        {
            get { return rpsConfig; }
        }

        public LogUtil LogUtil
        {
            get { return logUtil; }
        }



        public TestRun getNextRun()
        {
            bool ifRunning = true;
            bool pendingRunExist = false;
            SqlConnection connection = DBoperation.connectTodatabase();
            TestRun pendingTestrun = null;

            while (ifRunning || !pendingRunExist)
            {
                if (checkRunning(connection))
                {
                    ifRunning = true;
                    Console.WriteLine("Try to schedule next test run, but there is still test running, sleep " + rpsConfig.TestSchedulerSleep + " minutes and re-try!");
                    logUtil.Log("Try to schedule next test run, but there is still test running, sleep " + rpsConfig.TestSchedulerSleep + " minutes and re-try!");
                    Thread.Sleep(rpsConfig.TestSchedulerSleep * rpsConfig.MinToMiniSecond);
                }
                else
                {
                    ifRunning = false;
                    pendingTestrun = getNextPendingRun(connection);
                    if (pendingTestrun != null)
                    {
                        pendingRunExist = true;
                    }
                    else
                    {
                        pendingRunExist = false;
                        Console.WriteLine("Try to schedule next test run, but there is no pending run, sleep " + rpsConfig.TestSchedulerSleep + " minutes and re-try!");
                        logUtil.Log("Try to schedule next test run, but there is no pending run, sleep " + rpsConfig.TestSchedulerSleep + " minutes and re-try!");
                        Thread.Sleep(rpsConfig.TestSchedulerSleep * rpsConfig.MinToMiniSecond);
                    }
                }
            }

            Console.WriteLine("got next pending run build: " + pendingTestrun.BuildNumber);
            logUtil.Log("got next pending run build: " + pendingTestrun.BuildNumber);
            Thread.Sleep(3000);

            return pendingTestrun;
        }


        private bool checkRunning(SqlConnection connection)
        {
            String query = "SELECT testrunid FROM RPS_testRun where runningstatus = \'running\'";

            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                if (queryResults.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                else
                {
                    // check if this test running too long
                    TimeSpan ts = DateTime.Now.Subtract(startTime);
                    int mins = ts.Hours * 60 + ts.Minutes;
                    if (mins > rpsConfig.MaxRuntime)
                    {
                        EmailHandler.sendTestRunHangEmail(rpsConfig.EmailPassword);

                        //reset the starttime to avoid duplicate emails are sent
                        startTime = DateTime.Now;
                    }

                    return true;
                }
            }
        }



        private TestRun getNextPendingRun(SqlConnection connection)
        {
            //check if there is high priority runs
            TestRun nextRun = getNextHighPriRun(connection);
            if (nextRun != null)
            {
                return nextRun;
            }

            //if there is no high priority runs, get next normal runs according to the skip rules
            nextRun = getNextNormalRun(connection);
            if (nextRun != null)
            {
                return nextRun;
            }

            // finally check if there is low priority runs
            nextRun = getNextLowPriRun(connection);
            if (nextRun != null)
            {
                return nextRun;
            }

            return null; // return null if no runs are found           
        }


        public TestRun getNextHighPriRun(SqlConnection connection)
        {
            // get high priority run, high priority run should be scheduled from old to new one by one
            string query = "SELECT testrunid, buildnumber, testruntype, priority, ifimage, isrerun, runningstatus, createtime " +
                            "FROM RPS_testRun " +
                            "WHERE runningstatus = \'pending\' And priority < " + rpsConfig.NormalPri + " " +
                            "ORDER BY priority, createtime";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    TestRun myTestRun = new TestRun(Int32.Parse(queryResults.Tables[0].Rows[0]["testrunid"].ToString()), queryResults.Tables[0].Rows[0]["testruntype"].ToString(), queryResults.Tables[0].Rows[0]["buildnumber"].ToString(),
                                                        Int32.Parse(queryResults.Tables[0].Rows[0]["priority"].ToString()), Int32.Parse(queryResults.Tables[0].Rows[0]["ifimage"].ToString()),
                                                        Int32.Parse(queryResults.Tables[0].Rows[0]["isrerun"].ToString()), queryResults.Tables[0].Rows[0]["runningstatus"].ToString(),
                                                        (DateTime)queryResults.Tables[0].Rows[0]["createtime"]);
                    return myTestRun;
                }
            }

            return null; //return null if no high priority runs found
        }



        public TestRun getNextNormalRun(SqlConnection connection)
        {
            // schedule the normal run according to rules
            string query = "SELECT testrunid, testruntype, buildnumber, priority, ifimage, isrerun, runningstatus, createtime " +
                            "FROM testRun " +
                            "WHERE runningstatus = \'pending\' And priority = " + rpsConfig.NormalPri + " " +
                            "ORDER BY priority, createtime";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    int skipRule = rpsConfig.SkipTest_rule; // the skip rule defines how many test runs will be skipped
                    if (rpsConfig.TestUseLastBuild == 1)
                    {
                        skipRule = resultCount - 1; //skip all the test runs except for the last one
                    }
                    if (resultCount > skipRule) // there will only be next test runs if the number of pending runs larger than the skip rule
                    {
                        //skip the test runs according to the rule
                        for (int i = 0; i < skipRule; i++)
                        {
                            // only skip the test runs with normal priority
                            int pri = Int32.Parse(queryResults.Tables[0].Rows[i]["priority"].ToString());
                            if (pri == rpsConfig.NormalPri)
                            {
                                //cancel the skipped test run
                                int testRunId = Int32.Parse(queryResults.Tables[0].Rows[i]["testrunid"].ToString());
                                DBoperation.setTestStatus(connection, testRunId, TestRun.RunStatus.cancelled);
                            }
                        }

                        // get the next run
                        TestRun myTestRun = new TestRun(Int32.Parse(queryResults.Tables[0].Rows[skipRule]["testrunid"].ToString()), queryResults.Tables[0].Rows[skipRule]["testruntype"].ToString(), queryResults.Tables[0].Rows[skipRule]["buildnumber"].ToString(),
                                                        Int32.Parse(queryResults.Tables[0].Rows[skipRule]["priority"].ToString()), Int32.Parse(queryResults.Tables[0].Rows[skipRule]["ifimage"].ToString()),
                                                        Int32.Parse(queryResults.Tables[0].Rows[skipRule]["isrerun"].ToString()), queryResults.Tables[0].Rows[skipRule]["runningstatus"].ToString(),
                                                        (DateTime)queryResults.Tables[0].Rows[skipRule]["createtime"]);
                        return myTestRun;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }
        }



        public TestRun getNextLowPriRun(SqlConnection connection)
        {
            // get low priority runs, 
            string query = "SELECT testrunid, testruntype, buildnumber, priority, ifimage, isrerun, runningstatus, createtime " +
                            "FROM testRun " +
                            "WHERE runningstatus = \'pending\' And priority > " + rpsConfig.NormalPri + " " +
                            "ORDER BY priority, createtime";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    TestRun myTestRun = new TestRun(Int32.Parse(queryResults.Tables[0].Rows[0]["testrunid"].ToString()), queryResults.Tables[0].Rows[0]["testruntype"].ToString(), queryResults.Tables[0].Rows[0]["buildnumber"].ToString(),
                                                        Int32.Parse(queryResults.Tables[0].Rows[0]["priority"].ToString()), Int32.Parse(queryResults.Tables[0].Rows[0]["ifimage"].ToString()),
                                                        Int32.Parse(queryResults.Tables[0].Rows[0]["isrerun"].ToString()), queryResults.Tables[0].Rows[0]["runningstatus"].ToString(),
                                                        (DateTime)queryResults.Tables[0].Rows[0]["createtime"]);
                    return myTestRun;
                }
            }

            return null; //return null if no low priority runs found
        }



        public void copyTest(TestRun testRun)
        {
            Console.WriteLine();
            Console.WriteLine("Copying the tplan and tsouces for build " + testRun.BuildNumber + "     ......");
            logUtil.Log("Copying the tplan and tsouces for build " + testRun.BuildNumber + "     ......");

            FileDirHandling.deleteDir(rpsConfig.TEST_TARGET_ROOT);
            CacheManager.copyTest(testRun.BuildNumber, rpsConfig.CACHED_TEST_ROOT,rpsConfig.TEST_TARGET_ROOT, rpsConfig.Architect + "\\" + rpsConfig.TEST_SUB_DIR);


            Console.WriteLine("Copying finished");
            logUtil.Log("Copying finished");
            
        }


        public void scheduleTest(TestRun testRun)
        {
            Console.WriteLine();
            Console.WriteLine("Scheduling test run: " + testRun.TestRunId + " for: " + testRun.BuildNumber + "    .......");
            logUtil.Log("Scheduling test run: " + testRun.TestRunId + " for: " + testRun.BuildNumber + "    .......");

            //set the start time for the test, it will be used to check if the test running too long
            startTime = DateTime.Now;

            string scheduleCommand = null;

            //found how many consecutive runs
            SqlConnection connection = DBoperation.connectTodatabase();
            int consecutiveRuns = DBoperation.getConsecutiveRuns(connection);

            //found how many runs are pending
            int pendingRuns = DBoperation.getNumberOfPendingRuns(connection);

            //do imaging if the following condition true
            if (consecutiveRuns > rpsConfig.MinRunsNoImaging && pendingRuns < rpsConfig.MaxPendRunsImaging)
            {
                scheduleCommand = scheduleCommand = "D:\\scripts\\schedule_new_RPS.cmd " + testRun.BuildNumber + " " + testRun.TestRunId + " " + 1 + " " + rpsConfig.RunConfig + " " + rpsConfig.LabConfig;
            }
            else //don't do imaging otherwise
            {
                scheduleCommand = scheduleCommand = "D:\\scripts\\schedule_new_RPS.cmd " + testRun.BuildNumber + " " + testRun.TestRunId + " " + 0 + " " + rpsConfig.RunConfig + " " + rpsConfig.LabConfig;
            }

            ExecuteCommandSync(scheduleCommand);
            

            //Setup the latest build number, to be done!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            

            // set the running status to be running in database, and set startTime
            DBoperation.setTestStatus(connection, testRun.TestRunId, TestRun.RunStatus.running);

            //update the consecutiveRuns in database
            //if imaging, set consecutive runs to 1
            if (consecutiveRuns > rpsConfig.MinRunsNoImaging && pendingRuns < rpsConfig.MaxPendRunsImaging)
            {
                DBoperation.setConsecutiveRuns(connection, 1);
                // set the ifimage field of the test run to be 1
                DBoperation.setIfImage(connection, testRun.TestRunId, 1);
            }
            else  // if no imaging, increase the consecutive run number in database
            {
                DBoperation.setConsecutiveRuns(connection, consecutiveRuns + 1);
                // set the ifimage field of the test run to be 0
                DBoperation.setIfImage(connection, testRun.TestRunId, 0);
            }

            connection.Close();

            Thread.Sleep(4000);

            Console.WriteLine("Scheduling finished");
            logUtil.Log("Scheduling finished");

        }



        /// <summary>
        /// Executes a shell command synchronously.
        /// </summary>
        /// <param name="command">string command</param>
        /// <returns>string, as output of the command.</returns>
        public void ExecuteCommandSync(object command)
        {
            try
            {
                // create the ProcessStartInfo using "cmd" as the program to be run,
                // and "/c " as the parameters.
                // Incidentally, /c tells cmd that we want it to execute the command that follows,
                // and then exit.
                System.Diagnostics.ProcessStartInfo procStartInfo =
                    new System.Diagnostics.ProcessStartInfo("cmd", "/c " + command);

                //System.Diagnostics.ProcessStartInfo procStartInfo =
                      //new System.Diagnostics.ProcessStartInfo(command, arguments);


                // The following commands are needed to redirect the standard output.
                // This means that it will be redirected to the Process.StandardOutput StreamReader.
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                procStartInfo.CreateNoWindow = true;
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
                Console.WriteLine(result);
                logUtil.Log(result);
            }
            catch (Exception objException)
            {
                // Log the exception
                throw objException;
            }
        }

    }
}
