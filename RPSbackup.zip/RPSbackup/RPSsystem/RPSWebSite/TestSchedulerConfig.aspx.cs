﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Data.SqlClient;

using RPSsystem;
using RPSsystem.Utility;

namespace RPSWebSite
{
    public partial class TestSchedulerConfig : System.Web.UI.Page
    {
        private Boolean adminUser = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT alias FROM RPS_permission where role = \'admin\'";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                ArrayList aliasList = new ArrayList();
                int resultCount = queryResults.Tables[0].Rows.Count;
                for (int i = 0; i < resultCount; i++)
                {
                    aliasList.Add(queryResults.Tables[0].Rows[i]["alias"].ToString());
                }
                if (aliasList.Contains(HttpContext.Current.User.Identity.Name.ToLower()))
                {
                    adminUser = true;
                }
                else
                {
                    adminUser = false;
                }
            }

            /*
            Boolean zhedai = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\zhedai");
            Boolean rkwiec = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\rkwiec");
            Boolean venkatc = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\venkatc");
            Boolean mauroot = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\mauroot");
            Boolean wdong = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\wdong");
            Boolean qianglin = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\qianglin");
            Boolean sajaya = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\sajaya");
            Boolean jedmiad = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\jedmiad");
            Boolean michfi = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\v-michfi");
            Boolean indgaunt = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\indgaunt");

            adminUser = zhedai || rkwiec || venkatc || wdong;
             * */


            //SqlConnection connection = DBoperation.connectTodatabase();
            string query2 = "SELECT skipTest_rule, runConfig, labConfig, testUseLastBuild, minRunsNoImaging, maxPendRunsImaging FROM RPS_config";
            SqlCommand mySqlCommand2 = new SqlCommand(query2, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand2))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    currSkipTest.Text = queryResults.Tables[0].Rows[0]["skipTest_rule"].ToString();
                    currRunconfig.Text = queryResults.Tables[0].Rows[0]["runConfig"].ToString() + ", " + queryResults.Tables[0].Rows[0]["labConfig"].ToString();
                    //currLabconfig.Text = queryResults.Tables[0].Rows[0]["labConfig"].ToString();
                    MinConsecutiveRuns.Text = queryResults.Tables[0].Rows[0]["minRunsNoImaging"].ToString();
                    MaxPendingRuns.Text = queryResults.Tables[0].Rows[0]["maxPendRunsImaging"].ToString();
                    if (Int32.Parse(queryResults.Tables[0].Rows[0]["testUseLastBuild"].ToString()) == 1)
                    {
                        currUseLastBuild.Text = "Yes";
                    }
                    else
                    {
                        currUseLastBuild.Text = "No";
                    }
                }
            }

            connection.Close();
        }

        protected void changeSkipRun_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "update RPS_config set skipTest_rule = " + TestSkipRuleDropDown.SelectedValue;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
            Response.Redirect("TestSchedulerConfig.aspx");
        }

        protected void changeUseLastBuild_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "update RPS_config set testUseLastBuild = " + changeUseLastBuildDropDown.SelectedValue;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
            Response.Redirect("TestSchedulerConfig.aspx");
        }

        protected void changeConsecutive_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "update RPS_config set minRunsNoImaging = " + changeConsecutiveDropDown.SelectedValue;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
            Response.Redirect("TestSchedulerConfig.aspx");
        }

        protected void changeMax_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "update RPS_config set maxPendRunsImaging = " + changeMaxRunDropdown.SelectedValue;
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
            Response.Redirect("TestSchedulerConfig.aspx");
        }
    }
}
