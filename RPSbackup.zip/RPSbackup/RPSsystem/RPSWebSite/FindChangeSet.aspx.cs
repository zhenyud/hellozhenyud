﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

using RPSsystem.Utility;


namespace RPSWebSite
{
    public partial class FindChangeSet : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void findChangeBtn_Click(object sender, EventArgs e)
        {
            string buildNumber = buildNumText.Text.ToString().Trim();
            string changeset = string.Empty;
            if (buildNumber != null && (!buildNumber.Equals(string.Empty)))
            {
                SqlConnection connection = DBoperation.connectTodatabase();
                string query = "SELECT changeList FROM RPS_testRun where buildnumber = \'" + buildNumber + "\'";
                SqlCommand mySqlCommand = new SqlCommand(query, connection);
                using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
                {
                    DataSet queryResults = new DataSet();
                    dtAdapter.Fill(queryResults);
                    int resultCount = queryResults.Tables[0].Rows.Count;
                    if (resultCount != 0)
                    {
                        changeset = queryResults.Tables[0].Rows[0]["changeList"].ToString();
                        string[] changes = changeset.Split(',');

                        if (changeset!= null && (!changeset.Equals(string.Empty)) && changes != null && changes.Length > 0)
                        {
                            string linkResults = "ChangeSet: ";
                            for (int i = 0; i < changes.Length; i++)
                            {
                                if (i > 0)//if it's not the first change
                                {
                                    linkResults += @",";
                                }
                                linkResults += @"<a href=""\\cdffile01\Drops\RPS\" + buildNumber + @"\snapmail_mail_checkin" + i + @".html"" target=""_blank"">" + changes[i] + @"</a>";
                            }

                            changesetLbl.Text = linkResults;
                        }
                        else
                        {
                            changesetLbl.Text = "No changeSet found, the build number is either not valid or too old!";
                        }
                    }
                    else
                    {
                        changesetLbl.Text = "No changeSet found, the build number is either not valid or too old!";
                    }
                    changesetLbl.Visible = true;

                }

                connection.Close();
            }

        }
    }
}
