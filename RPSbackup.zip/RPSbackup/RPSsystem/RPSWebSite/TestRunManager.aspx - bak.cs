﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Data.SqlClient;

using RPSsystem;

namespace RPSWebSite
{
    public partial class _Default : System.Web.UI.Page
    {
        private string sqlFilter = null;
        private string buildAlias = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) Button1.Attributes.Add("onclick", "return confirm_CancelRerun();");
            if (!IsPostBack) changeSkip.Attributes.Add("onclick", "return confirm_editSkipList();");


            getSkipList();

            //setFilter();
        }

        protected void RpsperfDatasource_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (GridView1.SelectedValue != null)
            {
                selectedTestid.Text = GridView1.SelectedValue.ToString();
            }

            setFilter(); 
        }

        protected void GridView1_Sorted(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";

            setFilter(); 
        }

         protected void GridView1_PageChanged(object sender, EventArgs e)
        {

            selectedTestid.Text = "UnSelected";

            setFilter(); 
        }



        protected void Button1_Click1(object sender, EventArgs e)
        {
            string testId = GridView1.SelectedValue.ToString();
            string operation = DropDownList1.SelectedValue;
            if (operation.Equals("ReRun"))
            {
                insertReRunTest(testId);
            }
            else if (operation.Equals("cancel"))
            {
                cancelTestRun(testId);
            }
            Response.Redirect("TestRunManager.aspx");
            
        }

        protected void insertReRunTest(string testId)
        {
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT testrunid, buildnumber, priority, ifimage, isrerun, runningstatus, createtime " +
                            "FROM testRun " +
                            "WHERE testrunid = @testId";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@testId";
            param.Value = testId;
            mySqlCommand.Parameters.Add(param);

            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                if (queryResults.Tables[0].Rows.Count != 0)
                {
                    TestRun myTestRun = new TestRun(Int32.Parse(queryResults.Tables[0].Rows[0]["testrunid"].ToString()), queryResults.Tables[0].Rows[0]["buildnumber"].ToString(),
                                                    Int32.Parse(queryResults.Tables[0].Rows[0]["priority"].ToString()), Int32.Parse(queryResults.Tables[0].Rows[0]["ifimage"].ToString()), 
                                                    Int32.Parse(queryResults.Tables[0].Rows[0]["isrerun"].ToString()),
                                                    queryResults.Tables[0].Rows[0]["runningstatus"].ToString(), (DateTime)queryResults.Tables[0].Rows[0]["createtime"]);

                    query = "insert into testRun(buildnumber, priority, isrerun, runningstatus, createtime) values (\'" + myTestRun.BuildNumber + "\', 1, 1, \'pending\', @currTime)";
                    mySqlCommand = new SqlCommand(query, connection);
                    param = new SqlParameter();
                    param.ParameterName = "@currTime";
                    param.Value = DateTime.Now;
                    mySqlCommand.Parameters.Add(param);
                    mySqlCommand.ExecuteNonQuery();
                }
            }
        }



        protected void cancelTestRun(string testId)
        {
            DBoperation.setTestStatus(Int32.Parse(testId), TestRun.RunStatus.cancelled);
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";
        
            setFilter(); 
        }


        protected void setFilter()
        {
            buildAlias = devAlias.Text;
            
            DateTime baseDate = new DateTime();
            int days = Int16.Parse(DropDownList2.SelectedValue);
            if (days != 0)
            {
                baseDate = DateTime.Now - TimeSpan.FromDays(days);
            }
            else
            {
                baseDate = DateTime.MinValue;
            }
            sqlFilter = "createtime >= ' " + baseDate + "' ";

            if (buildAlias != null)
            {
                if (buildAlias.Trim() != "")
                {
                    sqlFilter += "AND buildnumber LIKE '%" + buildAlias + "%' ";
                }
            }


            RpsperfDatasource.FilterExpression = sqlFilter;
            
        }

        protected void devAlias_TextChanged(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";

            setFilter(); 
        }

        protected void refreshBtn_Click(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";

            setFilter(); 
        }

        protected void getSkipList()
        {
            string skipBuildList = "";
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT buildnumber " +
                            "FROM skipList";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    for (int i = 0; i < resultCount; i++)
                    {
                        skipBuildList += queryResults.Tables[0].Rows[i]["buildnumber"].ToString() + ", ";
                    }
                }
            }

            skipListTextbox.Text = skipBuildList;
        }

        protected void changeSkip_Click(object sender, EventArgs e)
        {
            string buildNumber = skipBuild.Text;
            string operation = skipListOperation.SelectedValue;
            if (buildNumber != null && operation != null && buildNumber.Trim() != "")
            {
                editSkipList(buildNumber, operation);
            }

            Response.Redirect("TestRunManager.aspx");
        }


        protected void editSkipList(string buildNumber, string operation)
        {
            SqlConnection connection = DBoperation.connectTodatabase();
            if (operation.Equals("add"))
            {
                string query = "insert into skipList(buildnumber) values (\'" + buildNumber + "\')";
                SqlCommand mySqlCommand = new SqlCommand(query, connection);
                mySqlCommand.ExecuteNonQuery();
            }

            if (operation.Equals("remove"))
            {
                string query = "delete from skipList where buildnumber = \'" + buildNumber + "\'";
                SqlCommand mySqlCommand = new SqlCommand(query, connection);
                mySqlCommand.ExecuteNonQuery();
            }
        }
    }
}
