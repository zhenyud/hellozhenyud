﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;

using System.Web;
using System.Web.SessionState;


using System.Data.SqlClient;

using RPSsystem;
using RPSsystem.Utility;
using RPSsystem.Utility.TestRunType;

namespace RPSWebSite
{
    public partial class _Default : System.Web.UI.Page
    {
        private string sqlFilter = null; // the string used to filter the test run results, it's a database filter, will be reset when filter rules are changed by user
        private string buildAlias = null; // used to store the dev's alias for the build for filtering
        private Boolean adminUser = false;
        
        
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Button1.Attributes.Add("onclick", "return confirm_CancelRerun();");

                // set up value for date filter
                if (Session["days"] == null) // if that session parameter does not exist, using the default value in dropdownlist
                {
                    Session.Add("days", DropDownList2.SelectedValue.ToString());
                }
                else  // if that session parameter does exist, means it's set by some previous action, maintain that value
                {
                    DropDownList2.SelectedValue = Session["days"].ToString();
                }

                // same thing for dev alias filter
                if (Session["devalias"] != null) // if that session parameter does exist, means it's set by some previous action, maintain that value
                {
                    devAlias.Text = Session["devalias"].ToString();
                }

                // filter the gridview if its not postback, the filtering for postback will be done in the specific postback event handler
                setFilter(); 
            }

            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT alias FROM RPS_permission where role = \'admin\'";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                ArrayList aliasList = new ArrayList();
                int resultCount = queryResults.Tables[0].Rows.Count;
                for (int i = 0; i < resultCount; i++)
                {
                    aliasList.Add(queryResults.Tables[0].Rows[i]["alias"].ToString());
                }
                if (aliasList.Contains(HttpContext.Current.User.Identity.Name.ToLower()))
                {
                    adminUser = true;
                }
                else
                {
                    adminUser = false;
                }
            }

            /*
            Boolean zhedai = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\zhedai");
            Boolean rkwiec = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\rkwiec");
            Boolean venkatc = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\venkatc");
            Boolean mauroot = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\mauroot");
            Boolean wdong = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\wdong");
            Boolean qianglin = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\qianglin");
            Boolean sajaya = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\sajaya");
            Boolean jedmiad = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\jedmiad");
            Boolean michfi = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\v-michfi");
            Boolean indgaunt = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\indgaunt");

            adminUser = zhedai || rkwiec || venkatc || wdong;
            */

        }

        protected void RpsperfDatasource_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (GridView1.SelectedValue != null)
            {
                // on selected test run, set the text for selected test and the test status
                selectedTestid.Text = GridView1.SelectedValue.ToString();
                GridViewRow row = GridView1.SelectedRow;
                statusText.Text = row.Cells[3].Text;
            }

            setFilter(); //reset filter on selected test change
        }

        protected void GridView1_Sorted(object sender, EventArgs e)
        {
            //on every sort operation, unset the selected test value
            selectedTestid.Text = "UnSelected";
            statusText.Text = "UnKnown";

            setFilter(); //reset filter on every sort operation
        }

         protected void GridView1_PageChanged(object sender, EventArgs e)
        {
            //on every page change operation, unset the selected test value
            selectedTestid.Text = "UnSelected";
            statusText.Text = "UnKnown";

            setFilter(); //reset filter on every page change operation
        }


        /// <summary>
        /// click the submit button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            //get the test id and operation need to take
            string testId = GridView1.SelectedValue.ToString();
            string operation = DropDownList1.SelectedValue;
            if (operation.Equals("ReRun"))
            {
                string preStatus = statusText.Text.Trim();
                //insert a re-run test job if 
                insertReRunTest(testId, preStatus);
             
            }
            
            if (operation.Equals("cancel"))
            {
                //cancel the selected pending run
                cancelTestRun(testId);
            }

            if (operation.Equals("incPri"))
            {
                //increase the priority by 1 for the test run
                DetailsViewRow row = DetailsView1.Rows[5];
                int priority = Int32.Parse(row.Cells[1].Text);
                changePriority(testId, priority, "increase");
            }

            if (operation.Equals("decPri"))
            {
                //decrease the priority by 1 for the test run
                DetailsViewRow row = DetailsView1.Rows[5];
                int priority = Int32.Parse(row.Cells[1].Text);
                changePriority(testId, priority, "decrease");
            }

            Response.Redirect("TestRunManager.aspx");
        }



        /// <summary>
        /// insert a pending re-run test job, we actually only change the values of specific fields of the test run instead of insert a new row, if re-run a cancelled one.
        /// we only insert a new row if re-run a finished one. creation time is always unchanged cause we need to use it to sort the regression report.
        /// </summary>
        /// <param name="testId"></param>
        /// <param name="preStatus">the running status for the old test run</param>
        protected void insertReRunTest(string testId, string preStatus)
        {
            //get the test run first
            TestRun myTestRun = DBoperation.getTestRunById(testId);
            myTestRun.Priority = RPSconfig.rerunPri;
            myTestRun.IsReRun = 1;

            if (preStatus.Equals("cancelled"))
            {
                //don't insert new row, only change the old row
                DBoperation.reRunCancelled(myTestRun);
            }
            else
            {
                //insert the re-run test job if the preStatus is done or running, creation time is unchanged though
                DBoperation.insertTestRun(myTestRun);
            }
          
        }

        
        /// <summary>
        /// cancel a specified test run
        /// </summary>
        /// <param name="testId"></param>
        protected void cancelTestRun(string testId)
        {
            SqlConnection connection = DBoperation.connectTodatabase();
            DBoperation.setTestStatus(connection, Int32.Parse(testId), TestRun.RunStatus.cancelled);
            connection.Close();
        }



        /// <summary>
        /// change the priority of a test run
        /// </summary>
        /// <param name="testId"></param>
        /// <param name="priority"></param>
        /// <param name="type"></param>
        protected void changePriority(string testId, int priority, string type)
        {
            DBoperation.changeTestPriority(Int32.Parse(testId), priority, type);
        }


        /// <summary>
        /// reset filter when the time filter dropdown changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";
            statusText.Text = "UnKnown";
            
            Session.Add("days", DropDownList2.SelectedValue.ToString());
            setFilter();

        }



        /// <summary>
        /// update the filter criteria
        /// </summary>
        protected void setFilter()
        {
            //dev's alias
            //buildAlias = devAlias.Text;

            
            if (Session["devalias"] != null)
            {
                buildAlias = Session["devalias"].ToString();
            }
            else
            {
                buildAlias = null;
            }
            


            
            DateTime baseDate = new DateTime();

            //get time filter value
            //int days = Int16.Parse(DropDownList2.SelectedValue);

            
            int days = 5; //default is 5
            if (Session["days"] != null)
            {
                days = Int32.Parse(Session["days"].ToString());
            }
             
            if (days != 0)
            {
                baseDate = DateTime.Now - TimeSpan.FromDays(days);
            }
            else
            {
                baseDate = DateTime.MinValue;
            }
            sqlFilter = "createtime >= ' " + baseDate + "' ";

            if (buildAlias != null)
            {
                if (buildAlias.Trim() != "")
                {
                    sqlFilter += "AND buildnumber LIKE '%" + buildAlias + "%' ";
                }
            }

            RpsperfDatasource.FilterExpression = sqlFilter;
            //RpsperfDatasource.DataBind();
            
        }


        /// <summary>
        /// update filter when dev's alias changed in filter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void devAlias_TextChanged(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";
            statusText.Text = "UnKnown";

            Session.Add("devalias", devAlias.Text.Trim());
            setFilter(); 
        }



        /// <summary>
        /// update filter when refresh button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void refreshBtn_Click(object sender, EventArgs e)
        {
            selectedTestid.Text = "UnSelected";
            statusText.Text = "UnKnown";

            Session.Add("devalias", devAlias.Text.Trim());
            setFilter(); 
            
        }



        protected string getChangeListLinks(object changeList, object buildNumber)
        {
            string linkResults = string.Empty;
            if (changeList != null && buildNumber != null && !changeList.Equals(System.DBNull.Value) && !buildNumber.Equals(System.DBNull.Value))
            {
                string[] changes = ((string)changeList).Split(',');

                if (changes != null && changes.Length > 0)
                {
                    for (int i = 0; i < changes.Length; i++)
                    {
                        if (i > 0)//if it's not the first change
                        {
                            linkResults += @"<br>";
                        }
                        linkResults += @"<a href=""\\cdffile01\Drops\RPS\" + (string)buildNumber + @"\snapmail_mail_checkin" + i + @".html"">" + changes[i] + @"</a>";
                    }
                }
            }


            return linkResults;
        }


        protected string getRegressionLinks(object testResult, object labRunId, bool compareFive)
        {
            string linkResults = string.Empty;
            if (testResult != null && labRunId != null && !testResult.Equals(System.DBNull.Value) && !labRunId.Equals(System.DBNull.Value))
            {
                string regression = ((string)testResult).ToString().Trim();
                string runId = ((Int32)labRunId).ToString().Trim();
                if (regression.Equals("Possible_regression"))
                {
                    if (compareFive)
                        linkResults += @"<a href=""http://xws-perf-cc/indiperfRPS/AnalyzeRun.aspx?&runid=" + runId + @"&testid=-1&testname=-1&count=30&analyzeRPSrun=true&showRPSchart=true"">" + regression + @"</a>";
                    else
                        linkResults += @"<a href=""http://xws-perf-cc/indiperfRPS/AnalyzeRun.aspx?&runid=" + runId + @"&testid=-1&testname=-1&count=30&analyzeRPSrun=true&showRPSchart=true&compare=1"">" + regression + @"</a>";

                }

                if (regression.Equals("No_regression"))
                {
                    linkResults += @"<a href=""http://xws-perf-cc/indiperfRPS/GenerateReport.aspx?&runid=" + runId + @"&testid=-1&testname=-1&count=20"">" + regression + @"</a>";
                }
            }


            return linkResults;
        }

    }
}
