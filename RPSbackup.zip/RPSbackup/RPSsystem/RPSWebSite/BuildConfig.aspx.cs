﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Data.SqlClient;

using RPSsystem;
using RPSsystem.Utility;

namespace RPSWebSite
{
    public partial class BuildConfig : System.Web.UI.Page
    {
        private Boolean adminUser = false;

        protected void Page_Load(object sender, EventArgs e)
        {

            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "SELECT alias FROM RPS_permission where role = \'admin\'";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                ArrayList aliasList = new ArrayList();
                int resultCount = queryResults.Tables[0].Rows.Count;
                for(int i=0; i<resultCount; i++)
                {
                    aliasList.Add(queryResults.Tables[0].Rows[i]["alias"].ToString());
                }
                if (aliasList.Contains(HttpContext.Current.User.Identity.Name.ToLower())){
                    adminUser = true;
                }else{
                    adminUser = false;
                }
            }

            /*
            Boolean zhedai = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\zhedai");
            Boolean rkwiec = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\rkwiec");
            Boolean venkatc = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\venkatc");
            Boolean mauroot = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\mauroot");
            Boolean wdong = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\wdong");
            Boolean qianglin = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\qianglin");
            Boolean sajaya = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\sajaya");
            Boolean jedmiad = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\jedmiad");
            Boolean michfi = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\v-michfi");
            Boolean indgaunt = HttpContext.Current.User.Identity.Name.ToLower().Equals(@"redmond\indgaunt");

            adminUser = zhedai || rkwiec || venkatc || wdong;
             * */

            if (!IsPostBack) changeSNAP.Attributes.Add("onclick", "return confirm_SnapRoot();");
            if (!IsPostBack) changeCacheTarget.Attributes.Add("onclick", "return confirm_CacheRoot();");
            if (!IsPostBack) addProductPath.Attributes.Add("onclick", "return confirm_addProductPath();");
            if (!IsPostBack) addTestPath.Attributes.Add("onclick", "return confirm_addTestPath();");

            
            int filter_verifyTestChange = 0; // default value is 0

            //SqlConnection connection = DBoperation.connectTodatabase();
            string query2 = "SELECT filter_skipBuild, snap_root, cache_target_root, filter_verifyTestChange, flavor FROM RPS_config";
            SqlCommand mySqlCommand2 = new SqlCommand(query2, connection);
            using (SqlDataAdapter dtAdapter = new SqlDataAdapter(mySqlCommand2))
            {
                DataSet queryResults = new DataSet();
                dtAdapter.Fill(queryResults);
                int resultCount = queryResults.Tables[0].Rows.Count;
                if (resultCount != 0)
                {
                    currCacheTarget.Text = queryResults.Tables[0].Rows[0]["cache_target_root"].ToString();
                    currSnapRoot.Text = queryResults.Tables[0].Rows[0]["snap_root"].ToString();
                    currSkipBuild.Text = queryResults.Tables[0].Rows[0]["filter_skipBuild"].ToString();
                    filter_verifyTestChange = Int32.Parse(queryResults.Tables[0].Rows[0]["filter_verifyTestChange"].ToString());
                    currFlavor.Text = queryResults.Tables[0].Rows[0]["flavor"].ToString();
                }
            }

            connection.Close();

            if (filter_verifyTestChange == 0)
            {
                testPathCell.Enabled = false;
            }
            else
            {
                testPathCell.Enabled = true;
            }

        }

        protected void changeSkip_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string skipValue = skipValueDropDown.SelectedValue;
            string query = "update RPS_config set filter_skipBuild = @skipValue";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@skipValue";
            param.Value = skipValue;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();

            Response.Redirect("BuildConfig.aspx");
        }

        protected void changeSNAP_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string snapRoot = snapRootText.Text;
            string query = "update RPS_config set snap_root = @snapRoot";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@snapRoot";
            param.Value = snapRoot;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();

            Response.Redirect("BuildConfig.aspx");
        }

        protected void changeCacheTarget_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string cacheRoot = cacheRootText.Text;
            string query = "update RPS_config set cache_target_root = @cacheRoot";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@cacheRoot";
            param.Value = cacheRoot;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();

            Response.Redirect("BuildConfig.aspx");
        }

        protected void addProductPath_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "insert into RPS_changepaths(type, path) values (\'product\', \'" + addProductText.Text.Trim() + "\')";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
            Response.Redirect("BuildConfig.aspx");
        }

        protected void addTestPath_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string query = "insert into RPS_changepaths(type, path) values (\'test\', \'" + addTestText.Text.Trim() + "\')";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
            Response.Redirect("BuildConfig.aspx");
        }

        protected void changeFlavor_Click(object sender, EventArgs e)
        {
            if (!adminUser)
            {
                Response.Write(@"<font size=""5"" color=""ff3333"">You have no authority to make any changes!</font>");
                return;
            }
            SqlConnection connection = DBoperation.connectTodatabase();
            string newFlavor = flavorDropDown.SelectedValue;
            string query = "update RPS_config set flavor = @newFlavor";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@newFlavor";
            param.Value = newFlavor;
            mySqlCommand.Parameters.Add(param);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();

            Response.Redirect("BuildConfig.aspx");
        }
    }
}
