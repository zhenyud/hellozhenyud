﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using RPSsystem;
using RPSsystem.Utility;

namespace RPSWebSite
{
    public partial class RPSpostTestOperation : System.Web.UI.Page
    {
        protected System.Data.SqlClient.SqlConnection connection;

        protected void Page_Load(object sender, EventArgs e)
        {
            // get parameter from url   
            string testRunId = Request.QueryString["testrunid"];

            //connect to database
            connection = DBoperation.connectTodatabase();
            String query = "update RPS_testRun set runningstatus = \'done\', endtime = @currTime where testrunid = @runId";
            SqlCommand mySqlCommand = new SqlCommand(query, connection);

            SqlParameter param1 = new SqlParameter();
            param1.ParameterName = "@currTime";
            param1.Value = DateTime.Now;
            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@runId";
            param2.Value = testRunId;

            mySqlCommand.Parameters.Add(param1);
            mySqlCommand.Parameters.Add(param2);
            mySqlCommand.ExecuteNonQuery();

            Response.Write("\nSUCCESS");

        }
    }
}
