
$| = 1; 
open(STDERR, ">&STDOUT");    # redirect STDERR to STDOUT

my $start_time = time;

$DEBUG = 1;

# need to add some logic to look for other running scripts as an extra safety
# feature
use POSIX ":sys_wait_h";
use DBI;
use DBD::mysql;
use XML::Simple;
use File::Copy;
require "/htdocs/cgi-bin/config-lib.pl";     # provides configuration functionality
require "/htdocs/cgi-bin/db-lib.pl";         # provides DB related globals

$num_children = 0;      # number of child processes currently running
$curr_prod_pid = 0;     # PID for active pre-prod/prod test
@children = ();

#-------------------------------------------------------------------------------
# grim_reaper
#
# This function is the signal handler for SIGCHLD signals.
#-------------------------------------------------------------------------------
sub grim_reaper
{
	my $child;
    while (($child = waitpid(-1, WNOHANG)) > 0) 
    {
        print "Decrementing the number of children...\n$child Status : $?\n" if $DEBUG;
        $num_children--;
        
        # if this child was the current prod process, clear the curr_prod_pid so
        # that we can fire off another prod test
        if ($child == $curr_prod_pid)
        {
            print "Erasing prod pid...\n" if $DEBUG;
            $curr_prod_pid = 0;
        }

	    #$Kid_Status{$child} = $?;
	}

    $dbh = &get_dbh;

	$SIG{CHLD} = \&grim_reaper;
}

my $max_run_time = 60;
my $time_between_runs = 5;

my $retrieve_start_time_sql = "select UNIX_TIMESTAMP(startTime) as epochTime from testRuns where testRunId = ?";
my $queue_update_start_time_sql = "update testRuns set startTime = CURRENT_TIMESTAMP where testRunId = ?";
my $queue_update_end_time_sql = "update testRuns set endTime = CURRENT_TIMESTAMP where testRunId = ?";
my $queue_update_status_sql = "update testRuns set testRunStatus = ? where testRunId = ?";
my $queue_ts_sql = "select * from (select * from testRunSuites, statusDefinitions where statusName = ? and testSuiteStatus = statusId and testRunId=?) ts, (select testSuiteName, avg(UNIX_TIMESTAMP(endTime)-UNIX_TIMESTAMP(startTime)) as avgTime from testRunSuites where testSuiteStatus = 3 and testcases = 'all' and numPassed + numFailed > 0 and startTime > 0 and endTime > 0 group by testSuiteName) avgTimes where ts.testSuiteName = avgTimes.testSuiteName order by avgTime";
my $executing_ts_sql = "select count(*) as numExecuting from testRunSuites, statusDefinitions where statusName=? and testSuiteStatus = statusId and testRunId=?";
my $activeSuites_sql = "select count(*) as numActive from activeSuites where testSuiteName = ?";
my $activeProdSuites_sql = "select count(*) as numActive from activeSuites where testSuiteEnvId = ?";
my $activeSuitesInsert_sql = "insert into activeSuites(testRunSuiteId, testSuiteName, testSuiteEnvId) values(?, ?, ?)";

chdir("/htdocs");
$SIG{CHLD} = \&grim_reaper;

$dbh;

while (time - $start_time < $max_run_time)
{
    $dbh = &get_dbh;
    my $testRun = $dbh->selectrow_hashref("select * from testRuns, statusDefinitions where testRunStatus = statusId and statusName = ? order by creationTime limit 1", undef, PENDING());

    if (! defined $testRun)
    {
        sleep($time_between_runs);
    }
    else
    {
        # mark this test run as executing
        my $statusId = retrieve_status_id($dbh, EXECUTING());
        $dbh = &get_dbh;
        $dbh->do($queue_update_status_sql, undef, $statusId, $testRun->{'testRunId'}) or die $DBI::errstr;
        $dbh = &get_dbh;
        $dbh->do($queue_update_start_time_sql, undef, $testRun->{'testRunId'}) or die $DBI::errstr;

        # retrieve the timestamp that was generated in the previous step
        # because we need it in order to initiate the tests
        $dbh = &get_dbh;
        my $time_result = $dbh->selectrow_hashref($retrieve_start_time_sql, undef, $testRun->{'testRunId'});
        my $current_start_time = $time_result->{'epochTime'};

        $dbh = &get_dbh;
        my $pendingTestSuitesRef = $dbh->selectall_arrayref($queue_ts_sql, { Slice => {} }, PENDING(), $testRun->{'testRunId'});
        my $numPendingTestSuites = scalar(@$pendingTestSuitesRef);

        MASTER: while ($numPendingTestSuites > 0)
        {
            # loop over all of the test suites to be executed while there are more
            # test suites to be executed and the test run has not been cancelled
            foreach my $queue_ts (@$pendingTestSuitesRef)
            {
                print "Checking to see if test run has been cancelled...\n" if $DEBUG;
                last MASTER if getTestRunStatus($dbh, $testRun->{'testRunId'}) eq CANCELLED();
                print "It has not been cancelled.\n" if $DEBUG;
                
                # check to see if the next test suite is a prod test suite;
                # if it is and another prod suite is already running, skip ahead to 
                # the next test suite; we'll run this one later
                print "Checking to see if we should execute this later because another prod test is already running.\n" if $DEBUG;
                next if ($queue_ts->{'testSuiteEnvId'} == PROD() && $curr_prod_pid > 0);
                print "No other prod tests are running or this is not a prod test.\n" if $DEBUG;

                while ($num_children >= $testRun->{'maxForkedChildren'})
                {
                    sleep(3);
                    last MASTER if getTestRunStatus($dbh, $testRun->{'testRunId'}) eq CANCELLED();
                }
                print "Exited sleep loop...\n" if $DEBUG;

                # check to see if the test suite to be run is already running
                # under a different test run; if so, skip it for the time being
                $dbh = &get_dbh;
                my $numActive = $dbh->selectrow_hashref($activeSuites_sql, undef, $queue_ts->{'testSuiteName'});
                if ($numActive->{'numActive'} > 0)
                {
                    print "Skipping because the testcase $queue_ts->{'testSuiteName'} is already running within a separate test run.\n" if $DEBUG;
                    next;
                }
                else
                {
                    # if this is a prod suite, check to see if anyone else is running any prod test suites
                    if ($queue_ts->{'testSuiteEnvId'} == PROD())
                    {
                        $dbh = &get_dbh;
                        my $numProdActive = $dbh->selectrow_hashref($activeProdSuites_sql, undef, PROD());
                        if ($numProdActive->{'numActive'} > 0)
                        {
                            print "Skipping because someone else is running a prod test suite.\n";
                            next;
                        }
                    }
                    
                    # update the activeSuites table to reflect the fact that we are running this suite
                    $dbh = &get_dbh;
                    $dbh->do($activeSuitesInsert_sql, 
                             undef, 
                             $queue_ts->{'testRunSuiteId'},
                             $queue_ts->{'testSuiteName'},
                             $queue_ts->{'testSuiteEnvId'}) or die $DBI::errstr;
                }

                my $pid = fork();
                if ($pid)
                {
                    print "Executing a new child ($pid - $queue_ts->{'testSuiteName'})...\n" if $DEBUG;
                    push(@children, $pid);
                    $num_children++;
                    
                    $curr_prod_pid = $pid unless $queue_ts->{'testSuiteEnvId'} != PROD();
                }
                elsif (0 == $pid)
                {
                    runTestSuite($current_start_time, $testRun->{'login'}, %$queue_ts);
                    exit(0);
                }
                else
                {
                    die "Couldn't fork: $! \n";
                }
            }

            print "Checking to see if we need to execute any other test suites...\n" if $DEBUG;
            $dbh = &get_dbh;
            $pendingTestSuitesRef = $dbh->selectall_arrayref($queue_ts_sql, { Slice => {} }, PENDING(), $testRun->{'testRunId'}) or die $DBI::errstr;
            $numPendingTestSuites = scalar(@$pendingTestSuitesRef);

            print "Num Pending: $numPendingTestSuites\n\n" if $DEBUG;
            sleep($time_between_runs);
        }
        print "Test run finished...\n" if $DEBUG;

        # check to see if any test suites are still marked as executing

        $dbh = &get_dbh;
        my $numExecuting = $dbh->selectrow_hashref($executing_ts_sql, undef, EXECUTING(), $testRun->{'testRunId'}) or die $DBI::errstr;
        
        # loop here until all children have finished executing
        print "Checking number of executing children: $numExecuting->{'numExecuting'}\n" if $DEBUG;
        while ($numExecuting->{'numExecuting'} > 0)
        {
            if (getTestRunStatus($dbh, $testRun->{'testRunId'}) eq CANCELLED())
            {
                foreach my $child (@children)
                {
                    print "Trying to kill $child...\n" if $DEBUG;
                    my $num_killed = kill(1, $child) || "0";
                    print "Killed $num_killed children.\n" if $DEBUG;
                }
            }
            sleep($time_between_runs);
            $dbh = &get_dbh;
            $numExecuting = $dbh->selectrow_hashref($executing_ts_sql, undef, EXECUTING(), $testRun->{'testRunId'}) or die $DBI::errstr;
            print "Checking number of executing children: $numExecuting->{'numExecuting'}\n" if $DEBUG;
        }

        # make doubly sure that all children have terminated
        foreach my $child (@children)
        {
            print "Waiting on child $child\n" if $DEBUG;
            waitpid($child, 0);
        }

        @children = ();
        $num_children = 0;
        $curr_prod_pid = 0;

        # remove all stale rows from activeSuites
        $dbh = &get_dbh;
        $dbh->do(q{delete from activeSuites where testRunSuiteId in (select testRunSuiteId from testRunSuites where testRunId=?)}, undef, $testRun->{'testRunId'}) or die $DBI::errstr;

        # check to see if this test run has already been cancelled
        my $emailStatus = CANCELLED();
        if (getTestRunStatus($dbh, $testRun->{'testRunId'}) ne CANCELLED())
        {
            # mark this test run as finished
            $statusId = retrieve_status_id($dbh, COMPLETED());
            $dbh = &get_dbh;
            $dbh->do($queue_update_status_sql, undef, $statusId, $testRun->{'testRunId'}) or die $DBI::errstr;
            $emailStatus = COMPLETED();
        }
                
        # update the time at which this run ended
        $dbh = &get_dbh;
        $dbh->do($queue_update_end_time_sql, undef, $testRun->{'testRunId'}) or die $DBI::errstr;
        
        if ($testRun->{'emailNotification'} == 1)
        {
            $ENV{'HOSTNAME'} |= "prime-test-0101.sea3.amazon.com";

            # send an email to the originator
           	open (MAIL,"|/usr/sbin/sendmail -t");
    	    print MAIL <<EOF;
To: $testRun->{'login'}\@amazon.com
From: prime-qa\@amazon.com
Subject: SSTE Test Run $testRun->{'testRunId'} - $emailStatus
    
Your test run has finished.  Please visit the following URL for detailed results.
 
http://$ENV{'HOSTNAME'}/?action=report&sub_action=view_run&testRunId=$testRun->{'testRunId'}

Prime QA
prime-qa\@amazon.com
EOF
    	    close(MAIL);
        }
    }
}

sub runTestSuite
{
    my ($current_start_time, $login, %queue_ts) = @_;
    
    my $queue_ts_status_sql = "select statusName from testRunSuites, statusDefinitions where testRunSuiteId = ? and statusId = testSuiteStatus";
    my $queue_ts_update_status_sql = "update testRunSuites set testSuiteStatus = ? where testRunSuiteId = ?";
    my $ts_update_cmd_sql = "update testRunSuites set testSuiteCommand = ? where testRunSuiteId = ?";

    # start and end time update queries for the testRunSuites table
    my $ts_update_start_time_sql = "update testRunSuites set startTime = CURRENT_TIMESTAMP where testRunSuiteId = ?";
    my $ts_update_end_time_sql = "update testRunSuites set endTime = CURRENT_TIMESTAMP where testRunSuiteId = ?";
    my $ts_update_results_sql = "update testRunSuites set numPassed = ?, numFailed = ?, failedTestcases = ? where testRunSuiteId = ?";
    
    print "$queue_ts{'testSuiteName'}: Connecting to the DB...\n" if $DEBUG;
    my $childDbh = &get_dbh;
    print "$queue_ts{'testSuiteName'}: checking the status of the test suite...\n" if $DEBUG;
    my $ts_status = $childDbh->selectrow_hashref($queue_ts_status_sql, undef, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;
    

    # if this test suite has not been run, initiate its execution
    if ($ts_status->{'statusName'} eq PENDING())
    {
        # mark the test suite as executing
        print "$queue_ts{'testSuiteName'}: pending -->executing...\n" if $DEBUG;
        my $statusId = retrieve_status_id($childDbh, EXECUTING());
        $childDbh = &get_dbh;
        $childDbh->do($queue_ts_update_status_sql, undef, $statusId, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;

        # execute the test suite
        my $upperCaseName = $queue_ts{'testSuiteName'};
        $upperCaseName =~ s/^prime/Prime/;

        my $arguments = $queue_ts{'testSuiteArguments'};
        if ($queue_ts{'testcases'} ne "all" && $queue_ts{'testcases'} ne "")
        {
            $arguments .= " --testcaseId=$queue_ts{'testcases'} ";
        }
                        
        # note that the startTime parameter must be passed in before the
        # login parameter
        my $transcriptFile = "/tmp/transcript_$queue_ts{'testRunSuiteId'}.txt";
        my $cmd = "./testScripts/${upperCaseName}.sh --startTime=$current_start_time --login=$login $arguments > $transcriptFile 2>&1";
        print "$queue_ts{'testSuiteName'}: saving the command...\n" if $DEBUG;
        $childDbh = &get_dbh;
        $childDbh->do($ts_update_cmd_sql, undef, $cmd, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;
        
        # record the time that this test suite started
        print "$queue_ts{'testSuiteName'}: saving the start time...\n" if $DEBUG;
        $childDbh = &get_dbh;
        $childDbh->do($ts_update_start_time_sql, undef, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;

        # execute the test suite
        print "$queue_ts{'testSuiteName'}: executing...\n" if $DEBUG;
        system($cmd);
        
        # record the time that this test suite ended
        print "$queue_ts{'testSuiteName'}: updating the end time...\n" if $DEBUG;
        $childDbh = &get_dbh;
        $childDbh->do($ts_update_end_time_sql, undef, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;
        
        # move the transcript file to the appropriate output directory
        print "$queue_ts{'testSuiteName'}: moving the file...\n" if $DEBUG;
        print "About to execute mv $transcriptFile result/$login/$current_start_time/$upperCaseName/transcript.txt \n" if $DEBUG;
        move($transcriptFile, "result/$login/$current_start_time/$upperCaseName/transcript.txt");
        
        # parse the results file to determine the outcome of this test suite
        print "$queue_ts{'testSuiteName'}: parsing the report...\n" if $DEBUG;
        my $report = "result/$login/$current_start_time/$upperCaseName/result.xml";
    
        my ($pass, $fail, $unknown) = (0, 0, 0);
        my %failures;
        if (-e $report)
        {
            my $xml = new XML::Simple;
 			my $data = $xml->XMLin("$report");
 			
 			foreach my $main_xml_key (keys %$data)
 			{
 			    next unless $main_xml_key =~ /testCase([0-9]+)$/;
 			    my $testcaseNumber = $1;

 			    foreach my $xml_key (keys %{$data->{$main_xml_key}})
 			    {
     			    next unless $xml_key =~ /^result[0-9]+$/;

     			    if ($data->{$main_xml_key}->{$xml_key}->{'status'}->{'value'} eq "FAIL")
     			    {
     			        $fail++;
     			        $failures{$testcaseNumber}++;
     			    }
     			    elsif ($data->{$main_xml_key}->{$xml_key}->{'status'}->{'value'} eq "PASS")
     			    {
     			        $pass++;
     			    }
     			    else
     			    {
     			        $unknown++;
     			    }
     			}
 			}
   		}

        # sort the failures numerically
        my $failures_str = "";
        my @failures_arr = sort as_number keys %failures;
        foreach my $failure (@failures_arr)
        {
             if ($failures_str eq "")
             {
                 $failures_str .= $failure;
             }
             else
             {
                 $failures_str .= ",$failure";
             }                    
        }
        
        # store the number of passes and fails to the database
        print "$queue_ts{'testSuiteName'}: Updating the number of passes and fails...\n" if $DEBUG;
        $childDbh = &get_dbh;
        $childDbh->do($ts_update_results_sql, undef, $pass, $fail, $failures_str, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;
        print "$queue_ts{'testSuiteName'}: Updating the number of passes and fails...DONE\n" if $DEBUG;


        # mark the test suite as completed
        print "$queue_ts{'testSuiteName'}: marking the test suite as complete...\n" if $DEBUG;
        $statusId = retrieve_status_id($childDbh, COMPLETED());
        $childDbh = &get_dbh;
        $childDbh->do($queue_ts_update_status_sql, undef, $statusId, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;
    }    

    print "$queue_ts{'testSuiteName'}: Cleaning up the activeSuites table...\n" if $DEBUG;
    $childDbh = &get_dbh;
    $childDbh->do(q{delete from activeSuites where testRunSuiteId=?}, undef, $queue_ts{'testRunSuiteId'}) or die $DBI::errstr;
    print "$queue_ts{'testSuiteName'}: Cleaning up the activeSuites table...DONE\n" if $DEBUG;
    
}


#-------------------------------------------------------------------------------
# getTestRunStatus
#
# This function takes in a database handle and a test run ID.  It searches the
# testRuns table for the status of the matching test run and returns the status.
#-------------------------------------------------------------------------------
sub getTestRunStatus
{
    my ($local_dbh, $testRunId) = @_;
    $local_dbh = &get_dbh;
    my $result = $local_dbh->selectrow_hashref("select statusName from testRuns, statusDefinitions where testRunId = ? and statusId = testRunStatus", undef, $testRunId) or die $DBI::errstr;
    return $result->{'statusName'};
}

#-------------------------------------------------------------------------------
# as_number
#
# This is passed in as an operator to the sort function to force sort to treat
# the values it is sorting as numerics instead of strings.
#-------------------------------------------------------------------------------
sub as_number
{
    return $a <=> $b;
}
