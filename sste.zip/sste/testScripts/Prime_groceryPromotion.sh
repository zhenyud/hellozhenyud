#!/bin/sh


source /net/zhenyu.desktop.amazon.com/workplace/p4clients/zhenyu-PrimeTests-NewClient/src/appgroup/OrderingQA/apps/PrimeTests/GTS/classpath


export JAVA_HOME=/net/zhenyu.desktop.amazon.com/workplace/jdk1.5.0_06


cd /net/zhenyu.desktop.amazon.com/workplace/p4clients/zhenyu-PrimeTests-NewClient/src/appgroup/OrderingQA/apps/PrimeTests/ 

$JAVA_HOME/bin/java -Xms256m -Xmx512m -cp $CLASSPATH amazon.qa.sellercentral.autoWeb.primeTest.prime_groceryPromotion.Prime_groceryPromotion_TestSuite --root=/apollo/env/ssteApache --realm=USAmazon --domain=test --override='(configuration/BSF.cfg,configuration/PrimeSubscribersCollectionClient.cfg)' $@
