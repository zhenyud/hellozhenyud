#!/usr/local/bin/perl

my $data_dir = "/workplace/jolo-SSTEUserInterface-mainline/src/appgroup/primeclub/apps/SSTEUserInterface/asinChecker";
my $output_dir = "$data_dir/last_run";

if (! -e $output_dir)
{
    system("/bin/mkdir $output_dir");
}

$DEBUG = 0;
use WWW::Mechanize;
my $mech = WWW::Mechanize->new();
$mech->agent_alias( 'Windows IE 6' );

print "Logging in..." if $DEBUG;
my $login_url = "https://development.amazon.com/gp/flex/sign-in/select.html/?ie=UTF8&protocol=https";
my $form = $mech->get($login_url);
open(FORM, ">$output_dir/login1.html");
print FORM $form->content;
close(FORM);
my %fields = (email => 'mocha016@amazon.com', password => 'test');
$response = $mech->submit_form(with_fields => \%fields);
print "done.\n" if $DEBUG;

print "Turning on 1-click..." if $DEBUG;
$mech->get("http://development.amazon.com/gp/product/B0007PF828");
$mech->follow("Click here to turn on 1-Click");
open(FORM, ">$output_dir/login2.html");
print FORM $mech->response->content;
close(FORM);
print "done.\n" if $DEBUG;

my %domains = 
(
	'd' => 'development',
	'p' => 'pre-prod'
);

open($asin_fh, "$data_dir/asins.flat");
open($asin_status_fh, ">$data_dir/asins_current.flat");
while (<$asin_fh>)
{
    chomp;
    if (/^\#/)
    {
    	print $asin_status_fh "#\n";
    	next;	
    }
    my ($asin, $desc, $env, $is_fast_track, $is_prime, $is_ssof, $ships_standard, $is_sold_by_amazon, $is_pre_order, $is_buyable) = split(/\t/);

    print "Checking ${asin}...\n" if $DEBUG;
    
    my $url = "";
    if ($is_ssof)
    {
    	$url = "http://$domains{$env}.amazon.com/gp/offer-listing/$asin";
    }
    else
    {
    	$url = "http://$domains{$env}.amazon.com/gp/product/$asin";
    }

   	my $response = $mech->get($url);
   	my $content = $response->content();

	my $retry_count = 0;
	while ($content =~ /<h2>We\'re sorry\!<\/h2>/ && $retry_count < 10)
	{
		$retry_count++;
		sleep(3);
	   	$response = $mech->get($url);
	   	$content = $response->content();
	}

    open(CONTENT, ">$data_dir/tmpcontent/${asin}.html");
    print CONTENT $content;
    close(CONTENT);
    
    my $buyable = 0;
    my $fast_trackable = 0;
    my $only_ships_standard = 0;
	my $pre_order = 0; 
	my $ssof = 0;
	my $prime = 0;
	my $sold_by_amazon = 0;
	
	if ($content =~ /Ships from and sold by <b>Amazon\.com<\/b>\./)
	{
		$sold_by_amazon = 1;	
	}
	
    if ($is_pre_order)
    {
    	if ($is_ssof)
    	{
	    	if ($content =~ /preorder\-this\-item\-md\-p/)
    		{
	    		$buyable = 1;
		    	$pre_order = 1;
		    	$ssof = 1;
		    }
		    if ($content =~ /amazon\-prime\-logo\-listings/)
		    {
		    	$prime = 1;	
		    }
		}
		else
		{
	    	if ($content =~ /btn\-preorder\.gif/)
    		{
	    		$buyable = 1;
		    	$pre_order = 1;
		    }			
		}
    }
    elsif ($is_ssof)
    {
    	if ($content =~ /add\-to\-cart\-md\-p/)
    	{
	    	$buyable = 1;
	    	$ssof = 1;
	    }

	    if ($content =~ /amazon\-prime\-logo\-listings/)
	    {
	    	$prime = 1;	
	    }
    }
    elsif ($content =~ /btn\-atc\.gif/)
    {
    	$buyable = 1;
    }
    
    if (! $prime && $content !~ /not eligible for Amazon Prime/i)
    {
    	$prime = 1;
    }
    
   	if ($content =~ /standard\-prime\-1\-click/)
   	{
   		$only_ships_standard = 1;	
   	}	
    
   	if ($content =~ /Order it in the next/)
   	{
   		$fast_trackable = 1;	
   	}	
    
    print $asin_status_fh "$asin\t\t$env\t$fast_trackable\t$prime\t$ssof\t$only_ships_standard\t$sold_by_amazon\t$pre_order\t$buyable\n";
}
close($asin_status_fh);
close($asin_fh);
