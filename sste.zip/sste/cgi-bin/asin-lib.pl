
$asin_data_file = "asinChecker/asins.flat";
$asin_status_data_file = "asinChecker/asins_current.flat";
$error_color = qq( bgcolor="#F0E68C");
my %valid_sub_actions = (
	"disp" => 1
);

sub asins
{
    
	if ($in{'sub_action'} && 1 == $valid_sub_actions{$in{'sub_action'}})
	{
		&{"$in{'action'}_$in{'sub_action'}"};
	}
	else
	{
	    &header("ASINs");
	    gen_title("SSTE - ASINs");
	    &nav;
	    &start_body;
		print <<EOF;
<form action="index.cgi" method="get">
<input type="hidden" name="action" value="$in{'action'}">
<input type="hidden" name="sub_action" value="disp">
<p>Please select the environment in which you will be testing.<br>
<input type="radio" name="env" value="d" checked>Development<br>
<input type="radio" name="env" value="p">Production<br>
<input type="submit" value="Continue &gt;&gt;" class="generic_submit_btn">
</form>		
EOF
    	&end_body;    
	    &footer;
	}
    
}

sub asins_disp
{
    &header("ASINs - Display");
    gen_title("SSTE - Display ASINs");
    &nav;
    &start_body;
	
	if ($in{'env'} ne "d" && $in{'env'} ne "p")
	{
		print qq(<p><b class="error">Error</b><br>The environment you selected is invalid.  Please
		<a href="index.cgi?action=asins">select another environment</a>.  Otherwise, if you feel
		you have reached this page in error, please contact <a href="mailto:jolo\@amazon.com">Josh
		Lopez</a>.</p>);
	}
	else
	{
		gen_asin_table($in{'env'});
	}
	
    &end_body;    
    &footer;
}

sub gen_asin_table
{
	my $env = shift;
	my %values = (1 => 'Yes', 0 => 'No');
	my %envs = ('d' => {
						'name' => 'Development',
						'url'  => 'development.amazon.com'
					   },
				'p' => {
						'name' => 'Production',
						'url'  => 'pre-prod.amazon.com'
					   }
		 		);

	my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
       $atime,$mtime,$ctime,$blksize,$blocks)
           = stat($asin_status_data_file);
	my $mod_time = localtime($mtime);

	# check for the override
	my $override_set = 1;
	if (! exists $in{'override'})
	{
		$override_set = 0;
		$in{'override'} = "development.amazon.com";	
	}

	print qq(<p>The following ASINs are available for testing on the
	<b><font color="#006600">$envs{$env}->{'name'}</font></b> site. 
	
	<p><center><table border="1" cellpadding="5" cellspacing="0"$error_color>
	<tr><td align="center">Denotes an Item Attribute Problem<br><span class="smltxt">Last Check: $mod_time</span></td></tr>
	</table></center></p>
	
	<form action="index.cgi" method="get">
		<input type="hidden" name="action" value="$in{'action'}">
		<input type="hidden" name="env" value="$in{'env'}">
		<input type="hidden" name="sub_action" value="$in{'sub_action'}">
	<p>Link Domain Override: <input type="text" size="40" name="override" value="$in{'override'}" maxlength="256" class="inputfield"> <input type="submit" value="Update &gt;&gt;" class="generic_submit_btn"><br>
	<table border="1" cellpadding="2" cellspacing="0">
		<tr class="headerrow" valign="bottom">
			<td align="center"><b>ASIN</b></td>
			<td align="center"><b>Description</b></td>
			<td align="center"><b>FT</b></td>
			<td align="center"><b>Prime<br>Eligible</b></td>
			<td align="center"><b>SSOF</b></td>
			<td align="center"><b>Std<br>Shipping<br>Only</b></td>
			<td align="center"><b>Sold<br>by<br>Amazon</b></td>
			<td align="center"><b>Pre-<br>Order</b></td>
			<td align="center"><b>Buyable</b></td>
			<td align="center"><b>Variational</b></td>
		</tr>
		<tbody>
	);
	my $count = 0;
	open($asin_data, $asin_data_file);
	open($asin_status_data, $asin_status_data_file);
	while (<$asin_data>)
	{
		my $asin_ref = parse_asin_data_row($_);

		# read in the current status of this ASIN
		my $asin_status_row = <$asin_status_data>;
		chomp($asin_status_row);
		my $asin_status_ref = parse_asin_data_row($asin_status_row);

		if ($asin_ref->{'env'} eq $env)
		{
			$count++;
			
			my ($temp_url, $olp_url, $dp_url);
			if ($override_set)
			{
				$temp_url = "http://$in{'override'}/gp/";
			}
			else
			{
				$temp_url = "http://$envs{$env}->{'url'}/gp/";
			}
			
			$olp_url = $temp_url."/offer-listing/$asin_ref->{'asin'}/";
			$dp_url = $temp_url."/product/$asin_ref->{'asin'}/";
			
			my $ft_status = ($asin_ref->{'ft'} == $asin_status_ref->{'ft'} ? "" : $error_color);
			my $prime_status = ($asin_ref->{'prime'} == $asin_status_ref->{'prime'} ? "" : $error_color);
			my $ssof_status = ($asin_ref->{'ssof'} == $asin_status_ref->{'ssof'} ? "" : $error_color);
			my $standard_status = ($asin_ref->{'standard'} == $asin_status_ref->{'standard'} ? "" : $error_color);
			my $amazon_status = ($asin_ref->{'amazon'} == $asin_status_ref->{'amazon'} ? "" : $error_color);
			my $preorder_status = ($asin_ref->{'pre-order'} == $asin_status_ref->{'pre-order'} ? "" : $error_color);
			my $buyable_status = ($asin_ref->{'buyable'} == $asin_status_ref->{'buyable'} ? "" : $error_color);
			my $variational_status = ($asin_ref->{'variational'} == $asin_status_ref->{'variational'} ? "" : $error_color);
			if ($asin_status_row eq "")
			{
				$ft_status = $prime_status = $ssof_status = $standard_status = $amazon_status = $preorder_status = $buyable_status = "";
			}

			print qq(<tr><td align="center" nowrap>$asin_ref->{'asin'}&nbsp;&nbsp;&nbsp;<a href="$dp_url" target="asinWin">DP</a>&nbsp;|&nbsp;<a href="$olp_url" target="asinWin">OLP</a></td>
				<td>$asin_ref->{'desc'}</td>
				<td align="center"$ft_status>$values{$asin_ref->{'ft'}}</td>
				<td align="center"$prime_status>$values{$asin_ref->{'prime'}}</td>
				<td align="center"$ssof_status>$values{$asin_ref->{'ssof'}}</td>
				<td align="center"$standard_status>$values{$asin_ref->{'standard'}}</td>
				<td align="center"$amazon_status>$values{$asin_ref->{'amazon'}}</td>
				<td align="center"$preorder_status>$values{$asin_ref->{'pre-order'}}</td>
				<td align="center"$buyable_status>$values{$asin_ref->{'buyable'}}</td>
				<td align="center"$variational_status>$values{$asin_ref->{'variational'}}</td>
			</tr>);	
		}
	}
	close($asin_data);
	
	if (! $count)
	{
		print qq(<tr><td colspan="8" align="center">No ASINs are available for testing on the specified environment.</td></tr>);	
	}
	print qq(</tbody></table></form></p>);
}

sub parse_asin_data_row
{
	my $row = shift;
	chomp($row);
	
	my @data = split(/\t/, $row);
	my %asin = (
		'asin' => $data[0],
		'desc' => $data[1],
		'env' => $data[2],
		'ft' => $data[3],
		'prime' => $data[4],
		'ssof' => $data[5],
		'standard' => $data[6],
		'amazon' => $data[7],
		'pre-order' => $data[8],
		'buyable' => $data[9],
		'variational' => $data[10]
	);
	
	return \%asin;
}

1;