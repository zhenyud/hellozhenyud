my %current_testSuite;

$run_tests_disp_sub_actions = 0;
%run_tests_sub_actions = (
	"disp" => 1,
	"initiate" => 1,
	"rerun" => 1
);

sub run_tests
{
	if ($in{'sub_action'} && 1 == $run_tests_sub_actions{$in{'sub_action'}})
	{
		&{"$in{'action'}_$in{'sub_action'}"};
	}
	else
	{	
    	&header("Run Tests");
    	gen_title("SSTE - Run Tests");
    	&nav;
        &start_body;
        
        my $login = get_cookie($user_id_cname);
        
        my $error_str;
        if (1 == $in{'error'})
        {
            $error_str = qq(<p><b><font color="#ff0000">Error</font></b><br>You must specify a username before continuing.</p>);
        }
        
	    print <<EOF;
	    <b class="md_title">Run Tests</b><br>
        Please choose from the three options below and provide your username.<br>
<form method="get" action="index.cgi" name="runTest">
	<input type="hidden" name="action" value="$in{'action'}">
	<input type="hidden" name="sub_action" value="disp">
	<blockquote>
	<p><b>Test Options</b><br>
	<input name="runTestOption" value="all" type="radio" checked="checked" />Run full regression<br>
  	<input name="runTestOption" value="devo" type="radio" />Run all (or some) of the test cases that can be run against Devo / developer's desktop<br>
  	<input name="runTestOption" value="prod" type="radio" />Run all (or some) of the test cases that can be run against Pre-prod / Prod
  	</p>$error_str
  	<p><table border="0" cellpadding="2" cellspacing="0">
  	    <tr>
  	        <td align="right"><b>Username:</b></td>
  	        <td><input type="text" name="login" value="$login" size="20" maxlength="64" class="inputfield" /></td>
  	    </tr>
  	    <tr>
  	        <td align="right" nowrap><b>Email&nbsp;Notification:</b></td>
  	        <td><select name="emailNotification"><option value="0">No</option><option value="1">Yes</option></select></td>
  	    </tr>
  	    <tr valign="top">
  	        <td align="right" nowrap><b>Max&nbsp;Sessions:</b></td>
  	        <td><select name="maxForkedChildren"><option>1</option><option>2</option><option selected>3</option></select>
  	        <br><li>Set to 3 if you are testing devo or pre-prod.
  	        <br><li>Use 2 or 1 when testing against developers' desktops.
  	        </td>
  	    </tr>
  	    <tr>
  	        <td align="right"><b>Weblab(s):</b></td>
  	        <td><input type="text" size="40" maxlength="500" name="weblab"></td>
  	    </tr>
  	    <tr>
  	        <td align="right"><b>PowerBar:</b></td>
  	        <td><input type="checkbox" name="powerbar" value="1"></td>
  	    </tr>
  	</table></p>
  	<p><input type="submit" value="Continue &gt;&gt;" class="generic_submit_btn" /></p>
  	</blockquote>
</form>
EOF

    	&end_body;    
    	&footer;    
	}
}


sub run_tests_disp
{
    if ($in{'login'} eq "")
    {
        # clear out the sub_action so that we don't loop infinitely
        delete $in{'sub_action'};
        
        # set an error flag
        $in{'error'} = '1';

        # call the parent function        
        &{$in{'action'}};

        return;
    }
    
    # save the login in a cookie for future use
    save_cookie($user_id_cname, $in{'login'});
    
	&header("Run Tests - Test Case Selection");
    gen_title("SSTE - Run Tests - Test Case Selection");

    &nav;
    &start_body;
	
	if ($in{'runTestOption'} ne "all" && $in{'runTestOption'} ne "devo" && $in{'runTestOption'} ne "prod")
	{
		print qq(<p><b class="error">Error</b><br>The option you selected is invalid.  Please
		<a href="index.cgi?action=config">select another option</a>.  Otherwise, if you feel
		you have reached this page in error, please contact <a href="mailto:prime-qa\@amazon.com">Prime QA</a>.</p>);
	}
	else
	{
		run_tests_display_testCases($in{'runTestOption'});
	}
	
    &end_body;    
    &footer;
}


sub run_tests_display_testCases
{
	my $env = shift;
	
	my $dbh = get_dbh();
	my $executionTimes = loadExecutionTimes($dbh, $in{'maxForkedChildren'});
	
	if ($in{'powerbar'} != 1)
	{
	    $in{'powerbar'} = 0;
	}
	
	print <<EOF;
<p><b class="md_title">Confirm Test Run Options</b><br>
You may specify an alternate testing environment.  Additionally, you can select which test suites and test cases
you wish to run using the checkboxes below.</p>

<form method="post" action="index.cgi" name="specifyEnv">
<input type="hidden" name="action" value="$in{'action'}">
<input type="hidden" name="login" value="$in{'login'}">
<input type="hidden" name="sub_action" value="initiate">
<input type="hidden" name="maxForkedChildren" value="$in{'maxForkedChildren'}">
<input type="hidden" name="emailNotification" value="$in{'emailNotification'}">
<input type="hidden" name="weblab" value="$in{'weblab'}">
<input type="hidden" name="powerbar" value="$in{'powerbar'}">
EOF

    if ($env eq "all")
    {
        print qq(<input name="runTestOption" value="all" type="hidden">);
        print qq(<p><b>Test Option:</b> Run a full regression<br>
                 <b>Estimated Execution Time:</b> $executionTimes->{'all'}</p>
                <p><input class="action_submit_btn" value="Initiate Test Run &gt;&gt;" type="submit"></p>
                <p>);
    }
    else
    {
        my $cookieHost = $env eq "devo" ? get_cookie($devo_host_cname) : get_cookie($prod_host_cname);
        my $cookiePort = $env eq "devo" ? get_cookie($devo_port_cname) : get_cookie($prod_port_cname);
        my $cookieSecurePort = $env eq "devo" ? get_cookie($devo_secure_port_cname) : get_cookie($prod_secure_port_cname);

        my $default_environment = $cookieHost || ($env eq "devo" ? "development.amazon.com" : "pre-prod.amazon.com");
        my $environment = $env eq "devo" ? +DEVO : +PROD;
        my $default_unsecure_port = $cookiePort || 80;
        my $default_secure_port = $cookieSecurePort || 443;
    
        print qq(
	        <p>The checked test cases will be running on:
	        <input type="hidden" name="environment" value="$environment">
	        <table border="0" cellpadding="2" cellspacing="0">
	            <tr>
	                <td align="right"><b>Host:</b></td>
	                <td><input type="text" size="40" maxlength="256" name="host" value="$default_environment" class="inputfield" /> (fully qualified)</td>
	            </tr>
	            <tr>
	                <td align="right"><b>HTTP Port:</b></td>
	                <td><input type="text" size="4" maxlength="5" name="httpPort" value="$default_unsecure_port" class="rinputfield" /></td>
	            </tr>
	            <tr>
	                <td align="right"><b>HTTPS Port:</b></td>
	                <td><input type="text" size="4" maxlength="5" name="httpsPort" value="$default_secure_port" class="rinputfield" /></td>
	            </tr>
	            <tr>
	                <td></td>
	                <td><input class="action_submit_btn" value="Initiate Test Run &gt;&gt;" type="submit"></td>
	            </tr>
	        </table></p>
	    );
	}
	
	if ($env eq "all")
	{
		print <<EOF;
<hr style="width: 100%; height: 2px;">
</form>
<br>
EOF
	}
	else
	{
		print <<EOF;
<hr style="width: 100%; height: 2px;">
<input class="generic_submit_btn" type="button" name="Check_All" value="UnCheck All" onClick="Check(document.specifyEnv.check_list)"><br><br>
EOF
	}

	my $tsRef = &loadTestSuiteHash;
    
    my @testSuites = keys %$tsRef;
    %ts = %$tsRef;
    
    my $testSuiteCount = 0;
	
	# print selected test suite and test cases
	foreach my $testSuite (sort keys %ts)
	{
		$testSuiteCount++;
		my $tsName = $testSuite;
		my $isMatch = 0;
		
		# check to see if we need to display this test suite
		%current_testSuite = %{$ts{$testSuite}};
		next unless $current_testSuite{'isEnabled'};
		
		foreach my $testCase (sort byTestCaseNumConfig keys %current_testSuite)
		{
		    next if $testCase eq "desc";
		    next if $testCase eq "env";
		    if ($ts{$testSuite}{$testCase}->{env} eq $env || $env eq "all" || $env eq "custom")
		    {
				$isMatch = 1;
				last;
			}		
   		}
		
		if ($isMatch)
		{
		    my $properTsName = $tsName;
		    $properTsName =~ s/^p/P/;
			print qq(&nbsp;&nbsp;<b>$properTsName:</b> );
			print qq(&nbsp;&nbsp;&nbsp;\(Avg Exec Time: $executionTimes->{$properTsName}\)<br>);
			print qq(&nbsp;&nbsp;<a href="javascript:toggleCheckboxes(document.specifyEnv.check_list, '$tsName');">toggle all</a><br>) if $env ne "all";
		
			# print the selected test cases in a test suite
			foreach my $testCase (sort byTestCaseNumConfig keys %current_testSuite)
			{
		    	next if $testCase eq "desc" || $testCase eq "isEnabled" || $testCase eq "env";
		   		if ($ts{$testSuite}{$testCase}->{env} eq $env || $env eq "all" || $env eq "custom")
		   		{
					print qq(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;);
					if ($env ne "all")
					{
						print qq(<input value="${tsName}_$ts{$testSuite}{$testCase}{num}" type="checkbox" checked="true" name="check_list">);
					}
					print qq($ts{$testSuite}{$testCase}{num}. $testCase<br>\n);
				}
   			}
   			print qq(<br>);
		}
	}
	print qq(<br><br>);
	if($env ne "all")
	{
		print qq(</form>);
	}
}


sub byTestCaseNumConfig
{
    if ($a eq "desc")
    {
        return -1;
    }
    elsif ($b eq "desc")
    {
        return 1;
    }
    else
    {
        return $current_testSuite{$a}{'num'} <=>  $current_testSuite{$b}{'num'};
    }
}

#-------------------------------------------------------------------------------
# run_tests_rerun
#
# This function handles generating a re-run of a previous test run.  There are
# several paramters that can be passed in via either GET or POST:
#   scope = all | failed --indicates whether we should re-run all or just the
#                          failed test suites (optional - defaults to failed)
#   parent_id = [1-9][0-9]* --ID of the parent test run
#   testRunSuiteId = [1-9][0-9]* --ID of the individual test suite to be re-run 
#                             (optional)
#
# After creating the new test run, the user is redirected back to the run detail
# page for the newly created test run.
#-------------------------------------------------------------------------------
sub run_tests_rerun
{
    my $dbh = get_dbh();

    # first, retrieve the parent test run
    my $retrieveParentQuery = $dbh->prepare("select * from testRuns where testRunId = ?");
    $retrieveParentQuery->execute($in{'parent_id'});
    
    # if no matching parent test runs were found, redirect the user back to the
    # queue and display a relevant error message
    if ($retrieveParentQuery->rows != 1)
    {
        # redirect to the test run queue page
        print "Location: http://$ENV{'SERVER_NAME'}/$script?action=report&error=3\n\n";        
        return;
    }

    # create a new test run using fields from the parent test run
    my $parentTestRun = $retrieveParentQuery->fetchrow_hashref();
    my $createNewTestRun = $dbh->prepare("insert into testRuns(emailNotification, maxForkedChildren, login, testRunStatus, testRunParentId) values(?, ?, ?, ?, ?)") or print $dbh->errstr;
    my $retrieveNewTestRunId = $dbh->prepare("SELECT LAST_INSERT_ID() AS id");
    $createNewTestRun->execute($parentTestRun->{'emailNotification'}, $parentTestRun->{'maxForkedChildren'}, $parentTestRun->{'login'}, retrieve_status_id($dbh, COMPLETED), $in{'parent_id'});
    $retrieveNewTestRunId->execute();
    my $id_result = $retrieveNewTestRunId->fetchrow_hashref();
    my $newTestRunId = $id_result->{'id'};
    $retrieveNewTestRunId->finish;
    $createNewTestRun->finish;

    # check to see if we actually created a new test run
    if ($newTestRunId == 0)
    {
        # redirect to the test run queue page
        print "Location: http://$ENV{'SERVER_NAME'}/$script?action=report&error=4\n\n";        
        return;        
    }

    # check to see if a testRunSuiteId has been passed in;
    # - if so, we are re-running an individual test suite
    # - otherwise, we are re-running one or more test suites
    if ($in{'testRunSuiteId'} > 0)
    {
        # load the original test suite to be re-run
        my $retrieveParentTestSuite = $dbh->prepare("SELECT * FROM testRunSuites where testRunSuiteId = ?");
        $retrieveParentTestSuite->execute($in{'testRunSuiteId'});
        
        if ($retrieveParentTestSuite->rows)
        {
            my $parentTestSuite = $retrieveParentTestSuite->fetchrow_hashref();
            
            # check to see whether we need to re-run just the failures or all of
            # the originally specified testcases
            my $testcases = ($in{'scope'} eq "all" ? $parentTestSuite->{'testcases'} : $parentTestSuite->{'failedTestcases'});

            # prepare the insertion SQL
            my $insertTestSuite = $dbh->prepare("INSERT INTO testRunSuites(testRunId, testSuiteName, testSuiteEnvId, testcases, testSuiteArguments, testSuiteStatus) values(?, ?, ?, ?, ?, ?)");

            # insert the new row
            $insertTestSuite->execute($newTestRunId, $parentTestSuite->{'testSuiteName'}, $parentTestSuite->{'testSuiteEnvId'}, $testcases, $parentTestSuite->{'testSuiteArguments'}, retrieve_status_id($dbh, PENDING));

            # clean up
            $insertTestSuite->finish;        
        }
        $retrieveParentTestSuite->finish;
    }
    else
    {
        my $retrieveParentTestSuite;

        # check to see whether we need to re-run just the failures or all of
        # the originally specified testcases
        if ($in{'scope'} eq "all")
        {
            # prepare a query to gather all test suites run under the parent test run
            $retrieveParentTestSuite = $dbh->prepare("SELECT * FROM testRunSuites where testRunId = ?");
        }
        else
        {
            # prepare a query to gather all test suites that had failures
            $retrieveParentTestSuite = $dbh->prepare("SELECT * FROM testRunSuites where (numFailed > 0 or numPassed = 0) and testRunId = ?");            
        }
        
        # prepare the insertion SQL
        my $insertTestSuite = $dbh->prepare("INSERT INTO testRunSuites(testRunId, testSuiteName, testSuiteEnvId, testcases, testSuiteArguments, testSuiteStatus) values(?, ?, ?, ?, ?, ?)");

        $retrieveParentTestSuite->execute($in{'parent_id'});
        while (my $parentTestSuite = $retrieveParentTestSuite->fetchrow_hashref())
        {
            # check to see whether we need to re-run just the failures or all of
            # the originally specified testcases
            my $testcases = ($in{'scope'} eq "all" ? $parentTestSuite->{'testcases'} : $parentTestSuite->{'failedTestcases'});
            $insertTestSuite->execute($newTestRunId, $parentTestSuite->{'testSuiteName'}, $parentTestSuite->{'testSuiteEnvId'}, $testcases, $parentTestSuite->{'testSuiteArguments'}, retrieve_status_id($dbh, PENDING));
        }
    
        # clean up the queries' result memory
        $retrieveParentTestSuite->finish;
        $insertTestSuite->finish;
    }

    # lastly, set the status of the new test run to pending so that it will be
    # executed by the engine
    my $updateTestRunStatus = $dbh->prepare("UPDATE testRuns SET testRunStatus = ? where testRunId = ?");;
    $updateTestRunStatus->execute(retrieve_status_id($dbh, PENDING), $newTestRunId);
    $updateTestRunStatus->finish;
    
    # redirect to the test run detail page
    print "Location: http://$ENV{'SERVER_NAME'}/$script?action=report&sub_action=view_run&testRunId=$newTestRunId\n\n";
}

sub run_tests_initiate
{
    if ($in{'login'} eq "")
    {
        delete $in{'sub_action'};
        $in{'error'} = 1;
        &{$in{'action'}};
        return;
    }
    
    # validate the maxForkedChildren input to make sure no one tries to do 
    # something malicious
    if ($in{'maxForkedChildren'} > 3 || $in{'maxForkedChildren'} < 1)
    {
        $in{'maxForkedChildren'} = 1;
    }

    # I need to add some logic here to initially create the test run as
    # completed so that the engine does not start executing the test before
    # all of the test suites have been added.  Then, once all test suites
    # have been added, we can set it back to PENDING to have the engine
    # pick it up.
    my $dbh = get_dbh();
    my $insert_tr_sth = $dbh->prepare("INSERT INTO testRuns(login, testRunStatus, maxForkedChildren, emailNotification) values(?, ?, ?, ?)") or print $dbh->errstr;
    my $retrieve_id_sth = $dbh->prepare("SELECT LAST_INSERT_ID() AS id") or print $dbh->errstr;
    
    # create the new test run in the database
    $insert_tr_sth->execute($in{'login'}, retrieve_status_id($dbh, COMPLETED), $in{'maxForkedChildren'}, $in{'emailNotification'}) or print $insert_tr_sth->errstr;
    
    # retrieve the ID of the newly created run
    $retrieve_id_sth->execute() or print $dbh->errstr;
    my $id_result = $retrieve_id_sth->fetchrow_hashref();
    $retrieve_id_sth->finish;
    $insert_tr_sth->finish;
    
    # build the standard and secure host strings
    my $arguments = "";
    if ($in{'host'} ne "pre-prod.amazon.com" && $in{'host'} ne "development.amazon.com"
        && $in{'host'} ne "www.amazon.com" && $in{'runTestOption'} ne "all")
    {
        my $standardServer = "http://$in{'host'}:$in{'httpPort'}";
        my $secureServer   = "https://$in{'host'}:$in{'httpsPort'}";
        $arguments .= " --standardServer=$standardServer --secureServer=$secureServer";
    }
    
    if ($in{'weblab'} ne "")
    {
        $arguments .= " --weblab=$in{'weblab'}";
    }
    if ($in{'powerbar'} == 1)
    {
        $arguments .= " --enablePowerBar";
    }
    
    # check to see if the host has been passed in; if so, store the values
    # in a cookie
    if ($in{'host'} ne "")
    {
        # save the host and port information in a cookie for future convenience
        if ($in{'environment'} eq PROD)
        {
            save_cookie($prod_host_cname, $in{'host'});
            save_cookie($prod_port_cname, $in{'httpPort'});
            save_cookie($prod_secure_port_cname, $in{'httpsPort'});
        }
        else
        {
            save_cookie($devo_host_cname, $in{'host'});
            save_cookie($devo_port_cname, $in{'httpPort'});
            save_cookie($devo_secure_port_cname, $in{'httpsPort'});            
        }
    }
    
    # insert rows for each test suite to be executed
    my $insert_ts_sth = $dbh->prepare("INSERT INTO testRunSuites(testRunId, testSuiteName, testSuiteEnvId, testcases, testSuiteArguments, testSuiteStatus) values(?, ?, ?, ?, ?, ?)");

    if ($in{'runTestOption'} eq "all")
    {
    	my $tsRef = &loadTestSuiteHash;
        
    	foreach my $testSuite (sort keys %$tsRef)
    	{
    	    next unless $tsRef->{$testSuite}{'isEnabled'};
    	    $insert_ts_sth->execute($id_result->{'id'}, $testSuite, $tsRef->{$testSuite}{'env'}, "all", $arguments, retrieve_status_id($dbh, +PENDING));
    	}
    }
    else
    {
        my @selected_cases = split(/\0/, $in{'check_list'});
        my %ts;

        foreach my $selected_case (@selected_cases)
        {
            my ($ts_name, $tc) = ($selected_case =~ /^(.*)\_([0-9]+)$/);
            
            $ts{$ts_name} .= ($ts{$ts_name} eq "" ? $tc : ",$tc");
        }
        
        foreach my $ts_name (sort keys %ts)
        {
    	    $insert_ts_sth->execute($id_result->{'id'}, $ts_name, $in{'environment'}, $ts{$ts_name}, $arguments, retrieve_status_id($dbh, PENDING));            
        }
    }

    # lastly, set the status of the new test run to pending so that it will be
    # executed by the engine
    my $updateTestRunStatus = $dbh->prepare("UPDATE testRuns SET testRunStatus = ? where testRunId = ?");;
    $updateTestRunStatus->execute(retrieve_status_id($dbh, PENDING), $id_result->{'id'});
    $updateTestRunStatus->finish;

    $insert_ts_sth->finish;

    # redirect to the reporting queue display
    print "Location: http://$ENV{'SERVER_NAME'}/$script?action=report\n\n";
}


1;
