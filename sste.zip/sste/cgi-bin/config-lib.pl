@months = qw(January February March April May June July August September October November December);

# root script
$script = "index.cgi";

# valid actions that can be passed into this script; this is a security feature
# that helps avoid malicious or invalid requests
%valid_actions = 
(
    "accounts" => 1,
    "asins" => 1,
    "dbtool" => 1,
    "report" => 1,
    "run_tests" => 1,
    "ts" => 1
);

%error_messages = (
    1 => "The test run could not be deleted because it is either executing or has been completed.",
    2 => "The test run has already been deleted.",
    3 => "Unable to re-run failed test cases because the initial test run could not be found.",
    4 => "Unable to create a new test run.  The database operation failed."
);

# status constants
use constant PENDING => 'In Queue';
use constant EXECUTING => 'Executing';
use constant COMPLETED => 'Completed';
use constant CANCELLED => 'Cancelled';

# environment constants
use constant DEFAULT => 0;
use constant DEVO => 1;
use constant PROD => 2;

# Cookie names
$user_id_cname = "user_id";
$devo_host_cname = "last_host";
$devo_port_cname = "port";
$devo_secure_port_cname = "secure_port";
$prod_host_cname = "prod_last_host";
$prod_port_cname = "prod_port";
$prod_secure_port_cname = "prod_secure_port";

#-------------------------------------------------------------------------------
# save_cookie
#
# This function writes a cookie to the header of the page that is currently
# being generated.  This must be called before the header is completed (e.g.
# before Content-type: text/html\n\n has been printed out).  Also, the cookies
# written will not take effect until the next page load.
#-------------------------------------------------------------------------------
sub save_cookie
{
    my ($cookie_name, $value) = @_;
    
    my $cookie = new CGI::Simple::Cookie(-name    => $cookie_name,
                                         -value   => $value,
                                         -expires => '+1M');

    print "Set-Cookie: $cookie\n";
}

#-------------------------------------------------------------------------------
# get_cookie
#
# This function fetches the cookie value from a cookie with the specified name.
#-------------------------------------------------------------------------------
sub get_cookie
{
    my $cname = shift;
    my %cookies = fetch CGI::Simple::Cookie;
    my $cookie_val = defined $cookies{$cname} ? $cookies{$cname}->value : "";
    return $cookie_val;
}

#-------------------------------------------------------------------------------
# retrieve_status_id
#-------------------------------------------------------------------------------
sub retrieve_status_id
{
    my ($dbh, $status_name) = @_;
    $dbh = &get_dbh;
    my $result = $dbh->selectrow_hashref("SELECT statusId FROM statusDefinitions WHERE statusName = ?", undef, $status_name) or die $DBI::errstr;
    return $result->{'statusId'};
}

1;