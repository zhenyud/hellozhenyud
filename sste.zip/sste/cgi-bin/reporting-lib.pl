use XML::Simple;
use Data::Dumper;
use Time::Local;

my %valid_sub_actions = (
    "cancel" => 1,
	"disp" => 1,
	"del_run" => 1,
	"view_run" => 1,
	"view_suite" => 1
);


#-------------------------------------------------------------------------------
# report_cancel
#
# This function cancels a test run and all of its associated test suites.
# It checks to ensure that runs and suites are not already completed before
# cancelling them.  
#
# Eventually, we need to add some mechanism by which a process goes out and 
# actually kills currently running test suites when the user issues a
# cancellation request.
#-------------------------------------------------------------------------------
sub report_cancel
{
    my $dbh = get_dbh();
    my $cancel_testRunSuites_sth = $dbh->prepare("UPDATE testRunSuites set testSuiteStatus = 4 where testRunId = ? and testSuiteStatus != 3");
    $cancel_testRunSuites_sth->execute($in{'testRunId'});
    $cancel_testRunSuites_sth->finish;
    
    my $cancel_testRun_sth = $dbh->prepare("UPDATE testRuns set testRunStatus = 4 where testRunId = ? and testRunStatus != 4");
    $cancel_testRun_sth->execute($in{'testRunId'});
    $cancel_testRun_sth->finish;

    print "Location: index.cgi?action=$in{'action'}&sub_action=$in{'referrer'}&testRunId=$in{'testRunId'}\n\n";
}
# end report_cancel


sub report_del_run
{
    my $dbh = get_dbh();

    my $tr_sth = $dbh->prepare("select statusName from statusDefinitions, testRuns where testRunStatus = statusId and testRunId = ?");
    $tr_sth->execute($in{'testRunId'});
    my $numResults = $tr_sth->rows; 
    my $tr_status_result = $tr_sth->fetchrow_hashref();
       
    if ($numResults == 1 && $tr_status_result->{'statusName'} eq PENDING)
    {
        $dbh->do("delete from testRunSuites where testRunId = ?", undef, $in{'testRunId'}) or print $dbh->errstr;
        $dbh->do("delete from testRuns where testRunId = ? and testRunStatus = ? limit 1", undef, $in{'testRunId'}, retrieve_status_id($dbh, PENDING())) or print $dbh->errstr;
    }
    elsif ($numResults == 0)
    {
        $err_code = 2;   
    }
    else
    {
        $err_code = 1;
    }
    
    print "Location: /?action=$in{'action'}&error=$err_code\n\n";
}

sub report_view_run
{
    my $dbh = get_dbh();

    # retrieve the general details for the test run
    my $retrieve_run_sth = $dbh->prepare("select maxForkedChildren, UNIX_TIMESTAMP(startTime) AS epochStart, creationTime, testRunId, testRunParentId, statusName, login, creationTime, startTime, endTime from testRuns, statusDefinitions where testRunStatus = statusId and testRunId = ?") or print $dbh->errstr;
    $retrieve_run_sth->execute($in{'testRunId'}) or print $dbh->errstr;
    my $testRun = $retrieve_run_sth->fetchrow_hashref();
    $retrieve_run_sth->finish;

    my $refreshSeconds = ($testRun->{'statusName'} eq EXECUTING || $testRun->{'statusName'} eq PENDING ? 15 : 0);
    my $refreshMessage = "";
    if ($refreshSeconds)
    {
        $refreshMessage = qq(<b><font color="#009900">This page will refresh every $refreshSeconds seconds</font></b>);
    }
    header("View Test Run", $refreshSeconds);
    gen_title("SSTE - View Test Run");
    &nav;
    &start_body;

    my $endTime = ($testRun->{'endTime'} ne "0000-00-00 00:00:00" ? $testRun->{'endTime'} : "N/A");
    my $startTime = ($testRun->{'startTime'} ne "0000-00-00 00:00:00" ? $testRun->{'startTime'} : "N/A");
    my $creationTime = $testRun->{'creationTime'};

    # hack to detect which host the user is running against
    my $oneTestSuiteQuery = $dbh->prepare("select testSuiteArguments from testRunSuites where testRunId = ? LIMIT 1");
    $oneTestSuiteQuery->execute($in{'testRunId'});
    my $environmentDetails = "";
    if ($oneTestSuiteQuery->rows == 1)
    {
        my $argTestSuite = $oneTestSuiteQuery->fetchrow_hashref();
        if ($argTestSuite->{'testSuiteArguments'} =~ /--standardServer=([^\s]+) --secureServer=([^\s]+)/)
        {
            my ($standardServer, $secureServer) = ($1, $2);
            $environmentDetails = qq(
                <tr>
                    <td align="right" bgcolor="#cccccc">Standard Server</td>
                    <td>$standardServer</td>
                </tr>
                <tr>
                    <td align="right" bgcolor="#cccccc">Secure Server</td>
                    <td>$secureServer</td>
                </tr>
            );
        }
    }
    $oneTestSuiteQuery->finish;

    # display the page title
    print qq(<p><b class="md_title">View Test Run #$in{"testRunId"}</b></p>);
    
    my ($parent, $children) = ('None', 'None');
    
    # check to see if this test run has a parent
    if ($testRun->{'testRunParentId'} > 0)
    {
        my $retrieveParentInfoQuery = $dbh->prepare("select creationTime from testRuns where testRunId = ?");
        $retrieveParentInfoQuery->execute($testRun->{'testRunParentId'});
        my $parentRun = $retrieveParentInfoQuery->fetchrow_hashref();
        $retrieveParentInfoQuery->finish;
        
        $parent = qq(<a href="index.cgi?action=report&sub_action=view_run&testRunId=$testRun->{'testRunParentId'}">$testRun->{'testRunParentId'}</a> - $parentRun->{'creationTime'});
    }
    
    # check to see if this test run has any children
    my $findChildrenQuery = $dbh->prepare("select testRunId, creationTime from testRuns where testRunParentId = ? order by testRunId desc");
    $findChildrenQuery->execute($in{'testRunId'});
    if ($findChildrenQuery->rows > 0)
    {
        $children = "";
        while (my $child = $findChildrenQuery->fetchrow_hashref())
        {
            $children .= qq(<a href="index.cgi?action=report&sub_action=view_run&testRunId=$child->{'testRunId'}">$child->{'testRunId'}</a> - $child->{'creationTime'}<br>);
        }
        $children =~ s/<br>$//;
    }
    $findChildrenQuery->finish;

    my $statusImage = "";
    my $executingImage = qq(<br><img src="http://images.amazon.com/images/G/01/nav2/images/loading-bar.gif" width="60" border="0" alt="Executing">);
    if ($testRun->{'statusName'} eq EXECUTING())
    {
        $statusImage = $executingImage;
    }
    
    if ($testRun->{'statusName'} eq EXECUTING() ||
        $testRun->{'statusName'} eq PENDING())
    {
        $cancelLink = qq( (<a href="?action=report&sub_action=cancel&testRunId=$testRun->{'testRunId'}&referrer=$in{'sub_action'}">Cancel</a>));            
    }

    print qq(    
    <p>
    <table border="0" cellpadding="10" cellspacing="0">
    <tr valign="top"><td>
    <b>General Information</b><br>
    <table border="0" cellpadding="2" cellspacing="1">
        <tr>
            <td align="right" bgcolor="#cccccc">Login</td>
            <td>$testRun->{'login'}</td>
        </tr>
        <tr>
            <td align="right" bgcolor="#cccccc">Max. Child Processes</td>
            <td>$testRun->{'maxForkedChildren'}</td>
        </tr>
        <tr>
            <td align="right" bgcolor="#cccccc">Creation Time</td>
            <td>$creationTime</td>
        </tr>
        <tr>
            <td align="right" bgcolor="#cccccc">Start Time</td>
            <td>$startTime</td>
        </tr>
        <tr>
            <td align="right" bgcolor="#cccccc">End Time</td>
            <td>$endTime</td>
        </tr>
$environmentDetails
        <tr>
            <td align="right" bgcolor="#cccccc">Status</td>
            <td>$testRun->{'statusName'}$cancelLink$statusImage</td>
        </tr>
    </table></td>
    <td>
    <b>Related Test Runs</b><br>
    <table border="0" cellpadding="2" cellspacing="1">
        <tr>
            <td align="right" bgcolor="#cccccc">Parent</td>
            <td>$parent</td>
        </tr>
        <tr valign="top">
            <td align="right" bgcolor="#cccccc">Children</td>
            <td>$children</td>
        </tr>
    </table>
    </td></tr></table>
    </p>
    <p>$refreshMessage</p>
    );

    # check to see if the test run has completed; if the test run has completed
    # and there were any failures, show the option to re-run the test suite
    my $dispReRunOption = 0;
    if ($testRun->{'statusName'} eq COMPLETED || $testRun->{'statusName'} eq CANCELLED)
    {
        print qq(<p><center><a href="index.cgi?action=run_tests&sub_action=rerun&scope=all&parent_id=$testRun->{'testRunId'}" class="rerun">Re-Run&nbsp;All</a>);
        my $numFailedQuery = $dbh->prepare("select * from testRunSuites where testRunId = ? and (numFailed > 0 or numPassed = 0)");
        $numFailedQuery->execute($in{'testRunId'});
        
        if ($numFailedQuery->rows > 0)
        {
            print qq(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.cgi?action=run_tests&sub_action=rerun&scope=failed&parent_id=$testRun->{'testRunId'}" class="rerun">Re-Run&nbsp;Failed</a>);
        }
        $numFailedQuery->finish;

        print qq(</b></center></p>);
    }

    
    if ($dispReRunOption)
    {
        print qq(<p><center><input type="submit" value="Re-Run Failed Testcases &gt;&gt;" class="generic_submit_btn"></center></p>);
    }
    
    print qq(    
    <p><b>Test Suites</b><br>
    Click on the title
    of any completed test suite to view detailed output and results.
    </p>
    
    <p><table border="1" cellpadding="2" cellspacing="0">
        <tr bgcolor="#cccccc" valign="bottom">
            <td align="center"><b>Name</b></td>
            <td align="center"><b>Test Cases</b></td>
            <td align="center"><b>Status</b></td>
            <td align="center"><b>Pass</b></td>
            <td align="center"><b>Fail</b></td>
            <td align="center"><b>Notes</b></td>
            <td align="center"><b>Options</b></td>
            <td align="center"><b>Exec<br>Time</b></td>
            <td align="center"><b>Avg<br>Exec<br>Time</b></td>
        </tr>
    );
    
    # retrieve the list of test suites to be executed within this test run
    my $retrieve_run_ts_sth = $dbh->prepare("select *, UNIX_TIMESTAMP(endTime)-UNIX_TIMESTAMP(startTime) as execTime, UNIX_TIMESTAMP(CURRENT_TIMESTAMP) - UNIX_TIMESTAMP(startTime) as cExecTime from testRunSuites, statusDefinitions where statusId = testSuiteStatus and testRunId = ? order by testSuiteName") or print $dbh->errstr;
    $retrieve_run_ts_sth->execute($in{'testRunId'}) or print $dbh->errstr;
 
    my $avgExecutionTime = loadExecutionTimes($dbh);
 
    while (my $testSuite = $retrieve_run_ts_sth->fetchrow_hashref())
    {
        my $originalTestSuiteName = $testSuite->{'testSuiteName'};
        $testSuite->{'testSuiteName'} =~ s/^prime/Prime/;
        my $report = "result/$testRun->{'login'}/$testRun->{'epochStart'}/$testSuite->{'testSuiteName'}/result.xml";
            
        my %failures;
   		my $notes;
        if (! -e $report && $testSuite->{'statusName'} eq COMPLETED)
   		{
   		    $notes = "Test appears to have been manually killed.";
   		}
   		
   		my $bgcolor = "#ffffff";
   		if ($testSuite->{'statusName'} eq COMPLETED)
   		{
   		    if ($testSuite->{'numFailed'} == 0 && $testSuite->{'numPassed'} > 0)
   		    {
   		        $bgcolor = "#ccff99";
   		    }
   		    elsif ($testSuite->{'numFailed'} == 0)
   		    {
   		        $bgcolor = "#ffff99";
   		    }
   		    else
   		    {
   		        if ($testSuite->{'failedTestcases'} =~ /^[^\,]+$/)
   		        {
       		        $notes .= "Failed&nbsp;test&nbsp;case:&nbsp;";
       		        $notes .= $testSuite->{'failedTestcases'};
       		    }
       		    else
       		    {
       		        $notes .= "Failed&nbsp;test&nbsp;cases:&nbsp;";
     		        $notes .= convert_csv_to_range($testSuite->{'failedTestcases'});
       		    }
       		    
   		        $bgcolor = "#ff9999";
   		    }
   		}
  		
  		my $testSuiteLink;
  		if ($testSuite->{'statusName'} eq COMPLETED)
  		{
       		$testSuiteLink = qq(<a href="/?action=$in{'action'}&sub_action=view_suite&testRunSuiteId=$testSuite->{'testRunSuiteId'}" class="tsLink">$testSuite->{'testSuiteName'}</a>);
       	}
       	else
       	{
       		$testSuiteLink = qq($testSuite->{'testSuiteName'});       	    
       	}
   		$testSuite->{'numPassed'} |= "0";
   		$testSuite->{'numFailed'} |= "0";
   		
   		# prettify the test case list so that we have 1-9 instead of 1,2,3,4,5,6,7,9
   		my $testcases = $testSuite->{'testcases'};
   		if ($testcases =~ /\,/)
   		{
            $testcases = convert_csv_to_range($testcases);
   		}
   		
   		my $statusImage = "";
   		my $executionTime = "&nbsp;";
   		if ($testSuite->{'statusName'} eq EXECUTING())
   		{
   		    $statusImage = $executingImage;
   		    $executionTime = parseExecutionSeconds($testSuite->{'cExecTime'});
   		}
   		elsif ($testSuite->{'statusName'} eq COMPLETED() ||
   		       $testSuite->{'statusName'} eq PENDING())
   		{
   		    $executionTime = parseExecutionSeconds($testSuite->{'execTime'});
   		}
        
        print qq(
        <tr bgcolor="$bgcolor">
            <td>$testSuiteLink</td>
            <td align="center">$testcases</td>
            <td>$testSuite->{'statusName'}$statusImage</td>
            <td align="right">$testSuite->{'numPassed'}</td>
            <td align="right">$testSuite->{'numFailed'}</td>
            <td>${notes}&nbsp;</td>
            <td nowrap="nowrap">
        );
        
        if ($testSuite->{'statusName'} eq +COMPLETED || $testSuite->{'statusName'} eq +CANCELLED)
        {
            print qq(<a href="index.cgi?action=run_tests&sub_action=rerun&testRunSuiteId=$testSuite->{'testRunSuiteId'}&parent_id=$in{'testRunId'}&scope=all">Re-Run&nbsp;All</a>);
            if ($testSuite->{'numFailed'} > 0)
            {
                print qq(&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="index.cgi?action=run_tests&sub_action=rerun&testRunSuiteId=$testSuite->{'testRunSuiteId'}&parent_id=$in{'testRunId'}&scope=failed">Re-Run&nbsp;Failed</a>);
            }
        }        
            
        print qq(&nbsp;</td><td align="center">$executionTime</td><td align="center">$avgExecutionTime->{$testSuite->{'testSuiteName'}}</td></tr>);
    }
 
    print qq(</table></p>);
  
    $retrieve_run_ts_sth->finish;    
    
    &end_body;
    &footer;
}




sub report_view_suite
{
    my $dbh = get_dbh();
    my $retrieve_run_ts_sth = $dbh->prepare("select UNIX_TIMESTAMP(testRuns.startTime) AS epochStart, login, testSuiteName, testRuns.testRunId from testRuns, testRunSuites where testRuns.testRunId = testRunSuites.testRunId and testRunSuiteId = ? ") or print $dbh->errstr;
    $retrieve_run_ts_sth->execute($in{'testRunSuiteId'}) or print $dbh->errstr;
    
    my $testSuiteInfo = $retrieve_run_ts_sth->fetchrow_hashref();
	my $login = $testSuiteInfo->{'login'};
	my $epochStart = $testSuiteInfo->{'epochStart'};
	my $currTestSuite = $testSuiteInfo->{'testSuiteName'};
	$currTestSuite =~ s/prime/Prime/;
	my $testRunId = $testSuiteInfo->{'testRunId'};

	if (!defined($in{'view_option'})){
		header("View Test Results", $refreshSeconds);
    	gen_title("SSTE - View Test Results");
    	&nav;
    	&start_body;

    
		print qq(<table cellpadding="2" cellspacing="0" width="100%">);
    	print qq(<tr><td valign="top">
    	<b class="md_title">${currTestSuite}</b><br>
    	<ul>
    	<li><a href = "/?action=$in{'action'}&sub_action=view_suite&testRunSuiteId=$in{'testRunSuiteId'}&view_option=result" target="testSuiteView">Test result report</a><br><br></li>
    	<li><a href = "/?action=$in{'action'}&sub_action=view_suite&testRunSuiteId=$in{'testRunSuiteId'}&view_option=log" target="testSuiteView">Log information</a><br><br></li>
    	<li><a href = "/?action=$in{'action'}&sub_action=view_suite&testRunSuiteId=$in{'testRunSuiteId'}&view_option=screen" target="testSuiteView">Screen shots</a><br><br></li>
    	<li><a href = "/?action=report&sub_action=view_run&testRunId=$testRunId">Go back</a>
    	</ul>
    	</td>);
    	
    	print qq(<td><iframe src ="/?action=$in{'action'}&sub_action=view_suite&testRunSuiteId=$in{'testRunSuiteId'}&view_option=result" name="testSuiteView" width="600" height="650">The test result</iframe></td></tr></table>);

    	&end_body;
	}elsif ($in{'view_option'} eq 'result' || $in{'view_option'} eq 'log' || $in{'view_option'} eq 'screen'){
		&simpleHeader;
		&{"report_view_suite_$in{'view_option'}"}($in{'testRunSuiteId'}, $login, $epochStart, $currTestSuite);
		&simple_end_body;
	}
	
	$retrieve_run_ts_sth->finish; 
}



sub report_view_suite_result
{
	my ($testRunSuiteId, $login, $epochStart, $currTestSuite) = @_;  
	    
    my $report = "result/${login}/${epochStart}/${currTestSuite}/result.xml";
    
    print qq(<table border="1" cellpadding="2" cellspacing="0" width="100%">);
    
    my $xml = new XML::Simple;
 	my $data = $xml->XMLin("$report");
 	
 	foreach my $main_xml_key (sort {$data->{$a}->{'TestCaseNum'} <=> $data->{$b}->{'TestCaseNum'}} keys %$data)
 	{
 		next unless $main_xml_key =~ /testCase([0-9]+)$/;
 		#my $testCaseNumber = $1;
 			    
 		#print out test case
 		print qq(
 		   	<tr bgcolor="#cccccc">
        		<td align="center"><b>$main_xml_key</b></td>
            	<td align="center"><b>$data->{$main_xml_key}->{'Description'}</b></td>
			</tr>
		);

		#print out each steps and each result for the test case
		my %stepHash = %{$data->{$main_xml_key}};	
 		
 		foreach my $xml_key (sort {$stepHash{$a}->{'SequenceNum'} <=> $stepHash{$b}->{'SequenceNum'}} keys %stepHash)
 		{
	 		if ($xml_key =~ /step[0-9]+/){
		 		print qq(
			 		<tr>
        				<td align="center">$xml_key</td>
            			<td align="left">$data->{$main_xml_key}->{$xml_key}->{'Description'}</td>
					</tr>
				);
			}elsif ($xml_key =~ /result[0-9]+/){			
				if($data->{$main_xml_key}->{$xml_key}->{'status'}->{'value'} eq "PASS"){
		 			print qq(
		 				<tr bgcolor="#ccff99">
		 				<td align="center">$xml_key</td>
            			<td align="left">$data->{$main_xml_key}->{$xml_key}->{'status'}->{'value'}: &nbsp $data->{$main_xml_key}->{$xml_key}->{'details'}->{'value'}</td>
					</tr>);
	 			}else{
		 			#get the html result page
		 			my $details = $data->{$main_xml_key}->{$xml_key}->{'details'}->{'value'};
		 			my @resultPageLink;
		 			if($details =~ /(\d+_\d+)/){
			 			my $pageNum = $1;
			 			my $pages = "result/${login}/${epochStart}/${currTestSuite}/".${pageNum}."_*.html";
			 			my @resultPage = glob $pages;
			 			$resultPageLink = "/".$resultPage[0];
			 			$details =~ s/Clicked nothing yet.//g;
			 			$details =~ s/</&lt;/g;
			 			$details =~ s/>/&gt;/g;
			 			$details =~ s/&lt;br&gt;//g;
			 			my $resultPageAnchor = "<b><a href=\"".${resultPageLink}."\" target=\"_blank\">".${pageNum}." click to view</a></b>";
			 			$details =~ s/$pageNum/$resultPageAnchor/;
		 			}
		 			print qq(
		 				<tr bgcolor="#ff9999">
		 				<td align="center">$xml_key</td>
            			<td align="left">$data->{$main_xml_key}->{$xml_key}->{'status'}->{'value'}: &nbsp $details</td>
					</tr>);
	 			}
			}
		}
	}

	print qq (</table>);
}



sub report_view_suite_screen
{
    my ($testRunSuiteId, $login, $epochStart, $currTestSuite) = @_;
    
    my $pages = "result/${login}/${epochStart}/${currTestSuite}/*.html";
    my @resultPages = glob $pages;

    print qq(<table border="1" cellpadding="2" cellspacing="0" width="100%">);
    my $last_tc = 0;
    foreach $page (sort by_tc_and_step @resultPages)
    {
        my ($tc) = ($page =~ /\/([0-9]+)_/);
        if ($tc != $last_tc)
        {
            print qq(</td></tr>) unless ! $last_tc;
            $last_tc = $tc;
            print qq(<tr><td align="center" bgcolor="#cccccc">Test&nbsp;Case&nbsp;$tc</td><td align="left">);
        }
        $page =~ /(\d+_\d+_\w+.html)/;
        print qq(<a href="/$page" class="pageLink" target="_blank">$1</a><br>);
    }
    print qq(</td></tr></table>);
}

sub by_tc_and_step
{
    my ($a_tc, $a_step) = ($a =~ /\/([0-9]+)\_([0-9]+)\_/);
    my ($b_tc, $b_step) = ($b =~ /\/([0-9]+)\_([0-9]+)\_/);
    return $a_tc <=> $b_tc unless $a_tc == $b_tc;
    return $a_step <=> $b_step;
}



sub report_view_suite_log
{
	my ($testRunSuiteId, $login, $epochStart, $currTestSuite) = @_;    
	
	my $logFile = "result/${login}/${epochStart}/${currTestSuite}/transcript.txt";
	open (FPTR,$logFile) || die "Can't Open Log File: $logFile\n";
	while (<FPTR>)
	{
		s/</&lt;/g;
		s/>/&gt;/g;
		s/FAIL!/<span style="background-color: #ff9999">FAIL!<\/span>/g;
		print qq($_<br>);
	}
	close(FPTR);
}


sub report
{
	if ($in{'sub_action'} && 1 == $valid_sub_actions{$in{'sub_action'}})
	{
		&{"$in{'action'}_$in{'sub_action'}"};
	}
	else
	{
    	header("Reporting", 15);
    	gen_title("SSTE - Reporting");
    	&nav;
    	&start_body;
    	
     	&disp_reportSearch;
     	
     	# check to see if an error id has been passed in; if so,
     	# display the corresponding error message
     	if ($in{'error'} > 0)
     	{
     	    print qq(<p class="error"><b>ERROR</b><br>$error_messages{$in{'error'}}</p>);
     	}
     	
     	&disp_queue;
       	
       	&end_body;    
    	&footer;
	}
}


sub report_disp
{
    # save the login in a cookie for future use
    save_cookie($user_id_cname, $in{'login'});

	&header("Reporting - Display");
    gen_title("SSTE - Display Report");

    &nav;
    &start_body;
    
    # first part is still presenting the search form
    &disp_reportSearch;
    
   	my $startDate = "$months[$in{'startMonth'} - 1] $in{'startDay'}, $in{'startYear'}";
   	my $endDate = "$months[$in{'endMonth'} - 1] $in{'endDay'}, $in{'endYear'}";
    my $startEpoch = timelocal(0,0,0,$in{'startDay'}, $in{'startMonth'} - 1, $in{'startYear'} - 1900); 
    my $endEpoch = timelocal(59,59,23,$in{'endDay'}, $in{'endMonth'} - 1, $in{'endYear'} - 1900);

    my $dbh = get_dbh();
    my $results_sth = $dbh->prepare("SELECT *, UNIX_TIMESTAMP(endTime) - UNIX_TIMESTAMP(startTime) as executionTime from testRuns, statusDefinitions where testRunStatus = statusId and startTime > FROM_UNIXTIME(?) and startTime < FROM_UNIXTIME(?) and login = ? order by testRunId desc");
    $results_sth->execute($startEpoch, $endEpoch, $in{'login'}) or print "Error executing query: ".$dbh->errstr;

    my $numResults = $results_sth->rows;

    print qq(<p><b class="md_title">Search Results</b><br>
    Your search for test results executed by <b class="highlight">$in{'login'}</b> between <b class="highlight">$startDate and $endDate</b> produced <b class="highlight">$numResults</b> results.</p>
    );

    print qq(<p>
    <table border="1" cellpadding="2" cellspacing="0" width="100%">
        <tr bgcolor="#cccccc">
            <td align="center"><b>Options</b></td>
            <td align="center"><b>ID</b></td>
            <td align="center"><b>Login</b></td>
            <td align="center"><b>Status</b></td>
            <td align="center"><b># Test Suites</b></td>
            <td align="center"><b>Creation Time</b></td>
            <td align="center"><b>Execution Time</b></td>
        </tr>
    );

    # prepare the SQL that will show us how many test suites need to be executed in each run
    my $num_suites_sth = $dbh->prepare("select count(*) as numSuites from testRunSuites where testRunId = ?") or print $dbh->errstr;
    
    while (my $testRun = $results_sth->fetchrow_hashref())
    {
        my $executionTime = ($testRun->{'statusName'} ne PENDING ? parseExecutionSeconds($testRun->{'executionTime'}) : "Not Started");
        my $creationTime = $testRun->{'creationTime'};
        $num_suites_sth->execute($testRun->{'testRunId'});
        my $num_suites_result = $num_suites_sth->fetchrow_hashref();

        # determine what options should be presented for this run
        my $options = qq(<a href="/?action=$in{'action'}&sub_action=view_run&testRunId=$testRun->{'testRunId'}">View</a>);

        if ($testRun->{'statusName'} ne +COMPLETED && 
            $testRun->{'statusName'} ne +CANCELLED)
        {
            $options .= qq(&nbsp | &nbsp;<a href="/?action=$in{'action'}&sub_action=cancel&testRunId=$testRun->{'testRunId'}" class="del_link" onClick="return confirm('Are you sure that you wish to cancel this run?');">Cancel</a>);
        }

        if (PENDING eq $testRun->{'statusName'})
        {
            $options .= qq(&nbsp; | &nbsp;<a href="/?action=$in{'action'}&sub_action=del_run&testRunId=$testRun->{'testRunId'}" class="del_link" onClick="return confirm('Are you sure that you wish to delete this run?');">Delete</a>);
        }

        print qq(<tr>
                    <td align="center">$options</td>
                    <td align="center">$testRun->{'testRunId'}</td>
                    <td align="center">$testRun->{'login'}</td>
                    <td align="right">$testRun->{'statusName'}</td>
                    <td align="right">$num_suites_result->{'numSuites'}</td>
                    <td align="right">$creationTime</td>
                    <td align="center">$executionTime</td>
                 </tr>);
    }
    $num_suites_sth->finish;
    $results_sth->finish;
    print qq(</table></p>);
    
    # display error message if no report is found
    if (! $numResults)
    {
	    print qq(<p><b>Note:</b> Please try changing your search parameters to produce more results.</p>);
    }

    &end_body;    
    &footer;

}

sub disp_reportSearch
{
    my $login;
   
    if (defined $in{'login'})
    {
        $login = $in{'login'};   
    }
    else
    {
        $login = get_cookie($user_id_cname);
        $in{'login'} = $login;  # needed by disp_queue
    }
    
    print qq(<form method="get" action="index.cgi" name="searchReport">
            <input type="hidden" name="action" value="$in{'action'}">	
            <input type="hidden" name="sub_action" value="disp">
    <b class="md_title">Search Reports</b><br>
    <table border="0" cellpadding="2" cellspacing="0">
        <tr>
            <td align="right"><b>Login:</b></td>
            <td><input class="inputfield" type="text" name="login" value="$login"></td>
        </tr>
        <tr>
            <td align="right"><b>Run Between:</b></td>
            <td>
    );
    print_dateSelection("start");
	print qq( &nbsp;and&nbsp; );
	print_dateSelection("end");
	print qq(</td></tr><tr><td></td><td><input type="submit" value="Search &gt;&gt;" class="generic_submit_btn" /></td></tr></table> </form>
	);
}

sub print_dateSelection
{
	my $dataType = shift;
	
	# get current time as selected default
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    $year = $year + 1900;
    $mon = $mon + 1;
	
    if($dataType eq "start"){
    	if(defined $in{'startYear'}){
	    	$year = $in{'startYear'};
    	}
    	if(defined $in{'startMonth'}){
	    	$mon = $in{'startMonth'};
    	}
    	if(defined $in{'startDay'}){
	    	$mday = $in{'startDay'};
   	 	}
	}
	if($dataType eq "end"){
    	if(defined $in{'endYear'}){
	    	$year = $in{'endYear'};
    	}
    	if(defined $in{'endMonth'}){
	    	$mon = $in{'endMonth'};
    	}
    	if(defined $in{'endDay'}){
	    	$mday = $in{'endDay'};
   	 	}
	}
	
    print qq(<select name="${dataType}Month" class="inputfield">);
    for ($i = 1; $i < 13; $i++){
	    if($i == $mon){
		    print qq(<option value="$i" selected>$months[$i - 1]</option>);
	    }else{
			print qq(<option value="$i">$months[$i - 1]</option>);
		}
	}
	print qq(</select>&nbsp;&nbsp;);	
	
    print qq(<select name="${dataType}Day" class="inputfield">);
    for ($i = 1; $i < 32; $i++){
	    if($i eq $mday){
		    print qq(<option value="$i" selected>$i</option>);
	    }else{
			print qq(<option value="$i">$i</option>);
		}
	}
	print qq(</select>&nbsp;&nbsp;);

	print qq(<select name="${dataType}Year" class="inputfield">);
    for ($i = 2007; $i < 2013; $i++){
	    if($i == $year){
		    print qq(<option value="$i" selected>$i</option>);
	    }else{
			print qq(<option value="$i">$i</option>);
		}
	}
	print qq(</select>);
}

sub disp_queue
{
    my $dbh = get_dbh();
    my $queue_sth = $dbh->prepare("select *, UNIX_TIMESTAMP(endTime) - UNIX_TIMESTAMP(startTime) as executionTime from testRuns, statusDefinitions where testRunStatus = statusId and DATE_SUB(CURDATE(),INTERVAL 0.5 DAY) <= creationTime order by testRunId DESC") or print $dbh->errstr;
    $queue_sth->execute() or print $dbh->errstr;
    my $num_results = $queue_sth->rows;
    
    return unless $num_results;

    # prepare the SQL that will show us how many test suites need to be executed in each run
    my $num_suites_sth = $dbh->prepare("select count(*) as numSuites from testRunSuites where testRunId = ?") or print $dbh->errstr;
    
    print qq(<p><b class="md_title">SSTE Test Queue</b><br>
    <table border="1" cellpadding="2" cellspacing="0" width="100%">
        <tr bgcolor="#cccccc">
            <td align="center"><b>Options</b></td>
            <td align="center"><b>ID</b></td>
            <td align="center"><b>User</b></td>
            <td align="center"><b>Status</b></td>
            <td align="center"><b># Test Suites</b></td>
            <td align="center"><b>Creation Time</b></td>
            <td align="center"><b>Execution Time</b></td>
        </tr>
    );

    my $executingImage = qq(<br><img src="http://images.amazon.com/images/G/01/nav2/images/loading-bar.gif" width="60" border="0" alt="Executing">);

    while (my $queue_row = $queue_sth->fetchrow_hashref())
    {
        my $executionTime = ($queue_row->{'statusName'} ne PENDING ? parseExecutionSeconds($queue_row->{'executionTime'}) : "Not Started");
        my $creationTime = $queue_row->{'creationTime'};
        $num_suites_sth->execute($queue_row->{'testRunId'});
        my $num_suites_result = $num_suites_sth->fetchrow_hashref();

        # determine what options should be presented for this run
        my $options = qq(<a href="/?action=$in{'action'}&sub_action=view_run&testRunId=$queue_row->{'testRunId'}">View</a>);

        if ($queue_row->{'statusName'} ne COMPLETED && 
            $queue_row->{'statusName'} ne CANCELLED)
        {
            $options .= qq(&nbsp | &nbsp;<a href="/?action=$in{'action'}&sub_action=cancel&testRunId=$queue_row->{'testRunId'}" class="del_link" onClick="return confirm('Are you sure that you wish to cancel this run?');">Cancel</a>);
        }

        if (PENDING eq $queue_row->{'statusName'})
        {
            $options .= qq(&nbsp; | &nbsp;<a href="/?action=$in{'action'}&sub_action=del_run&testRunId=$queue_row->{'testRunId'}" class="del_link" onClick="return confirm('Are you sure that you wish to delete this run?');">Delete</a>);
        }

        my $bgcolor = "#ffffff";
        $bgcolor = "#ccffcc" if ($queue_row->{'statusName'} eq COMPLETED);
        $bgcolor = "#eeeeee" if ($queue_row->{'statusName'} eq CANCELLED);


        my $statusImage = "";
        if ($queue_row->{'statusName'} eq EXECUTING)
        {
            $statusImage = "<br>$executingImage";
        }

        print qq(<tr bgcolor="$bgcolor">
                    <td align="center">$options</td>
                    <td align="center">$queue_row->{'testRunId'}</td>
                    <td align="center">$queue_row->{'login'}</td>
                    <td align="center">$queue_row->{'statusName'}$statusImage</td>
                    <td align="right">$num_suites_result->{'numSuites'}</td>
                    <td align="right">$creationTime</td>
                    <td align="center">$executionTime</td>
                 </tr>);
    }
    print qq(</table></p>);

    $num_suites_sth->finish;
    $queue_sth->finish;
}

sub as_numbers
{
    return $a <=> $b;
}

sub loadExecutionTimes
{
    my ($dbh, $numThreads) = @_;
    $numThreads |= 1;
    my $avgExecution_sth = $dbh->prepare("select testSuiteName, avg(UNIX_TIMESTAMP(endTime) - UNIX_TIMESTAMP(startTime)) as avgExecutionTime from testRunSuites where testSuiteStatus = 3 and numPassed + numFailed > 0 and testcases = 'all' and startTime > 0 and endTime > 0 group by testSuiteName");
    $avgExecution_sth->execute;
    
    my %avgExecutionTimes;
    my $totalExecutionTime = 0;
    while (my $avgExecution_row = $avgExecution_sth->fetchrow_hashref())
    {
        $avgExecution_row->{'testSuiteName'} =~ s/^p/P/;
        $totalExecutionTime += $avgExecution_row->{'avgExecutionTime'};
        $avgExecutionTimes{$avgExecution_row->{'testSuiteName'}} = parseExecutionSeconds($avgExecution_row->{'avgExecutionTime'});
    }
    $avgExecutionTimes{'all'} = parseExecutionSeconds($totalExecutionTime / $numThreads);
    return \%avgExecutionTimes;
}

sub parseExecutionSeconds
{
    my $executionEpoch = shift;
    $executionEpoch = 0 if ($executionEpoch < 0);
    $executionEpoch |= "0";
   	$executionEpoch = sprintf("%d", $executionEpoch);
   	
    my $executionSeconds = sprintf("%02d", $executionEpoch % 60);
    my $executionMinutes = sprintf("%02d", int(($executionEpoch % 3600) / 60));
    my $executionHours = sprintf("%02d", int($executionEpoch / 3600)); 
           
    my $executionTime = "$executionMinutes:$executionSeconds";
    if ($executionHours ne "00")
    {
        $executionTime = "$executionHours:$executionTime";
    }
    elsif ($executionTime eq "00:00")
    {
        $executionTime = "&nbsp;";
    }

    return $executionTime;
}

#-------------------------------------------------------------------------------
# convert_csv_to_range
#
# This function takes a string of the form 1,8,2,12,3,9,10 and converts it to
# 1-3,8-10,11.
#-------------------------------------------------------------------------------
sub convert_csv_to_range
{
    my $testcases = shift;
    my $newTestcaseList;
    my $currStart = 0;
    my $lastSeen  = 0;
    my @sortedTestcases = sort as_numbers split(/\,/, $testcases);
    foreach my $testcase (@sortedTestcases)
    {
        if ($currStart == 0)
        {
            $currStart = $testcase;
            $lastSeen = $testcase;
            next;
        }
        
        if ($testcase - $lastSeen == 1)
        {
            $lastSeen = $testcase;
            next;
        }
        else
        {
            if ($currStart != $lastSeen)
            {
                $newTestcaseList .= "${currStart}-${lastSeen},";
            }
            else
            {
                $newTestcaseList .= "${currStart},";
            }
            $currStart = $testcase;
            $lastSeen = $testcase;
        }
    }
    
    if ($currStart != $lastSeen)
    {
        $newTestcaseList .= "${currStart}-${lastSeen}";
    }
    else
    {
        $newTestcaseList .= "${currStart}";
    }
   return $newTestcaseList;
}

1;