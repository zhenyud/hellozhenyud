
sub end_body
{
    print <<EOF;
</td></tr>
<tr><td bgcolor="#cccccc"><center>Created and maintained by <a href="mailto:prime-qa\@amazon.com">Prime QA</a></font></center></td></tr>
</table>
EOF
}


sub simple_end_body
{
	print qq(</body></html>);
}

sub footer
{
    print <<EOF;
</body>
</html>    
EOF
}

sub gen_title
{
    my $page_title = shift;
    
    print qq(<table border="0" cellpadding="5" cellspacing="0" width="100%" bgcolor="#000000">
    <tr><td width="100%"><b class="lg_title">$page_title</b></td></tr></table>);
}

sub header
{
    my ($title, $refreshSeconds) = @_;
 
    $title = " - $title" if ($title ne "");
 
    my $metaRefresh = ($refreshSeconds ? qq(<meta http-equiv="refresh" content="$refreshSeconds" />) : "");
    
    print <<EOF;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
    <title>SSTE$title</title>
    <link rel="stylesheet" href="/css/main.css" type="text/css">
    $metaRefresh
EOF

	if ($in{'action'} eq 'run_tests' && $in{'sub_action'} eq 'disp')
	{
		print <<EOF;
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function Check(chk)
{
    if (document.specifyEnv.Check_All.value == "Check All")
    {
        for (var i = 0; i < chk.length; i++)
        {
            chk[i].checked = true;
        }
        document.specifyEnv.Check_All.value = "UnCheck All";
    }
    else
    {
        for (var i = 0; i < chk.length; i++)
        {
            chk[i].checked = false;
        }
        document.specifyEnv.Check_All.value = "Check All";
    }
}

function toggleCheckboxes(checkBoxes, tsName)
{
    for (var ii = 0; ii < checkBoxes.length; ii++)
    {
        var matchPosition = 0;
        matchPosition = checkBoxes[ii].value.indexOf(tsName + "_");
        if (matchPosition == 0)
        {
            checkBoxes[ii].checked = ! checkBoxes[ii].checked;
        }
    }
}

// End -->
</script>

EOF
	}
	
	print <<EOF;
</head>
<body bgcolor="#cccccc" margin="0" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0">
EOF
}


sub simpleHeader
{
	print <<EOF;
Content-type: text/html

		<html>
		<head>
    		<link rel="stylesheet" href="/css/main.css" type="text/css">
    	</head>
    <body>

EOF
	
}

sub nav
{
    print qq(<table border="0" cellpadding="2" cellspacing="0" width="100%" bgcolor="#666666"><tr><td width="100%">);
    
    my %nav_items = (
        "Test Suites" => "ts",
        "Run Tests" => "run_tests",
        "Reporting" => "report",
        "ASINs" => "asins",
        "Accounts" => "accounts",
        "DB Tool" => "dbtool"
    );
    
    foreach $link_txt ("Test Suites", "Run Tests", "Reporting", "ASINs", "Accounts", "DB Tool")
    {
        my $nav_class = ($in{'action'} eq $nav_items{$link_txt} ? "navselected" : "nav");
        print qq(<a href="index.cgi?action=$nav_items{$link_txt}" class="$nav_class">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$link_txt&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>);
    }
    
    print qq(</td></tr></table>);
    
    # check to see if an action has been selected; if one has, check to see
    # if there are sub actions; if so, display them in a sub menu
    if ($in{'action'} ne "" && ${"$in{'action'}_disp_sub_actions"} == 1)
    {
        print qq(<table border="0" cellpadding="2" cellspacing="0" width="100%" bgcolor="#999999"><tr><td width="100%">);
        foreach my $sub_action (sort keys %{"$in{'action'}_sub_actions"})
        {
            my $link_txt = ${"$in{'action'}_sub_actions"}{$sub_action};
            if ($in{'sub_action'} ne $sub_action)
            {
                print qq(<a href="index.cgi?action=$in{'action'}&sub_action=$sub_action" class="subnav">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$link_txt&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>);            
            }
            else
            {
                print qq(<span class="subnavsel">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$link_txt&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>);
            }
            
        }
        print qq(</td></tr></table>);
    }
}

sub start_body
{
    print <<EOF;
<table border="0" cellpadding="20" cellspacing="0" width="740" bgcolor="#ffffff">
<tr><td width="740">  
EOF
}


1;