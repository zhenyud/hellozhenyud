my %current_ts;

%envs = (
    "devo" => "devo",
    "prod" => "pre-prod/prod"
);

sub ts
{
    &header("Test Suites");
    gen_title("SSTE - Test Suites");
    &nav;
    &start_body;

    # all the assignments below will be replaced by module calls
    my $tsRef = &loadTestSuiteHash;
    #use Data::Dumper qw(Dumper);
    #print "<!--".Dumper($tsRef)."-->";
    
    my @testSuites = keys %$tsRef;
    my $numTestSuite = $#testSuites + 1;
    my $numTestCase = 0;
    my %ts = %$tsRef;
    for (my $testSuiteIndex = 0; $testSuiteIndex <= $#testSuites; ++$testSuiteIndex)
    {
        my @testCases = keys %{$tsRef->{$testSuites[$testSuiteIndex]}};
        $numTestCase += $#testCases unless $#testCases <= 0;
    }	
		  
	print qq(<p><b><font color="#666666">There are total $numTestSuite test suites and $numTestCase test cases</font></b></p>);
	
	my $testSuiteCount = 0;
	
	# print a table for each test suite
	foreach my $testSuite (sort keys %ts)
	{
		$testSuiteCount++;
		my $tsName = $testSuite;
		print <<EOF;
<p><a href="#" onClick="return toggleMenu('menu$testSuiteCount', $testSuiteCount)" class="tstitle"><img src="/images/right-icon-small-arrow.gif" alt="" border="0" name="ts$testSuiteCount" width="11" height="11"> <b>$tsName</b></a>
<span class="menu" id="menu$testSuiteCount">
<br><b>Description:</b> $ts{$testSuite}{'desc'}
    <table style="width: 860px;" border="1" cellpadding="2" cellspacing="0">
        <thead>
            <tr bgcolor="#cccccc">
                <td width="200" colspan="2"><b>Test Cases</b></td>
                <td width="400"><b>Description</b></td>
                <td width="120"><b>Environment</b></td>
                <td width="140"><b>Operation Type</b></td>
            </tr>        
        </thead>
        <tbody>
EOF
		
		%current_ts = %{$ts{$testSuite}};
		foreach my $testCase (sort byTestCaseNum keys %current_ts)
		{
		    next if $testCase eq "desc" || $testCase eq "isEnabled" || $testCase eq "env";
			print qq(<tr valign="top"><td align="right"><b>$ts{$testSuite}{$testCase}{num}</b></td><td>$testCase</td>);
			print qq(<td style="vertical-align: top;">$ts{$testSuite}{$testCase}->{desc});
	
    		# print use cases if there is any
    		if (exists $ts{$testSuite}{$testCase}{usecases})
    		{
			    print "<br>";
	    		my $usecaseNum = 0;
	    		foreach my $usecase (@{$ts{$testSuite}{$testCase}{usecases}})
	    		{
					$usecaseNum++;
			    	print qq(use case $usecaseNum: $usecase);
		    	}
		    }

		    # print the env and type
		    print qq(</td><td>$ts{$testSuite}{$testCase}->{env}</td>);
		    print qq(<td>$ts{$testSuite}{$testCase}->{type}</td></tr>);
		    		
   		}
		print qq(</tbody></table></span></p>);
	}
	
	
    print <<EOF;
<SCRIPT TYPE="TEXT/JAVASCRIPT" LANGUAGE="JAVASCRIPT">
<!--
	function toggleMenu(currMenu, tsNumber)
	{
		if (document.getElementById)
		{
			this.Menu = document.getElementById(currMenu).style;
			if (this.Menu.display == "block")
			{
				this.Menu.display = "none";
                document.images["ts"+tsNumber].src = '/images/right-icon-small-arrow.gif';
			}
			else
			{
				this.Menu.display = "block";
                document.images["ts"+tsNumber].src = '/images/drop-down-icon-small-arrow.gif';
			}
		}
		return false;
	}
//-->
</SCRIPT>
<STYLE TYPE="TEXT/CSS"><!--
	.menu  {display:none; margin-left: 13px}
	.tstitle { text-decoration: none; color: #000066; }
//--></STYLE>
EOF
   
    &end_body;    
    &footer;
}

sub byTestCaseNum
{
    if ($a eq "desc")
    {
        return -1;
    }
    elsif ($b eq "desc")
    {
        return 1;
    }
    else
    {
        return $current_ts{$a}{'num'} <=>  $current_ts{$b}{'num'};
    }
}

sub loadTestSuiteHash
{
    # determine the base source code directory for all of the Prime test suites
    my $baseDir = "/workplace";
    my $ssteDir = $baseDir;
    my $configDir = $baseDir;
    opendir(BASEDIR, $baseDir) or print "Unable to open $baseDir: $!\n";
    while (defined(my $filename = readdir(BASEDIR)))
    {
        if ($filename =~ /PrimeTests/)
        {
            $baseDir .= "/$filename/src/appgroup/OrderingQA/apps/PrimeTests/sctestcases/src/amazon/qa/sellercentral/autoWeb/primeTest";
            $configDir .= "/$filename/src/appgroup/OrderingQA/apps/PrimeTests/configuration";
        }
        elsif ($filename =~ /SSTE/)
        {
            $ssteDir .= "/$filename/src/appgroup/primeclub/apps/SSTEUserInterface/commentHarvester/data";
        }
    }
    close(BASEDIR);
    
    # load the runnable configuration to determine which test suites are runnable
    my %isEnabled = ();
    open(CONFIG, "$configDir/runnableTestSuites.config") or print "Unable to open $configDir/runnableTestSuites.config: $!";
    while (<CONFIG>)
    {
        chomp;
        if (/^(Prime[^\s]+)\s*=\s*(true|false)\s*$/i)
        {
            my ($testSuiteName, $enabled) = ($1, $2);
            $isEnabled{$testSuiteName} = ($enabled =~ /true/i ? 1 : 0);
        }       
    }
    close(CONFIG);
    
    # re-open basedir using the true base directory
    my %testSuites;
    opendir(BASEDIR, $baseDir) or print "Unable to open $baseDir: $!\n";
    while (defined(my $sourceDir = readdir(BASEDIR)))
    {
        next unless (-d "$baseDir/$sourceDir" && $sourceDir =~ /^prime/);
        my %testSuite;
        $testSuites{$sourceDir} = \%testSuite;
        my $sourceFilename = $sourceDir."_TestSuite.java";
        $sourceFilename =~ s/prime/Prime/;
        my $properTestSuiteName = $sourceDir;
        $properTestSuiteName =~ s/^prime/Prime/;
        $properTestSuiteName .= "_TestSuite";
        $testSuite{'isEnabled'} = $isEnabled{$properTestSuiteName};

        my $testSuiteMasterEnv = DEVO();
        my $testCaseNumber = "";
        my $testCaseType = "";
        my $testCaseEnv = "";
        $testSuite{'desc'} = "";
        open(SOURCE, "$baseDir/$sourceDir/$sourceFilename") or print "Unable to open $baseDir/$sourceDir/$sourceFilename: $!\n";
        my $parseState = 0;
        my $in_comment = 0;
        my $current_comment = 0;
        while (<SOURCE>)
        {
            chomp;
            
            # check for the start of the test suite comment block
            if ($parseState == 0 && /\/\*\*/)
            {
                $parseState = 1;
            }
            # check to see if we are still in the main test suite comment block
            elsif ($parseState == 1 && ! /\*\//)
            {
                next if (/\@author/);
                next if (/\@see/);
                $testSuite{'desc'} .= ' ';
                $testSuite{'desc'} .= ($_ =~ /^\s*\*\s*(.*)/)[0];
                
            }
            # if the parseState is set to 1 and we've reached this point, it means
            # that we have hit the end of the initial test suite comment block
            elsif ($parseState == 1)
            {
                $parseState = 2;
            }
            
            elsif ($parseState == 2)
            {
                # documentation for individual test cases
                if (/\/\*\*/)
                {
                    $current_comment = "";
                    $in_comment = 1;
                    if (/\*\//)
                    {
                        $in_comment = 0;   
                    }
                }
                elsif (/\*\//)
                {
                    $in_comment = 0;   
                }
                elsif (/public\s+void\s+(test[a-zA-Z0-9\_\-]+)\(\)/)
                {
                    my $testCaseName = $1;
                    $current_comment =~ s/^<br>//;
                    while ($current_comment =~ /<br>[\t\n\s]*$/)
                    {
                        $current_comment =~ s/<br>[\t\n\s]*$//;
                    }
                    $in_comment = 0;
                    $parseState = 2;
                    my %testCase = ("num" => $testCaseNumber, "desc" => $current_comment, "type" => $testCaseType, "name" => $testCaseName, "env" => $testCaseEnv);
                    $testSuite{$testCaseName} = \%testCase;
                    $current_comment = "";
                    $testCaseType = "";
                    $testCaseNumber = "";
                    $testCaseEnv = "";
                }
                elsif ($in_comment)
                {
                    s/^\s*\*?\s*//;
                    s/\s*\*?\s*$//;
                    if (/\@testcase (.*)/)
                    {
                        #$testCaseName = $1;
                    }
                    elsif (/\@type(.*)/)
                    {
                        $testCaseType = $1;
                        $testCaseType = trimmer($testCaseType);
                    }
                    elsif (/\@testcaseId(.*)/)
                    {
                        $testCaseNumber = $1;
                        $testCaseNumber = trimmer($testCaseNumber);
                    }
                    elsif (/\@env(.*)/)
                    {
                        $testCaseEnv = $1;
                        $testCaseEnv = trimmer($testCaseEnv);
                        if ($testCaseEnv =~ /prod/i)
                        {
                            $testSuiteMasterEnv = PROD();
                        }
                    }
                    elsif (/\@throws/)
                    {
                        # ignore   
                    }
                    else
                    {
                        $current_comment .= $_." ";
                    }
                }
            }
        }
        if ($testSuite{'desc'} eq "")
        {
            $testSuite{'desc'} = "Comments regarding this test suite are forthcoming.";
        }
        
        $testSuite{'env'} = $testSuiteMasterEnv;

        close(SOURCE);
    }
    closedir(BASEDIR);

    return \%testSuites;
}

sub trimmer
{
    my $shrub = shift;
    $shrub =~ s/^[\s\t\r\n]*//;
    $shrub =~ s/[\s\t\r\n]*$//;
    return $shrub;   
}

1;