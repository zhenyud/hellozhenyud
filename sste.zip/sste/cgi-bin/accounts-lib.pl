$accounts_disp_sub_actions = 1;
%accounts_sub_actions = (
    "devo_collection" => "Development Collection Accounts",
    "devo_regular" => "Regular Development Accounts",
    "prod_collection" => "Production Collection Accounts"
);

sub accounts_devo_collection
{
    $in{'env'} = "devo";
    $in{'type'} = "collection";
    &disp_accts;
}

sub accounts_devo_regular
{
    $in{'env'} = "devo";
    $in{'type'} = "regular";
    &disp_accts;
}

sub accounts_prod_collection
{
    $in{'env'} = "prod";
    $in{'type'} = "collection";    
    &disp_accts;
}

sub accounts
{
    if ($in{'sub_action'} && $accounts_sub_actions{$in{'sub_action'}} ne "")
	{
		&{"$in{'action'}_$in{'sub_action'}"};
	}
	else
	{	
       	&header("SSTE - Test Accounts");
       	gen_title("SSTE - Test Accounts");
       	&nav;
        &start_body;
    
        print qq(<b class="md_title">Test Accounts</b><br>
        This utility provides access to accounts that have been 
        created for Prime QA testing purposes.  All accounts marked in red
        are in use by the Prime automated test suites and, as such, should 
        not be used or modified.);
        &end_body;
        &footer;
    }
}

sub disp_accts 
{
    &header("SSTE - Test Accounts");
    gen_title("SSTE - Test Accounts");
    &nav;
    &start_body;
    
    print qq(
    <b class="md_title">$accounts_sub_actions{$in{'sub_action'}}</b><br><br>
    <iframe frameborder="0" src ="http://internal.amazon.com/~jolo/accounts/index.cgi?env=$in{'env'}&type=$in{'type'}&hash_base=$in{'hash_base'}" width="100%" height="500"></iframe>
    );    
    
    &end_body;
    &footer;
}

1;