
my %valid_sub_actions = (
	"exec" => 1
);

sub dbtool
{
    # if a sub-action has been passed in, make sure it is valid, and, if so,
    # execute it
	if ($in{'sub_action'} && 1 == $valid_sub_actions{$in{'sub_action'}})
	{
		&{"$in{'action'}_$in{'sub_action'}"};
		return;
	}
	# otherwise, display the DB tool splash page
	else
   	{
        header("SSTE - Prime QA DB Tool");
        gen_title("SSTE - Prime QA DB Tool");
        &nav;
        &start_body;
    
        print qq(
        <p>Use this utility to look up subscription information for devo accounts.<br><br>
        <table border="0" cellpadding="2" cellspacing="0">
        <form action="index.cgi" method="get">
            <input type="hidden" name="action" value="$in{'action'}">
            <input type="hidden" name="sub_action" value="exec">
            <tr>
                <td align="right">Value:</td>
                <td><input class="inputfield"  type="text" name="value" size="38" maxlength="128"> (use customer ID or email address)</td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Search &gt;&gt;" class="generic_submit_btn"></td>
            </tr>
        </form>
        </table>
        </form></p>
        );
    
        &end_body;
        &footer;
    }
}

sub dbtool_exec
{
    header("SSTE - Prime QA DB Tool - Search Results");
    gen_title("SSTE - Prime QA DB Tool - Search Results");
    &nav;
    &start_body;
    print qq(<p><b class="md_title">Search Results</b><br>Your search for <b>$in{'value'}</b> produced the following result(s).</p>
    
    <p><b><a href="index.cgi?action=$in{'action'}">New Search</a></b></p>
    );

    my $db_prefix = "t";
    if ($in{'domain'} eq "prod")
    {
        $db_prefix = "";
    }
    else
    {
        $in{'domain'} = "test";   
    }

    my $email;
    if ($in{'value'} =~ /\@/)
    {
        $email = $in{'email_addr'} = $in{'value'};
    }
    elsif ($in{'value'} =~ /^[0-9]+$/)
    {
        my $encrypted_id = Amazon::Crypt::IDs::encrypt_customer_id($in{'value'});
        my $content = get("http://$ENV{'HTTP_HOST'}/email_retriever.cgi?id=$encrypted_id&domain=$in{'domain'}");
        my @content = split(/\n/, $content);
        $in{'email_addr'} = $content[$#content];
        chomp($in{'email_addr'});
        $email = $in{'email_addr'};
    }
    elsif ($in{'value'} =~ /^[0-9A-Za-z]+$/)
    {
        my $encrypted_id = $in{'value'};
        my $content = get("http://$ENV{'HTTP_HOST'}/email_retriever.cgi?id=$encrypted_id&domain=$in{'domain'}");
        my @content = split(/\n/, $content);
        $in{'email_addr'} = $content[0];
        chomp($in{'email_addr'});
        $email = $in{'email_addr'};
    }
  
    use LWP::Simple;
    use Amazon::Crypt::IDs;
    
    my $user = 'rtot_ro';
    my $pass = 'rtot_ro_5283';

    $content = get("http://$ENV{'HTTP_HOST'}/test.cgi?email=$email&domain=$in{'domain'}");
    
    my ($customer_id, @cc_id, @cc_tails, @cc_last_used, @results, %cust);
    if ($content =~ /Customer ID/)
    {
        my @content = split(/\n/, $content);
        foreach (@content)
        {
            if (/Customer ID: ([0-9]+)/)
            {
                $customer_id = $1;
            }
            elsif (/Credit Card ID: ([0-9]+)/)
            {
                push(@cc_id, $1);
            }
            elsif (/Credit Card Tail: ([0-9]{5})/)
            {
                push(@cc_tail, $1);
            }
            elsif (/Last Used UTC: (.*)/)
            {
                push(@cc_last_used, $1);
            }
        }
        %cust = ("CUSTOMER_ID" => $customer_id, 
                 "LOWER_EMAIL" => $email,
                 "CC_ID" => $cc_id,
                 "LAST_USED_UTC" => $last_used_utc);
        $results[0] = \%cust;
    }

    my $subs_dbh = DBI->connect('DBI:Oracle:'.$db_prefix.'subs1na',
                                 $user,
                                 $pass,
                                 {
                                    RaiseError=> 1,
                                    AutoCommit => 0
                                 }
                                ) or die "Database connection failed: $DBI::errstr \n";

    my $num_results = $#results + 1;
   
    if ($num_results >= 1)
    {
        my $result = $selected_result || $results[0];
        my $encrypted_id = Amazon::Crypt::IDs::encrypt_customer_id($result->{'CUSTOMER_ID'});
        if ($num_results > 1)
        {
            my $email_list;
            
            foreach my $nav_result (@results)
            {
                my $formatted_email_addr = $nav_result->{'LOWER_EMAIL'};
                $formatted_email_addr =~ s/^(.{22}).*$/$1\.\.\./ if length($formatted_email_addr) > 22;
                my $class = $nav_result->{'CUSTOMER_ID'} eq $result->{'CUSTOMER_ID'} ? "dbtoolsel" : "dbtoolres";
                $email_list .= qq(<a href="index.cgi?email_addr=$email&cust_id=$nav_result->{'CUSTOMER_ID'}" class="$class">$formatted_email_addr</a>);
            }
            
            print qq(<p><table border="0" cellpadding="0" cellspacing="0">
            <tr valign="top">
            <td width="150">
            <b>Search Results</b>
            $email_list
            </td>
            <td width="12">&nbsp;</td>
            <td width="688">
            <p>Your search for <b>$email</b> returned <b>$num_results</b> results.</p>
            );
        }
        
        my $hash_base = $in{'hash_base'} || 1024;
        my $customer_id_hash_value = ($result->{'CUSTOMER_ID'} / 8) % $hash_base;
        
        print qq(<p><table border="1" cellpadding="2" cellspacing="0" bgcolor="#ffffbb">
                <tr bgcolor="#666666">
                    <td colspan="2"><font color="#ffffff"><b>GENERAL CUSTOMER INFORMATION</b></font></td>
                </tr>
                <tr>
                    <td align="right">Email Address:</td>
                    <td>$result->{'LOWER_EMAIL'}</td>
                </tr>
                <tr>
                    <td align="right">ID:</td>
                    <td>$result->{'CUSTOMER_ID'}</td>
                </tr>
                <tr>
                    <td align="right">Hash:</td>
                    <td>$customer_id_hash_value</td>
                </tr>
                <tr>
                    <td align="right">Encrypted ID:</td>
                    <td>$encrypted_id</td>
                </tr>
             </table>
             </p>
             
             <p><table border="1" cellpadding="2" cellspacing="0" bgcolor="#ffffbb">
                <tr bgcolor="#666666">
                    <td colspan="3"><font color="#ffffff"><b>CREDIT CARD INFORMATION</b></font></td>
                </tr>
                <tr bgcolor="#cccccc">
                    <td><b>ID</b></td>
                    <td><b>Tail</b></td>
                    <td><b>Last Used</b></td>
                </tr>
        );
        
        for (my $ii = 0; $ii <= $#cc_id; ++$ii)
        {
            print qq(<tr><td>$cc_id[$ii]</td><td>$cc_tail[$ii]</td><td>$cc_last_used[$ii]</td></tr>);
        }
        print qq(</table></p>);
                
        my $subs_sth = $subs_dbh->prepare("select subscription_id, subscription_status from subscriptions where customer_id=?");
        $subs_sth->execute($result->{'CUSTOMER_ID'});
        
        my $count = 0;
        while (my $sub = $subs_sth->fetchrow_hashref())
        {
            $count++;
            print qq(
                <p><table border="1" cellpadding="2" cellspacing="0" bgcolor="#ffffff">
                    <tr bgcolor="#666666">
                        <td colspan="2"><font color="#ffffff"><b>SUBSCRIPTION \#$count</b></font></td>
                    </tr>
                    <tr bgcolor="#ffffbb">
                        <td align="right" width="100">ID:</td>
                        <td><a href="http://development.amazon.com/gp/internal/subs/subs-info.html/?subsID=$sub->{'SUBSCRIPTION_ID'}" target="devosubs">$sub->{'SUBSCRIPTION_ID'}</a></td>
                    </tr>
                    <tr bgcolor="#ffffbb">
                        <td align="right">Status:</td>
                        <td>$sub->{'SUBSCRIPTION_STATUS'}</td>
                    </tr>
            );        
            
            my $prob_sth = $subs_dbh->prepare("select subscription_problem_id, subscription_problem from subscription_problems where subscription_id = ? and termination_date is null");
            $prob_sth->execute($sub->{'SUBSCRIPTION_ID'});
            while (my $sub_problem = $prob_sth->fetchrow_hashref())
            {
                print qq(
                    <tr bgcolor="#ffffbb">
                        <td align="right">Problem $sub_problem->{'SUBSCRIPTION_PROBLEM_ID'}:</td>
                        <td>$sub_problem->{'SUBSCRIPTION_PROBLEM'}</td>
                    </tr>
                );
            }
            $prob_sth->finish;

            my $cv_sth = $subs_dbh->prepare("select client_view, TO_CHAR(creation_date, 'MM/DD/YY-HH24:MI:SS') as creation_date, TO_CHAR(end_date, 'MM/DD/YY-HH24:MI:SS') as end_date, TO_CHAR(effective_date, 'MM/DD/YY-HH24:MI:SS') as effective_date from subs_client_view_history where subscription_id=? order by end_date");
            $cv_sth->execute($sub->{'SUBSCRIPTION_ID'});
           
            print qq(
                <tr>
                    <td colspan="2">
                                <br><table border="1" cellpadding="2" cellspacing="0" bgcolor="#ffffbb">
                                    <tr bgcolor="#999999">
                                        <td colspan="4">
                                        <b>Client History</b>
                                        </td>
                                    </tr>
                                    <tr bgcolor="#cccccc">
                                        <td>Creation Date</td>
                                        <td>Effective Date</td>
                                        <td>End Date</td>
                                        <td>Client View</td>
                                    </tr>
            );
            while (my $history = $cv_sth->fetchrow_hashref())
            {
                print qq(<tr>
                    <td>$history->{'CREATION_DATE'}</td>
                    <td>$history->{'EFFECTIVE_DATE'}</td>
                    <td>$history->{'END_DATE'}</td>
                    <td>$history->{'CLIENT_VIEW'}</td>
                    </tr>
                );
            }
            $cv_sth->finish;
            
            print qq(</table><br><table border="1" cellpadding="2" cellspacing="0" bgcolor="#ffffbb">
                                    <tr bgcolor="#999999">
                                        <td colspan="7">
                                        <b>Transaction History</b> &nbsp;&nbsp;&nbsp; (<a href="http://campsight.amazon.com/search/?idtype=cus&id=$result->{'CUSTOMER_ID'}&org=us&test=on">CAMPS</a>)
                                        </td>
                                    </tr>
                                    <tr bgcolor="#cccccc">
                                        <td>MID</td>
                                        <td>Transaction ID</td>
                                        <td>Type</td>
                                        <td>Status</td>
                                        <td>Amount</td>
                                        <td>Creation Date</td>
                                        <td>Subs Plan Family Type</td>
                                    </tr>);

            my $trans_sth = $subs_dbh->prepare("select marketplace_id, transaction_guid, transaction_status, TO_CHAR(transaction_creation_date, 'MM/DD/YY-HH24:MI:SS') as creation_date, total_transaction_amount, transaction_type, subs_plan_family_type from subs_transactions where subscription_id = ?");
            $trans_sth->execute($sub->{'SUBSCRIPTION_ID'});

            while (my $trans = $trans_sth->fetchrow_hashref())
            {
                print qq(<tr>
                        <td>$trans->{'MARKETPLACE_ID'}</td>
                        <td>$trans->{'TRANSACTION_GUID'}</td>
                        <td>$trans->{'TRANSACTION_TYPE'}</td>
                        <td>$trans->{'TRANSACTION_STATUS'}</td>
                        <td>$trans->{'TOTAL_TRANSACTION_AMOUNT'}</td>
                        <td>$trans->{'CREATION_DATE'}</td>
                        <td>$trans->{'SUBS_PLAN_FAMILY_TYPE'}</td>
                    </tr>
                );
            }
            $trans_sth->finish;
            
            print qq(</table><br><table border="1" cellpadding="2" cellspacing="0" bgcolor="#ffffbb">
                                    <tr bgcolor="#999999">
                                        <td colspan="7"><b>Metadata</b></td>
                                    </tr>
                                    <tr bgcolor="#cccccc">
                                        <td>Key</td>
                                        <td>Value</td>
                                    </tr>);
			
			my $metadata_sth = $subs_dbh->prepare("select * from subscription_metadata where subscription_id = ? order by creation_date");
			$metadata_sth->execute($sub->{'SUBSCRIPTION_ID'});
			
			my $metadata_count = 0;
			while (my $metadata = $metadata_sth->fetchrow_hashref())
			{
				$metadata_count++;
				print qq(<tr><td>$metadata->{'METADATA_KEY'}</td><td>$metadata->{'METADATA_VALUE'}</td></tr>);	
			}
			
			if (! $metadata_count)
			{
				print qq(<tr><td colspan="2" align="center">No metadata exists for this subscription.</td></tr>);	
			}
			
            print qq(
                </table></td></tr></table></p>
            );

            if ($num_results > 1)
            {
                print qq(</td></tr></table></p>);
            }
        }
        if (! $count)
        {
            print qq(<p><b>Subscriptions</b><br>This user has no subscriptions.</p>);
        }
        $subs_sth->finish;
        
        print qq(<p><b><a href="index.cgi?action=$in{'action'}">New Search</a></b></p>);
    }
    else
    {
        $num_results = "0" if (! $num_results); 
        print qq(<p><b>Error</b><br>Your query for customers with an email address of
            <font color="#880000"><b>$email</b></font> returned $num_results results.  Please verify the email
            address and <a href="index.cgi?action=$in{'action'}">try your query again</a>.</p>);
    }
    
    $subs_dbh->disconnect;

    &end_body;
    &footer;
}

1;
