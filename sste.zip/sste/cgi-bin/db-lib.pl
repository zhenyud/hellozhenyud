
my $active_dbh;

sub get_dbh
{
    my $retries = 0;
    while (++$retries < 10 )
    {
        _db_disconnect();
        _db_connect();
        my $timestamp = $active_dbh->do("select CURRENT_TIMESTAMP as theTime");
        return $active_dbh if (defined $timestamp);
    }    
    die "Repeatedly unable to get DB connection.  Last error: ".DBI->err;
}

sub _db_connect
{
    die "Already have a DB connection" if ( defined( $active_dbh ) );
    $active_dbh = DBI->connect(
                "DBI:mysql:database=sste;host=127.0.0.1;port=3306",
                "sste",
                "sst3Wr1t3r") or print "Content-type: text/html\n\nUnable to connect to DB: ".$DBI->errstr;
}

sub _db_disconnect
{
    if (defined($active_dbh)) 
    { 
        eval { $active_dbh->disconnect(); };
        $active_dbh = undef;
    }
}

1;
