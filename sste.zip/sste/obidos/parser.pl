my $DEBUG = 1;
my $base_dir = "/tmp/";
my $output_dir = "/workplace/jolo/local-overrides/ApacheServerRoot/server-root/obidos/data_files/";

opendir(DIR, "/tmp");
while (defined(my $filename = readdir(DIR)))
{
    next unless $filename =~ /^obidos/;
    my $file_size = (stat($base_dir.$filename))[7];
    
    if ($file_size != 0)
    {
        my $status = parse_log($base_dir.$filename);
        
        if (! $status)
        {
            print "Unable to parse $filename.\n" if $DEBUG;
        }
    }
    unlink($base_dir.$filename);
}
closedir(DIR);

sub parse_log
{
    my ($file) = @_;
    my $timestamp = ($file =~ /obidos_([0-9]+)\.txt$/)[0];

    if (! -e "$output_dir$timestamp")
    {
        print "Parsing ${file}...\n" if $DEBUG;

        # make a directory for the resultant output files
        system("mkdir $output_dir$timestamp");
        return 0 unless -e "$output_dir$timestamp";
        
        my ($err_count, $num_bad, $url, $ts, $tc, $content, $in_content) = (0, 0, "", "", "", "", 0);
        my %bad_urls;
        open(TOC, ">$output_dir${timestamp}/toc.flat");
        open(FILE, $file) or return 0;
        while (<FILE>)
        {
            chomp;
            
            if (/^TEST SUITE: (.*)/)
            {
                my $temp_ts = $1;
    
                if ($err_count > 0)
                {
                    print TOC "$err_count\t$ts\t$tc\t$url\t$num_bad\n";
                    open(CONTENT, ">$output_dir${timestamp}/${err_count}.html");
                    print CONTENT $content;
                    close(CONTENT);
                    
                    open(BAD, ">>$output_dir${timestamp}/urls.flat");
                    foreach my $key (sort keys %bad_urls)
                    {
                        print BAD "$err_count\t$key\t$bad_urls{$key}\n";
                    }
                    close(BAD);
                }
    
                $err_count++;
                $ts = $temp_ts;
                $tc = "";
                $url = "";
                $content = "";
                %bad_urls = ();
                $in_content = 0;
                $num_bad = 0;
            }
            elsif (/^TEST CASE: (.*)/)
            {
                $tc = $1;
                $in_content = 0;
                
            }
            elsif (/^PAGE URL: (.*)/)
            {
                $url = $1;
                $in_content = 1;
            }
            elsif ($in_content)
            {
               my $temp_text = $_;
               $content .= $temp_text."\n";
               
               while ($temp_text =~ /[\s\"\']?([^\s\"\']+exec[^\s\"\']+obidos[^\"\s\']+)/)
               {
                   my $bad_url = $1;
                   $bad_urls{$bad_url}++;
                   $num_bad++;
                   $temp_text =~ s/[\s\"]?[^\s\"]+obidos[^\"\s]+//;
               }
            }
            else
            {
               return 0;    # should never happen   
            }
        }
        $err_count++;
        print TOC "$err_count\t$ts\t$tc\t$url\n";
        open(CONTENT, ">$output_dir${timestamp}/${err_count}.html");
        print CONTENT $content;
        close(CONTENT);
    
        open(BAD, ">>$output_dir${timestamp}/urls.flat");
        foreach my $key (sort keys %bad_urls)
        {
            print BAD "$err_count\t$key\t$bad_urls{$key}\n";
        }
        close(BAD);
    
        close(FILE);
        close(TOC);
    }
    return 1;
}